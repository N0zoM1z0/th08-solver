"""Phase-qualified trace validation and first-difference analysis.
Input producers must be integrated separately; this is not a process-memory hook.
"""
import json,math
from pathlib import Path
PHASES={'input_sample','player_pre','player_post','enemy_post','bullet_post','frame_end'}
REQUIRED={'frame','phase','schema','input_consumed','rng_seed','events','player','bullets','lasers','enemies'}
def read(path):
 rows=[];previous=-1
 for line_no,line in enumerate(Path(path).read_text(encoding='utf-8').splitlines(),1):
  if not line.strip():continue
  x=json.loads(line,parse_constant=lambda s:(_ for _ in ()).throw(ValueError('nonfinite JSON')))
  if not isinstance(x,dict) or not REQUIRED.issubset(x):raise ValueError(f'line {line_no}: missing required fields')
  if x['schema']!='TH08_TRACE_V1' or x['phase'] not in PHASES:raise ValueError('trace schema/phase')
  if not isinstance(x['frame'],int)or x['frame']<previous:raise ValueError('nonmonotone frame')
  previous=x['frame']
  if x.get('coherent')is not True:raise ValueError('Snapshot producer has not attested a coherent logic boundary')
  for field in('bullets','lasers','enemies'):
   seen=set()
   for entity in x[field]:
    key=(entity['slot'],entity['generation'])
    if key in seen:raise ValueError('duplicate entity generation')
    seen.add(key)
  rows.append(x)
 if not rows:raise ValueError('empty trace')
 return rows

def first_difference(a,b,abs_tol=0.):
 def diff(x,y,path=''):
  if type(x)!=type(y)and not(isinstance(x,(int,float))and isinstance(y,(int,float))):return dict(path=path,left=x,right=y)
  if isinstance(x,dict):
   if set(x)!=set(y):return dict(path=path,left_keys=sorted(x),right_keys=sorted(y))
   for key in sorted(x):
    if key in('wall_time_ns','capture_cost_ns'):continue
    r=diff(x[key],y[key],path+'/'+key)
    if r:return r
  elif isinstance(x,list):
   if len(x)!=len(y):return dict(path=path,left_length=len(x),right_length=len(y))
   for i,(u,v)in enumerate(zip(x,y)):
    r=diff(u,v,path+'/'+str(i))
    if r:return r
  elif isinstance(x,float)or isinstance(y,float):
   if not math.isfinite(x)or not math.isfinite(y)or abs(x-y)>abs_tol:return dict(path=path,left=x,right=y)
  elif x!=y:return dict(path=path,left=x,right=y)
  return None
 for idx,(x,y)in enumerate(zip(a,b)):
  r=diff(x,y)
  if r:return dict(record=idx,frame=x.get('frame'),phase=x.get('phase'),**r)
 if len(a)!=len(b):return dict(record=min(len(a),len(b)),reason='trace length',left=len(a),right=len(b))
 return None

def audit(rows):
 # Event bits repeat at multiple phases in a frame; aggregate before counting.
 frames={}
 for row in rows:frames[row['frame']]=frames.get(row['frame'],0)|row['events']
 return dict(records=len(rows),frames=len(frames),bomb_event_frames=sum(bool(v&1)for v in frames.values()),death_committed_frames=sum(bool(v&4)for v in frames.values()),collision_event_frames=sum(bool(v&2)for v in frames.values()),qualification='Absence of event bits in a partial trace does NOT prove a full run cleared. Collision during invulnerability need not be a miss.')
