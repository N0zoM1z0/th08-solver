"""TH08 resource coverage, conditional emitter laboratory and planning testbed.
Not a complete game emulator or a verified NMNB autoplay implementation.
"""
__version__='0.1.0'
