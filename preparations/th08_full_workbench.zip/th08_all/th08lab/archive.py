"""Bounded TH08 PBGZ decoder, source-derived; no external dependencies."""
from pathlib import Path
import struct, hashlib
PARAMS=((0x5d,0x1b,0x37,0x40,0x2800),(0x74,0x51,0xe9,0x40,0x3000),(0x71,0xc1,0x51,0x1400,0x2000),(0x8a,3,0x19,0x1400,0x7800),(0x95,0xab,0xcd,0x200,0x1000),(0xb7,0x12,0x34,0x400,0x2800),(0x9d,0x35,0x97,0x80,0x2800),(0xaa,0x99,0x37,0x400,0x1000))
def decrypt(data,key,inc,chunk,limit):
    size=len(data);tail=(size%chunk if size%chunk<chunk//4 else 0)+(size&1)
    remaining=size-tail;pos=0;out=bytearray(data)
    while remaining>0 and limit>0:
        chunk=min(chunk,remaining);start=pos
        for parity in (1,2):
            for dest in range(start+chunk-parity,start-1,-2):
                out[dest]=data[pos]^key;key=(key+inc)&255;pos+=1
        remaining-=chunk;limit-=chunk
    return bytes(out)
def lzss(data,expected):
    if not 0<=expected<=256*1024*1024:raise ValueError('Unreasonable output size')
    dictionary=bytearray(8192);valid=bytearray(8192);wp=1;out=bytearray()
    acc=0;bits=0;idx=0;zeros=0
    def take(n):
        nonlocal acc,bits,idx,zeros
        while bits<n:
            if idx<len(data):acc=(acc<<8)|data[idx];idx+=1
            elif len(out)==expected and zeros<2:acc<<=8;zeros+=1
            else:raise ValueError('Truncated LZSS stream')
            bits+=8
        bits-=n;v=(acc>>bits)&((1<<n)-1);acc&=(1<<bits)-1;return v
    while True:
        if take(1):
            v=take(8);out.append(v);dictionary[wp]=v;valid[wp]=1;wp=(wp+1)&8191
        else:
            off=take(13)
            if off==0:break
            for i in range(take(4)+3):
                p=(off+i)&8191
                if not valid[p]:raise ValueError('Uninitialized LZSS backreference')
                v=dictionary[p];out.append(v);dictionary[wp]=v;valid[wp]=1;wp=(wp+1)&8191
        if len(out)>expected:raise ValueError('Decoded length overflow')
    if len(out)!=expected:raise ValueError(f'Decoded size {len(out)} != {expected}')
    return bytes(out)
def unwrap(data):
    if data[:3]!=b'edz':return data
    for i,(marker,key,inc,chunk,limit) in enumerate(PARAMS):
        if data[3]==marker-(i<<4)-0x10:return decrypt(data[4:],key,inc,chunk,limit)
    raise ValueError('Unknown content encryption marker')
class Archive:
    def __init__(self,path):
        self.data=Path(path).read_bytes();d=self.data
        if d[:4]!=b'PBGZ':raise ValueError('Expected PBGZ signature')
        a,b,c=struct.unpack('<III',decrypt(d[4:16],0x1b,0x37,12,0x400))
        n=a-123456;off=b-345678;size=c-567891
        if not(0<n<100000 and 16<=off<len(d)):raise ValueError('Invalid archive header')
        table=lzss(decrypt(d[off:],0x3e,0x9b,0x80,0x400),size);p=0;es=[]
        for i in range(n):
            z=table.index(0,p);name=table[p:z].decode('cp932');p=z+1
            if Path(name).name!=name or any(x in name for x in ('/','\\','..',':')):raise ValueError('Unsafe archive filename')
            pos,dec,meta=struct.unpack_from('<III',table,p);p+=12
            es.append(dict(name=name,offset=pos,packed_decoded_size=dec,metadata=meta))
        if any(table[p:]):raise ValueError('Nonzero unparsed directory padding')
        if len({e['name'] for e in es})!=n:raise ValueError('Duplicate archive name')
        for i,e in enumerate(es):
            e['compressed_size']=(es[i+1]['offset'] if i+1<n else off)-e['offset']
            if e['compressed_size']<=0 or not 16<=e['offset']<off:raise ValueError('Invalid archive extent')
        self.entries=es;self.meta=dict(sha256=hashlib.sha256(d).hexdigest(),bytes=len(d),entries=n,table_offset=off,table_decoded_bytes=size)
    def read(self,e):
        if isinstance(e,str):e=next(x for x in self.entries if x['name']==e)
        pos=e['offset'];out=unwrap(lzss(self.data[pos:pos+e['compressed_size']],e['packed_decoded_size']))
        e.update(decoded_bytes=len(out),sha256=hashlib.sha256(out).hexdigest());return out
