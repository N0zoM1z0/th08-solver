from pathlib import Path
import struct,hashlib,math
from .protocol import OP,SCHEMA,VARS,EX,IGNORED_PAYLOAD

def parse(data,name):
    b=data;ver,n,nt=struct.unpack_from('<IHH',b)
    if ver!=0x800 or not 0<nt<=16:raise ValueError(f'{name}: unexpected ECL header')
    ts=list(struct.unpack_from('<16I',b,8))[:nt];ss=list(struct.unpack_from('<'+str(n)+'I',b,72));bounds=sorted(set(ss+ts+[len(b)]));subs=[];jumps=0
    if len(set(ss))!=n:raise ValueError('Duplicate sub offsets')
    for sid,start in enumerate(ss):
        end=min(x for x in bounds if x>start);p=start;ins=[]
        while p<end:
            t,op,size,res,mask,flags=struct.unpack_from('<ihhBBH',b,p)
            if size<12 or size%4 or p+size>end or op not in OP:raise ValueError((name,sid,p,t,op,size))
            if op==-1 and not(t==-1 and p+size==end):raise ValueError('Misplaced end sentinel')
            payload=b[p+12:p+size];r=dict(pc=p,time=t,opcode=op,op=OP[op],size=size,mask=mask,flags=flags,raw=payload.hex(),args=None,selectors=[])
            schema=SCHEMA.get(op)
            if schema is not None and struct.calcsize('<'+schema)==len(payload):
                args=struct.unpack('<'+schema,payload);r['args']=list(args)
                for k,(typ,v) in enumerate(zip(schema,args)):
                    if flags&(1<<k) and (not isinstance(v,float) or math.isfinite(v)) and int(v) in VARS:
                        r['selectors'].append(dict(operand=k,id=int(v),name=VARS[int(v)],type=typ))
            if op in IGNORED_PAYLOAD:r['args']=[];r['ignored_payload_bytes']=len(payload)
            if op==122:
                face,num,bonus=struct.unpack_from('<hHi',payload)
                def text(v,key):return bytes(x^key for x in v).split(b'\0',1)[0].decode('cp932')
                r['spell']=dict(id=num,name=text(payload[8:56],0xaa),owner=text(payload[56:104],0xbb),bonus=bonus,face=face)
            if op in (136,137):
                x=struct.unpack_from('<i',payload)[0];r['ex']=x;r['ex_name']=EX[x] if 0<=x<len(EX) else 'NONE_OR_DYNAMIC'
            if op==111:
                k=struct.unpack('<iiiiiff',payload);r['transform']=dict(index=k[0],kind=k[1],concurrent=k[2],int0=k[3],int1=k[4],float0=k[5],float1=k[6])
            if op in (4,5) or 40<=op<=51:
                r['jump']=p+struct.unpack_from('<i',payload,12 if 40<=op<=51 else 4)[0];jumps+=1
            ins.append(r);p+=size
        pcs={i['pc'] for i in ins}
        if any(i['jump'] not in pcs for i in ins if 'jump'in i):raise ValueError('Jump not on subinstruction boundary')
        subs.append(dict(id=sid,pc=start,end=end,instructions=ins))
    timelines=[]
    for k,start in enumerate(ts):
        p=start;ins=[]
        while True:
            t,op,size,mask=struct.unpack_from('<ihBB',b,p)
            if t<0:break
            if size<8 or p+size>len(b) or not 0<=op<=16:raise ValueError('Invalid timeline')
            raw=b[p+8:p+size];sc={0:'iffiii',1:'iffiii',2:'ifffiii',3:'ifiii',4:'ifffiii',5:'ifiii',6:'i',7:'',8:'ii',9:'i',10:'i',11:'iffiiii',12:'iffiiii',13:'i',14:'i',15:'iffiii',16:''}.get(op)
            args=list(struct.unpack('<'+sc,raw)) if sc is not None and struct.calcsize('<'+sc)==len(raw) else None
            ins.append(dict(pc=p,time=t,opcode=op,size=size,mask=mask,args=args,raw=raw.hex()));p+=size
        timelines.append(dict(id=k,pc=start,instructions=ins))
    return dict(file=name,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b),sub_count=n,timeline_count=nt,jumps_validated=jumps,subs=subs,timelines=timelines)

def format_ins(i):
    if 'spell'in i:return f"{i['op']} {i['spell']}"
    if i['args'] is None:return f"{i['op']} RAW={i['raw']}"
    a=list(i['args'])
    for s in i['selectors']:a[s['operand']]='$'+s['name']
    return i['op']+'('+', '.join(str(x) for x in a)+')'+(f" ->{i['jump']:#x}" if 'jump'in i else '')

def disassemble(e):
    lines=[f"{e['file']} sha256={e['sha256']}", 'All masks retained. Offsets are decrypted-file offsets. Times are local ECL times.']
    for s in e['subs']:
        lines.append(f"\n=== sub {s['id']} @{s['pc']:#x} ===")
        for i in s['instructions']:lines.append(f"{i['pc']:#08x} t={i['time']:5} mask={i['mask']:02x} flags={i['flags']:04x} {format_ins(i)}")
    return '\n'.join(lines)+'\n'
