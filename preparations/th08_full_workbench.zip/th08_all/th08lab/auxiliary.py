"""Bounded wire parsers for STD, dialogue and supplied replay fixtures.
No message execution, background camera simulation or game replay playback.
"""
from pathlib import Path
import struct,hashlib,collections
from .archive import lzss

def replay(path):
    original=Path(path).read_bytes();b=bytearray(original)
    if len(b)<104 or b[:4]!=b'T8RP' or struct.unpack_from('<H',b,4)[0]!=6:raise ValueError('T8RP v6 required')
    size,checksum=struct.unpack_from('<II',b,12)
    if not 104<=size<=len(b):raise ValueError('Replay extent')
    key=b[21]
    for j in range(24,size):b[j]=(b[j]-key)&255;key=(key+7)&255
    if (0x3f000318+sum(b[21:size]))&0xffffffff!=checksum:raise ValueError('Replay checksum')
    cs,ds=struct.unpack_from('<II',b,24)
    if cs!=size-104 or not 204<=ds<=128*1024*1024:raise ValueError('Replay lengths')
    decoded=bytes(b[:104])+lzss(b[104:size],ds)
    stages=struct.unpack_from('<9I',decoded,32);fps=struct.unpack_from('<9I',decoded,68);rows=[]
    for k,start in enumerate(stages):
        if not start:continue
        if not 308<=start<=len(decoded)-64:raise ValueError('Stage header extent')
        initial=struct.unpack_from('<6IhH6BbB',decoded,start)
        end=fps[k]
        if not start+36<=end<=len(decoded):raise ValueError('Input/FPS ordering not supported')
        stride=6 if b[6] else 2;raw=decoded[start+36:end]
        if len(raw)%stride:raise ValueError('Input record alignment')
        values=list(struct.unpack('<'+'H'*(len(raw)//2),raw));inputs=values[::stride//2]
        row=dict(stage_index=k,stage_offset=start,fps_offset=end,score=initial[0],graze=initial[2],youkai_gauge=initial[6],rng_seed=initial[7],power=initial[8],lives=initial[9],bombs=initial[10],rank=initial[11],character=initial[12],captured=initial[13],clock_time=initial[14],serialized_input_records=len(inputs),input_sha256=hashlib.sha256(raw).hexdigest(),inputs=inputs)
        if stride==6:
            row['event_flags']=values[1::3];row['rng_seeds']=values[2::3]
        rows.append(row)
    return dict(file=Path(path).name,sha256=hashlib.sha256(original).hexdigest(),checksum_valid=True,extended=bool(b[6]),difficulty=decoded[107],shot_type=decoded[106],spell_number=struct.unpack_from('<h',decoded,124)[0],practice=bool(decoded[123]),stage_records=rows,qualification='Wire input extent only; not played here. Record counts are not attested consumed-update counts. No NMNB inference from a demo.')

def dialogue(path):
    b=Path(path).read_bytes();n=struct.unpack_from('<I',b)[0]
    if not 0<n<10000 or 4+4*n>len(b):raise ValueError('Message header')
    offsets=struct.unpack_from('<'+'I'*n,b,4);out=[]
    for idx,start in enumerate(offsets):
        end=min([x for x in offsets if x>start]+[len(b)]);p=start;ins=[]
        if not 4+4*n<=start<end:raise ValueError('Message offset')
        while p<end:
            if p+4>end:raise ValueError('Message truncated')
            t,op,size=struct.unpack_from('<HBB',b,p)
            if p+4+size>end:raise ValueError('Message payload')
            ins.append(dict(pc=p,time=t,opcode=op,size=size,payload=b[p+4:p+4+size].hex()));p+=4+size
        out.append(dict(index=idx,offset=start,end=end,instructions=ins))
    return dict(file=Path(path).name,sha256=hashlib.sha256(b).hexdigest(),messages=out,qualification='All records structurally parsed; dialogue choices, timing and displayed strings not simulated.')

def stage(path):
    b=Path(path).read_bytes();n,nq,io,so,res=struct.unpack_from('<hhiii',b)
    if n<0 or nq<0 or not 1168+4*n<=io<=so<len(b):raise ValueError('STD header')
    offs=struct.unpack_from('<'+'I'*n,b,1168);objects=[];count=0
    for start in offs:
        end=min([x for x in offs if x>start]+[io]);oid,z,flags,*v=struct.unpack_from('<hbb6f',b,start);p=start+28;quads=[]
        while p<end:
            kind,size=struct.unpack_from('<hh',b,p)
            if kind==-1:break
            if kind not in(0,1) or size not in(28,36) or p+size>end:raise ValueError(f'STD quad {Path(path).name} {p:#x} {kind} {size}')
            vals=struct.unpack_from('<hhhh'+'f'*((size-8)//4),b,p);quads.append(dict(pc=p,type=kind,size=size,anm_script=vals[2],vm_index=vals[3],values=vals[4:]));p+=size;count+=1
        objects.append(dict(id=oid,offset=start,zlevel=z,flags=flags,position=v[:3],size=v[3:],quads=quads))
    if count!=nq:raise ValueError('STD quad count')
    instances=[];p=io
    while p+16<=so:
        oid,pad,x,y,z=struct.unpack_from('<hhfff',b,p)
        if oid==-1:break
        if not 0<=oid<n:raise ValueError('STD instance ID')
        instances.append(dict(pc=p,object=oid,position=[x,y,z]));p+=16
    p=so;ins=[]
    while p+8<=len(b):
        t,op,size=struct.unpack_from('<ihh',b,p)
        if op==-1 or t==-1:break
        if size<0 or size>1024 or p+8+size>len(b) or not 0<=op<=34:raise ValueError(f'STD instruction {p:#x} {op} {size}')
        ins.append(dict(pc=p,frame=t,opcode=op,payload_size=size,payload=b[p+8:p+8+size].hex()));p+=8+size
    name=b[16:144].split(b'\0')[0].decode('cp932',errors='replace')
    return dict(file=Path(path).name,sha256=hashlib.sha256(b).hexdigest(),stage_name=name,objects=objects,instances=instances,instructions=ins,qualification='Background geometry is NOT the player collision map. VM scripts and random side effects still need runtime execution.')
