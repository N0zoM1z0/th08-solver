"""Parse all ANM-v3 entry/script/sprite extents; texture payload is not rendered."""
import struct,hashlib

def parse(b,name):
    base=0;entries=[];scripts=[];sprites=[];seen=set()
    while True:
        if base in seen:raise ValueError('ANM entry cycle')
        seen.add(base);h=struct.unpack_from('<16I',b,base);ns,nc=h[:2]
        if h[10]!=3 or ns>100000 or nc>100000:raise ValueError((name,base,'unsupported ANM version/header',h))
        path=b[base+h[7]:].split(b'\0',1)[0].decode('cp932')
        entries.append(dict(pc=base,name=path,sprites=ns,scripts=nc,width=h[3],height=h[4],format=h[5],next_offset=h[14]))
        for k in range(ns):
            pos=base+struct.unpack_from('<I',b,base+64+4*k)[0];v=struct.unpack_from('<Iffff',b,pos)
            sprites.append(dict(index=len(sprites),id=v[0],pc=pos,x=v[1],y=v[2],width=v[3],height=v[4]))
        for k in range(nc):
            sid,off=struct.unpack_from('<II',b,base+64+4*ns+8*k);p=base+off;ins=[]
            for steps in range(100000):
                op,size,t,mask=struct.unpack_from('<hHhH',b,p)
                if op==-1:break
                if size<8 or p+size>len(b):raise ValueError((name,p,'invalid ANM instruction'))
                ins.append(dict(pc=p,opcode=op,time=t,mask=mask,size=size,raw=b[p+8:p+size].hex()));p+=size
            else:raise ValueError('ANM instruction cap')
            scripts.append(dict(index=len(scripts),id=sid,pc=base+off,instructions=ins))
        if not h[14]:break
        if h[14]<64:raise ValueError('Invalid next entry')
        base+=h[14]
    return dict(file=name,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b),entries=entries,scripts=scripts,sprites=sprites)

def parse_sht(b,name):
    n=struct.unpack_from('<H',b,2)[0]
    return dict(file=name,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b),levels=n,bombs=struct.unpack_from('<f',b,4)[0],deathbomb_window=struct.unpack_from('<i',b,8)[0],hurtbox_full_width=struct.unpack_from('<f',b,12)[0],normal=struct.unpack_from('<f',b,36)[0],focus=struct.unpack_from('<f',b,40)[0],normal_diagonal=struct.unpack_from('<f',b,44)[0],focus_diagonal=struct.unpack_from('<f',b,48)[0],status='movement header parsed; firing records need source-specific analysis')
