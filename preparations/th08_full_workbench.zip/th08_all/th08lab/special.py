"""Auditable specialized geometry/state kernels. No renderer or full ECL runtime.
Return actual predicate calls, not a merged visual envelope. Unit clock only.
"""
from dataclasses import dataclass
from .emitter import f32
from .kinematics import norm
import math

WARP={
 'narrow':dict(center=(192.,208.),inner=(124.11774444580078,140.11773681640625,259.88226318359375,275.88226318359375),outer=(56.23548889160156,72.23548889160156,327.7645263671875,343.7645263671875),small=67.88225555419922,large=135.76451110839844),
 'medium':dict(center=(192.,208.),inner=(112.80403137207031,128.8040313720703,271.1959533691406,287.1959533691406),outer=(33.608070373535156,49.608070373535156,350.3919372558594,366.3919372558594),small=79.19596862792969,large=158.39193725585938),
 'wide':dict(center=(192.,224.),inner=(56.23548889160156,88.23548889160156,327.7645263671875,359.7645263671875),outer=(-32.,0.,416.,448.),previous_outer=(-31.100006103515625,0.,416.,448.),small=135.76451110839844,large=224.)}

def warp(p,v,angle,cooldown,kind):
 c=WARP[kind]
 if cooldown:return tuple(p),tuple(v),angle,cooldown-1
 def inside(p,b):return b[0]<p[0]<b[2]and b[1]<p[1]<b[3]
 def zone(p,previous=False):return 0 if inside(p,c['inner'])else 1 if inside(p,c.get('previous_outer',c['outer'])if previous else c['outer'])else 2
 old=[f32(p[k]-v[k])for k in range(2)];z=zone(p);o=zone(old,True)
 if z==o:return tuple(p),tuple(v),angle,0
 a,b=(c['large'],c['small'])if z==0 or o==0 else(c['small'],c['large'])
 pos=tuple(f32(f32(f32(p[k]-c['center'][k])*a)/b+c['center'][k])for k in range(2))
 return pos,tuple(-x for x in v),norm(angle+math.pi),2

def reisen_phase(vm_type,disabled):
 if vm_type==1:return 0,True,'slow invisible; velocity must be changed by caller'
 if vm_type==0:return 2,disabled,'appear interpolation; collision unchanged'
 return 1,False,'restore angle/speed velocity'

@dataclass
class LaserState:
 x:float=192.;y:float=100.;angle:float=1.5707963267948966
 start:float=0.;end:float=100.;length:float=100.;width:float=16.;speed:float=0.
 start_time:int=30;duration:int=60;despawn_time:int=10;hitbox_start:int=20;hitbox_end:int=5;flags:int=0
 state:int=0;timer:int=0;active:bool=True
 def step(self):
  if not self.active:return []
  self.end=f32(self.end+self.speed)
  if self.end-self.start>self.length:self.start=f32(self.end-self.length)
  self.start=max(self.start,0.)
  sx=f32(self.end-self.start)if self.start<=0 else f32((self.end-self.start)*.7)
  sy=f32(self.width/2);cx=f32((self.end-self.start)/2+self.start+self.x);cy=self.y;calls=[]
  def call(graze):calls.append(dict(origin=[self.x,self.y],center=[cx,cy],full_size=[sx,sy],angle=self.angle,graze=bool(graze),state=self.state,timer=self.timer))
  if self.state==0:
   if not self.flags&1:
    if self.start_time<=0:raise ValueError('Starting state with zero start_time is invalid')
    ramp=min(self.start_time,30);current=f32(self.timer*self.width/self.start_time)if self.start_time-ramp<self.timer else 1.2
    sx=f32(current/2) # Actual source writes X, not Y.
   if self.timer>=self.hitbox_start:call(False)
   if self.timer>=self.start_time:self.timer=0;self.state=1
  if self.state==1:
   call(self.timer%20==0)
   if self.timer>=self.duration:
    self.timer=0;self.state=2
    if self.despawn_time==0:self.active=False;return calls
  if self.state==2:
   if not self.flags&1 and self.despawn_time>0:sx=f32((self.width-self.timer*self.width/self.despawn_time)/2)
   if self.timer<self.hitbox_end:call(False)
   if self.timer>=self.despawn_time:self.active=False;return calls
  if self.start>=640:self.active=False
  self.timer+=1;return calls
