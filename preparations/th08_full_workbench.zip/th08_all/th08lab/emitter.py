"""Fail-closed interpreter for *fresh-context scalar emitter slices*.
Not EnemyManager/ECL whole-runtime emulation. Stops at movement, ANM, effects,
entity creation, damage, EX, unknown external reads, unsupported opcodes.
Nominal shot requests only: no rank adjustment, form/distance suppression,
pool allocation, birth animation, collision or hidden RNG consumers.
"""
import math,struct,copy,hashlib,json
from .protocol import SCHEMA,VARS,IGNORED_PAYLOAD

def f32(x):return struct.unpack('<f',struct.pack('<f',x))[0]
PI=f32(math.pi);TAU=f32(2*PI)
def normalize(x):
    x=f32(x);counter=0
    if not math.isfinite(x):raise ValueError('nonfinite angle')
    while x>PI:
        x=f32(x-TAU);old=counter;counter+=1
        if old>16:break
    while x<-PI:
        x=f32(x+TAU);old=counter;counter+=1
        if old>16:break
    return x
def i32(x):return (int(x)+(1<<31))%(1<<32)-(1<<31)
class StopSlice(Exception):pass
class RNG:
    def __init__(self,seed):self.seed=seed;self.draws=0
    def u16(self):
        t=((self.seed^0x9630)-0x6553)&65535;self.seed=((t<<2)|(t>>14))&65535;self.draws+=1;return self.seed
    def u32(self):return (self.u16()<<16)|self.u16() # Explicit order, not a claim about VC7 evaluation order.
    def unit(self):return f32(f32(self.u32())/4294967296.0) # (f32)UINT_MAX rounds to 2^32
    def signed(self):return f32(f32(f32(self.u32())/2147483648.0)-1.0)
class Emitter:
    def __init__(self,ecl,sid,mask=8,externals=None,seed=None):
        self.ecl=ecl;self.root=sid;self.sid=sid;self.mask=mask
        self.ins={i['pc']:i for s in ecl['subs']for i in s['instructions']};self.pc=ecl['subs'][sid]['pc'];self.time=0;self.wait=0;self.tick=0
        self.vars={**{k:0 for k in range(10000,10032)},**{k:0 for k in range(10036,10040)},**{k:0 for k in range(10053,10069)},10094:0,10095:0}
        self.external=externals or {};self.reads=[];self.rng=RNG(seed)if seed is not None else None
        self.tf={};self.offset=[0.0,0.0];self.stack=[];self.events=[];self.executed=0;self.trace=set();self.done=False;self.why=None
    def get(self,k,typ):
        if k in self.external:
            a=self.external[k];v=a(self.tick)if callable(a) else a;self.reads.append(k)
        elif k in self.vars:v=self.vars[k]
        elif k in (10032,10033,10034,10035,10082) and self.rng:
            self.reads.append(k)
            if k==10032:v=self.rng.u32()&0x7fffffff
            elif k==10034:v=i32(self.rng.u32())
            elif k==10033:v=self.rng.unit()
            elif k==10035:v=self.rng.signed()
            else:v=f32(f32(self.rng.unit()*TAU)-PI)
        else:raise StopSlice('UNBOUND_EXTERNAL:'+VARS.get(k,str(k)))
        return f32(v) if typ=='f' else i32(v)
    def read(self,i,k,typ=None,resolve=True):
        if i['args'] is None:raise StopSlice('SCHEMA')
        s=SCHEMA[i['opcode']];v=i['args'][k];typ=typ or s[k]
        if resolve and i['flags']&(1<<k) and int(v)in VARS:v=self.get(int(v),typ)
        return f32(v)if typ=='f'else i32(v)
    def write(self,i,k,v,typ):
        key=int(i['args'][k])
        if not i['flags']&(1<<k)or key not in self.vars:raise StopSlice('UNSUPPORTED_LVALUE:'+str(key))
        self.vars[key]=f32(v)if typ=='f'else i32(v)
    def step(self,tick):
        self.tick=tick
        for _ in range(10000):
            if self.wait>0:self.wait-=1;self.time-=1;break
            if self.pc not in self.ins:raise StopSlice('PC_OUTSIDE')
            i=self.ins[self.pc];op=i['opcode']
            if op==-1:raise StopSlice('REACHED_SENTINEL')
            if i['time']!=self.time:break
            nxt=self.pc+i['size']
            if i['mask']&self.mask!=self.mask:self.pc=nxt;continue
            self.trace.add(self.pc);self.executed+=1
            if op in IGNORED_PAYLOAD and op not in(95,176):pass
            elif op in(1,53):
                if op==53 and self.stack:
                    self.sid,self.time,self.wait,nxt,saved=self.stack.pop();self.vars.update(saved)
                else:self.done=True;self.why='RETURNED_SLICE'if op==53 else'TERMINATED_SLICE';return
            elif op==2:self.wait=self.read(i,0)
            elif op in(4,5):
                take=True
                if op==5:
                    v=self.read(i,2)-1;self.write(i,2,v,'i');take=v>0
                if take:self.time=self.read(i,0,resolve=False);nxt=i['jump']
            elif op==52:
                sub=self.read(i,0,resolve=False)
                if not 0<=sub<len(self.ecl['subs']):raise StopSlice('INVALID_CALL')
                if len(self.stack)>=15:raise StopSlice('STACK_BOUND')
                local=[*range(10000,10008),*range(10016,10024),*range(10036,10040),*range(10053,10061),10094,10095]
                self.stack.append((self.sid,self.time,self.wait,nxt,{k:self.vars[k]for k in local}));self.sid=sub;self.time=0;self.wait=0;nxt=self.ecl['subs'][sub]['pc']
                for k in range(8):self.vars[10053+k]=self.vars[10061+k]
            elif 40<=op<=51:
                a=self.read(i,0);b=self.read(i,1);cmp=[a==b,a!=b,a<b,a<=b,a>b,a>=b][(op-40)//2]
                if cmp:self.time=self.read(i,2,resolve=False);nxt=i['jump']
            elif op in(6,7,8,9):
                typ='f' if op in(7,9)else'i';v=self.read(i,1,typ)
                if op in(8,9):
                    if not self.rng:raise StopSlice('UNBOUND_RNG_SIGN')
                    v*=1 if self.rng.u16()&1 else-1
                self.write(i,0,v,typ)
            elif 10<=op<=29:
                typ='i'if op<15 or 20<=op<25 else'f';k=(op-10)%5
                a=self.read(i,0 if op<20 else 1,typ);b=self.read(i,1 if op<20 else 2,typ)
                if k==0:v=a+b
                elif k==1:v=a-b
                elif k==2:v=a*b
                elif k==3:v=int(a/b)if typ=='i'else a/b
                else:v=a-int(a/b)*b if typ=='i'else math.fmod(a,b)
                self.write(i,0,v,typ)
            elif op in(30,31):self.write(i,0,self.read(i,0)+(1 if op==30 else-1),'i')
            elif op in(32,33):self.write(i,0,(math.sin if op==32 else math.cos)(self.read(i,1,'f')),'f')
            elif op==34:self.write(i,0,math.atan2(self.read(i,4)-self.read(i,2),self.read(i,3)-self.read(i,1)),'f')
            elif op==35:self.write(i,0,(self.read(i,1)-self.read(i,2))*self.read(i,3)+self.read(i,2),'f')
            elif op==37:
                x=self.read(i,0)
                if not math.isfinite(x)or abs(x)>1e8:raise StopSlice('UNBOUNDED_ANGLE')
                x=normalize(x)
                self.write(i,0,x,'f')
            elif op in(38,166):
                a=self.read(i,2);m=self.read(i,3);self.write(i,0,math.cos(a)*m,'f');self.write(i,1,math.sin(a)*m,'f')
            elif op==39:self.write(i,0,math.hypot(self.read(i,1)-self.read(i,3),self.read(i,2)-self.read(i,4)),'f')
            elif op==110:self.offset=[self.read(i,0),self.read(i,1)]
            elif op==111:
                v=[self.read(i,k)for k in range(7)]
                if not 0<=v[0]<18:raise StopSlice('TRANSFORM_SLOT')
                self.tf[v[0]]=v[1:]
            elif 96<=op<=104:
                v=[self.read(i,k)for k in range(9)]
                if not(0<=v[2]<=65535 and 0<=v[3]<=65535):raise StopSlice('SHOT_COUNT_RANGE')
                self.events.append(dict(tick=tick,local_time=self.time,sub=self.sid,pc=self.pc,opcode=op,args=v,offset=list(self.offset),transforms=copy.deepcopy(self.tf),requests=v[2]*v[3]))
                if len(self.events)>20000:raise StopSlice('EVENT_BOUND')
            else:raise StopSlice('UNSUPPORTED_OPCODE:'+i['op'])
            self.pc=nxt
        else:raise StopSlice('PER_TICK_INSTRUCTION_BOUND')
        self.time+=1
    def run(self,ticks):
        status='HORIZON_ONLY';reason=None
        try:
            for t in range(ticks):
                self.step(t)
                if self.done:status=self.why;break
        except (StopSlice,ZeroDivisionError,ValueError,OverflowError) as ex:status='BLOCKED';reason=str(ex)
        result=dict(file=self.ecl['file'],root_sub=self.root,mask=self.mask,status=status,reason=reason,ticks_requested=ticks,stop_tick=self.tick,stop_pc=self.pc,executed=self.executed,covered_sites=len(self.trace),emission_commands=len(self.events),nominal_requests=sum(e['requests']for e in self.events),external_reads=sorted(set(self.reads)),rng_draws=self.rng.draws if self.rng else 0,assumptions=['fresh zero context','fixed override per slice','unit logical time','shot DESCRIPTORS only, before rank/gates/allocation','no external actors/ANM/damage; execution stops at unsupported opcode'],events=self.events)
        result['event_hash']=hashlib.sha256(json.dumps(self.events,sort_keys=True,separators=(',',':')).encode()).hexdigest();return result
