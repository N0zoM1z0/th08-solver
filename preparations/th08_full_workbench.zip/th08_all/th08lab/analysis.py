"""Whole-corpus structural/semantic routing. No static site is called a live event.
A dossier is an analysis/implementation plan, never a solved full-spell policy.
"""
import struct,collections,hashlib,json
from .protocol import OP,EX,TRANSFORMS,DIFFS,ALIGN,ANM_NAMES

FEATURES={
 'aim_sample':('取样自机狙','搜索取样区域及离开方向；取样前的自主演化共享','让两条候选在取样时不同，核对实际发射角；已取样后共享须不含后续重瞄准'),
 'player_stream':('连续玩家变量依赖','先做状态切片；可线性/低维递推的块批量计算，不能默认冻结敌人','对不同历史但相同当前位置的候选比较未来；检查累积状态'),
 'rng':('随机数依赖','保存游戏随机相位与真实消耗顺序；允许共享已确定的弹，不共享未证明相同的后续随机发射','增减一次发射/擦弹/ANM随机调用，检查第一失配相位'),
 'alignment':('人妖/模式条件','把实际形态与过渡计数加入状态；比较门槛前切换的收益和伤害损失','跨模式边界测试7/8次消费以及单人固定形态；不得以按键替代实际isYoukai'),
 'distance_gate':('距离门槛','针对具体比较方向建条件分支；同时核对发射抑制后的随机消耗','在半径内/等于/外逐点测试；不要把所有门槛都当成贴近少弹'),
 'polar':('极坐标加减速','同程序/起始状态的批次共享逐帧演化；解析式只作候选与带误差界的预筛','测计时0/1/终止边界、负速、并发变换和float32舍入'),
 'vector':('向量加速','共享独立弹的递推并保留不同加速度阶段','核对负哨兵角/速度、倍率与持续时间'),
 'direction':('定时方向切换','以变换计时器切段，保留活动标志、重复次数与减速曲线','逐帧核对首次切换、下一次等待及到期帧'),
 'retarget':('再自机狙','按实际到期帧分桶；共享事件前轨迹，候选相关的事件后增量单独计算','制造不同边界到达时间，确认不是一整批共享同一取样'),
 'bounce':('边界反弹','逐阶段/逐轴保留比较和限次顺序，反弹后重新分组','测四角、精确等号、底边例外、bounceLimit=0及速度改写'),
 'wrap':('穿屏','把传送表示为离散映射，不以连接两端的线段作致死扫掠','测同帧双轴穿屏和宽阶段裁剪是否误删远端威胁'),
 'child_bullets':('弹生成子弹','按变换标志及两条payload联合解释；保留容量和本帧遍历次序','临近1536槽位上限测试分配成功/失败和同帧生成更新'),
 'bullet_lifecycle':('弹生命周期/判定变化','跟踪出生ANM、消失、取消免疫、换图尺寸、延迟剔除','贴图变化不等于判定变化；每种模板在首个致死帧做对照'),
 'laser':('普通激光','输出原版每次判定调用的局部矩形，而非渲染宽度近似','测STARTING→ACTIVE→DESPAWNING的fallthrough、0时长、头尾偏移'),
 'direct_laser':('EX直接激光','读取真正的角度所属VM及控制器阶段，不能只导出Laser池','对应ANM和ECL联合查角度演化；检查外矩形与擦弹内矩形'),
 'warp':('结界映射','分别实现窄/中/宽映射，事件前后安全区用真实位置','保留宽结界-32/-31.100006的不对称及2tick冷却'),
 'reisen':('铃仙碰撞开关','构造未来恢复碰撞时仍有出口的通道；其他弹仍按常规处理','核对初始ANM.type、marker和碰撞开关；透明度不得代替collidable'),
 'spawn_graph':('实体/使魔生成','以生成图和对象池生命周期为世界状态；尽早选择有利的生成/击破位置','子程序出生即执行；序号遍历可导致同帧再次推进'),
 'recursive':('递归实体生成','优先控制扩散源位置；相关分支保留RNG/继承上下文；严格限制在线预算','累计树节点数与同时存活量分开，测容量与门槛改变随机树'),
 'child_context':('子ECL并行上下文','每个上下文保存独立时钟、call栈、per-frame回调和插值槽','同时运行主/子上下文，核对先后顺序及冻结行为'),
 'remote':('远程/槽位调用','显式跟踪Boss槽、动态目标与所有共享call参数；未知目标阻断优化','同帧两个调用/空槽/负ID/动态ID；不得以全文件静态引用替代真目标'),
 'phase_damage':('生命/计时回调','击破时间为由合法射击实现的控制结果；把安全出口与下阶段入口连接','验证刚好过阈值、超时、同帧多伤害和转阶段清弹/无敌'),
 'clear':('清弹/清实体','把清除语义、道具生成、cancel免疫作为原版状态变换','测试被清除的对象、留下的子弹、随机数和道具副作用'),
 'time_control':('冻结/倍率/局部时钟','保留各子系统时钟，不能统一dt=0；对输入队列单独推进','测试停表/子帧/强制暂停/已有速度缩放并核对恢复帧'),
 'enemy_body':('敌人本体判定','沿所有CheckLethalCollision调用导出危险，不以敌弹池替代','77/78尺寸及79/80/81的取反语义；形态影响使魔可碰撞状态'),
 'trail':('敌人拖尾/特殊交互','导出拖尾实际检测段与条件；复杂对象不能只用头部位置','历史点、激活标志、清除、每段尺寸逐一核对'),
 'anm':('ANM参与逻辑','执行必要的动画状态机与随机消耗；只删除绘制提交，不删除逻辑','追踪VM角度/type/生死/中断、共享RNG、恢复中断后的PC'),
 'opaque':('未封闭依赖','保留原始参数并回退参考执行器，不允许静默忽略','缺字段、未知operand或动态目标必须返回UNSUPPORTED而不是SAFE')}
EX_FEATURE={0:['anm'],1:['anm'],2:['enemy_body'],3:['warp','anm'],4:['warp'],5:['warp','anm'],6:['warp','anm'],7:['warp'],8:['spawn_graph','enemy_body'],9:['direct_laser','anm'],10:['anm'],11:['direct_laser','anm'],12:['reisen','time_control','anm'],13:['anm'],14:['reisen','anm'],15:['anm'],16:['spawn_graph','child_context'],17:['anm'],18:['time_control'],19:['phase_damage'],20:['warp','anm'],21:['warp'],22:['phase_damage','clear','spawn_graph','anm'],23:['anm'],24:['phase_damage'],25:['direct_laser','anm'],26:['time_control'],27:['spawn_graph'],28:['time_control'],29:['time_control'],30:['anm'],31:['clear','rng']}

def flags_for(i):
    f=set();op=i['opcode'];ids={s['id']for s in i['selectors']}
    if op in (96,98,100,115,118) or 10048 in ids:f.add('aim_sample')
    if ids & {10045,10046,10047,10050} or op in (68,69,178):f.add('player_stream')
    if ids & {10032,10033,10034,10035,10082} or op in (8,9,67,102,103,104,106,169,178):f.add('rng')
    if 10097 in ids or i['mask']&0x60 not in(0,0x60):f.add('alignment')
    if op==82 or (10050 in ids and 40<=op<=51):f.add('distance_gate')
    if 114<=op<=121 or op in (154,167,170,171,172):f.add('laser')
    if op in (90,91,92,93,94):f.add('spawn_graph')
    if op==135:f.add('child_context')
    if op in(86,87,88,89,125,126):f.add('remote')
    if op in(129,130,131,132,133,134,153,155,177):f.add('phase_damage')
    if op in(95,112,161,162):f.add('clear')
    if op in(173,176,180,181,183):f.add('time_control')
    if op in(77,78,79,80,81):f.add('enemy_body')
    if op in(156,157):f.add('trail')
    if op in range(54,63) or op in(128,138,139,140,145,147,149,150,165,174,179,182):f.add('anm')
    if 'ex'in i:
        if i['ex']>=0:f.update(EX_FEATURE.get(i['ex'],['opaque']))
    if i['args'] is None and op not in(-1,122):f.add('opaque')
    if 'transform'in i:
        k=i['transform']['kind']
        for mask,tag in [(16,'vector'),(32,'polar'),(64|256,'direction'),(128,'retarget'),(1024|2048,'bounce'),(4194304|8388608,'wrap'),(16777216,'child_bullets'),(8192|16384|131072|262144,'bullet_lifecycle')]:
            if k&mask:f.add(tag)
    if 96<=op<=104 and i['args'] is not None:
        mask=int(i['args'][8])
        if mask&0x18000:f.add('alignment')
        if mask&0x1000:f.add('bullet_lifecycle')
    return f

def edge_for(i,n):
    op=i['opcode'];idx=None;kind=None
    if op==52:idx=0;kind='call'
    elif op in(90,91,92,93,94):idx=0;kind='spawn'
    elif op==135:idx=1;kind='child'
    elif op==130:idx=0;kind='death_transition'
    elif op==133:idx=2;kind='life_transition'
    elif op==134:idx=1;kind='timer_transition'
    elif op in(88,89):idx=1;kind='remote'
    elif op==126:idx=1;kind='slot_assignment'
    if idx is None:return None
    a=i['args']
    if a is None or idx>=len(a):return dict(kind=kind,target=None,reason='schema')
    raw=int(a[idx]);literal=op in(52,88) or not(i['flags']&(1<<idx))
    return dict(kind=kind,target=raw if literal and 0<=raw<n else None,raw_target=raw,reason=None if literal and 0<=raw<n else ('disabled' if raw<0 and literal else 'dynamic'))

def catalogue(ecls,anms):
    subrows=[];spellrows=[];oprows={k:dict(opcode=k,name=v,sites=0,files=set(),schemas=set(),features=set()) for k,v in OP.items() if k>=0}
    exrows={k:dict(id=k,name=v,sites=[],features=EX_FEATURE[k],reference_status='source reviewed; whole-engine equivalence unverified') for k,v in enumerate(EX)}
    trans=collections.defaultdict(list);summaries=[];graphs=[]
    for e in ecls:
        subs=e['subs'];local={};edges={};sites={};unknown={}
        for s in subs:
            fs=set();ed=[];counts=collections.Counter();un=[]
            for i in s['instructions']:
                if i['opcode']<0:continue
                fs.update(flags_for(i));counts[i['opcode']]+=1
                r=oprows[i['opcode']];r['sites']+=1;r['files'].add(e['file']);r['features'].update(flags_for(i));r['schemas'].add('typed' if i['args'] is not None or 'spell'in i else 'raw')
                if i['args'] is None and i['opcode']!=122:un.append(i['pc'])
                if 'ex'in i and 0<=i['ex']<32:exrows[i['ex']]['sites'].append(dict(file=e['file'],sub=s['id'],pc=i['pc'],mask=i['mask'],repeating=i['opcode']==137))
                if 'transform'in i:trans[i['transform']['kind']].append(dict(file=e['file'],sub=s['id'],pc=i['pc'],mask=i['mask'],**i['transform']))
                v=edge_for(i,len(subs))
                if v:ed.append(dict(pc=i['pc'],mask=i['mask'],**v))
            local[s['id']]=fs;edges[s['id']]=ed;sites[s['id']]=counts;unknown[s['id']]=un
        # Closure contains call/spawn/child only. Stage transitions are separate.
        def closure(root,mask):
            seen=set();stack=[root];unresolved=[]
            while stack:
                sid=stack.pop()
                if sid in seen:continue
                seen.add(sid)
                for x in edges[sid]:
                    if x['mask']&mask!=mask:continue
                    if x['target'] is None and x['reason']!='disabled':unresolved.append(dict(sub=sid,**x))
                    if x['kind'] in('call','spawn','child') and x['target'] is not None:stack.append(x['target'])
            return sorted(seen),unresolved
        for s in subs:
            sid=s['id'];row=dict(file=e['file'],sub=sid,pc=s['pc'],end=s['end'],instruction_count=sum(sites[sid].values()),features=sorted(local[sid]),opcodes=dict(sites[sid]),edges=edges[sid],schema_gaps=unknown[sid],status='STRUCTURAL_ONLY',whole_spell_solved=False)
            # Recursion analysis only follows instantiation edges, not ordinary loops.
            seen=set();stack=[x['target']for x in edges[sid] if x['target'] is not None and x['kind']=='spawn']
            while stack:
                v=stack.pop()
                if v==sid:row['features']=sorted(set(row['features'])|{'recursive'});local[sid].add('recursive');break
                if v in seen:continue
                seen.add(v);stack.extend(x['target']for x in edges[v]if x['target'] is not None and x['kind']=='spawn')
            subrows.append(row)
            for i in s['instructions']:
                if 'spell'not in i:continue
                variants={}
                for d,dm in DIFFS.items():
                    for align,am in ALIGN.items():
                        mask=dm|am
                        if i['mask']&mask!=mask:continue
                        reach,un=closure(sid,mask);active=[(r,j)for r in reach for j in subs[r]['instructions']if j['opcode']>=0 and j['mask']&mask==mask]
                        fs=set().union(*(flags_for(j)for r,j in active));fs|=set().union(*(local[r]&{'recursive'}for r in reach))
                        transitions=[dict(sub=r,**x)for r in reach for x in edges[r]if x['kind'].endswith('transition') and x['mask']&mask==mask]
                        specs=[dict(sub=r,pc=j['pc'],local_time=j['time'],opcode=j['opcode'],args=j['args'])for r,j in active if 96<=j['opcode']<=104]
                        exs=sorted(set(j['ex'] for r,j in active if 'ex'in j and j['ex']>=0))
                        tfs=sorted(set(j['transform']['kind']for r,j in active if 'transform'in j))
                        refs=collections.Counter(z['name']for r,j in active for z in j['selectors'])
                        variants[d+'/'+align]=dict(required_mask=mask,closure_subs=reach,static_sites=len(active),features=sorted(fs),unresolved_targets=un,transition_edges=transitions,shoot_sites=specs,ex_ids=exs,transform_record_kinds=tfs,selector_sites=dict(refs),status='ANALYZED_NOT_EXECUTED',strategy_modules=[dict(id=f,name=FEATURES[f][0],design=FEATURES[f][1],acceptance=FEATURES[f][2])for f in sorted(fs)],qualification='Uniform-override diagnostic view, NOT an actual phase scenario: real parents/children have different overrides and can switch. Mask-included syntactic closure. Not proof of entry reachability, temporal order, transform enablement, absence of outside entities, or full-world independence.')
                spellrows.append(dict(key=f"{e['file']}:s{sid}:pc{i['pc']:x}",file=e['file'],sub=sid,pc=i['pc'],mask=i['mask'],**i['spell'],variants=variants,status='NO_FULL_SPELL_SOLUTION',solution=None))
        graphs.append(dict(file=e['file'],edges=edges,timelines=e['timelines']))
        summaries.append(dict(file=e['file'],subroutines=len(subs),instructions=sum(sum(x.values())for x in sites.values()),jumps_validated=e['jumps_validated'],spell_records=sum('spell'in i for s in subs for i in s['instructions'])))
    anmrows=[]
    for a in anms:
        for s in a['scripts']:
            c=collections.Counter(i['opcode']for i in s['instructions']);f=[]
            if set(c)&{12,13,35}:f.append('rotation')
            if 25 in c:f.append('type_used_by_gameplay')
            if set(c)&{59,60}:f.append('rng')
            if set(c)&{1,2,20,23,89}:f.append('lifecycle_or_suspend')
            if set(c)&{4,5,*range(67,79),79}:f.append('control_flow')
            if 21 in c:f.append('interrupts')
            anmrows.append(dict(file=a['file'],script=s['index'],id=s['id'],pc=s['pc'],instructions=sum(c.values()),opcodes=dict(c),features=f,status='DECODED_NOT_EXECUTED'))
    for r in oprows.values():
        for k in ('files','schemas','features'):r[k]=sorted(r[k])
    return dict(summary=summaries,subroutines=subrows,spells=spellrows,graphs=graphs,opcodes=list(oprows.values()),ex=list(exrows.values()),transforms=[dict(kind=k,name=TRANSFORMS.get(k,'UNKNOWN_COMPOSITE'),sites=v,status='record observed; runtime enabling flags must be checked')for k,v in sorted(trans.items())],anm_scripts=anmrows)
