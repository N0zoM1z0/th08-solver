"""Source-guided isolated bullet pool. Unit multiplier; no external game systems.
Not a TH08 world emulator. Inputs are nominal emitter descriptors under a fixed
origin/owner context. No damage, rank changes, graze RNG, items, ECL EX, or lasers.
Candidate-dependent aiming is rejected unless an explicit target trajectory is
supplied. The fixture is therefore never evidence of a full-spell clear.
"""
import math,struct,copy
from types import SimpleNamespace
from .emitter import f32,RNG,normalize
PI=f32(math.pi); TAU=f32(2*PI)
class UnsupportedWorld(Exception):pass

def norm(x):
    if not math.isfinite(x)or abs(x)>1e6:raise UnsupportedWorld('unbounded angle')
    return normalize(x)

def vector(a,s):return [f32(math.cos(a)*s),f32(math.sin(a)*s)]

def within(p,w,h):return not(w/2+p[0]<0 or p[0]-w/2>384 or h/2+p[1]<0 or p[1]-h/2>448)

SCRIPTS=[[0,18,19,20,15]]+[[k,21,22,23,16]for k in range(1,7)]+[[k,24,24,24,17]for k in range(7,10)]+[[25,27,27,27,26]]+[[k,21,22,23,16]for k in range(106,109)]+[[k,24,24,24,17]for k in range(109,111)]+[[k,21,22,23,16]for k in range(111,113)]+[[k,24,24,24,17]for k in range(113,116)]

def templates(anm):
    out=[]
    for k,row in enumerate(SCRIPTS):
        s=anm['scripts'][row[0]];sprite=next(struct.unpack('<i',bytes.fromhex(i['raw']))[0]for i in s['instructions']if i['opcode']==3)
        sp=anm['sprites'][sprite];h=sp['height'];sid=row[0]
        size=4 if h<=8 else (4 if sid in(2,111,112,4,6,5,106,107,108)else 6)if h<=16 else(5 if sid in(8,113,114,115)else 8 if sid in(9,109,110)else 10)if h<=32 else 24
        ends=[]
        for index in row[1:]:
            ins=anm['scripts'][index]['instructions']
            # Audited template scripts: straight-line visual updates, ending in Delete.
            if any(i['opcode']in(4,5,20,21,59,60,79,89)for i in ins[:next(j for j,i in enumerate(ins)if i['opcode']==1)]):raise UnsupportedWorld('spawn ANM control flow')
            ends.append(next(i['time']for i in ins if i['opcode']==1))
        out.append(dict(type=k,script=sid,sprite=sprite,width=sp['width'],height=h,size=size,ends=ends))
    return out

class Bullet:
    def __init__(self,w,p,angle,speed,typ,color,flags,tf,start):
        self.w=w;self.p=list(p);self.angle=norm(angle);self.speed=f32(speed);self.v=vector(angle,speed)
        self.typ=typ;self.color=color;self.flags=flags;self.tf=tf;self.idx=start;self.active=0;self.ex={};self.cull=0;self.offscreen=0;self.age=0;self.disabled=False
        self.state='fired';self.spawn_kind=0;self.anm_time=1;self.fade_time=1
        self.template=w.templates[typ]
        if flags&14:
            self.spawn_kind=0 if flags&2 else 1 if flags&4 else 2;self.state='spawn'
            self.p=[f32(self.p[j]-f32(self.v[j]*4))for j in range(2)]
        self.advance()
    def target_angle(self):
        if self.w.target is None:raise UnsupportedWorld('candidate-dependent retarget')
        p=self.w.target(self.w.tick);return math.atan2(p[1]-self.p[1],p[0]-self.p[0])
    def advance(self):
        for _ in range(19):
            if self.idx>=18:return
            r=self.tf.get(self.idx)
            if not r or not r[0]:return
            kind,concurrent,i0,i1,a,b=r
            if not concurrent and self.active:return
            if not self.flags&kind:self.idx+=1;continue
            self.idx+=1
            if kind==1:self.active|=kind;self.ex['decel']=0
            elif kind==16:self.active|=kind;self.ex['vector']=[0,i0,vector(b if b>-990 else self.angle,a)]
            elif kind==32:self.active|=kind;self.ex['polar']=[0,i0,a,b]
            elif kind in(64,128,256):
                if kind==128 and self.w.target is None:raise UnsupportedWorld('candidate-dependent retarget')
                self.active|=kind;self.ex['direction']=[0,i0,i1,0,a,b if b>-999 else self.speed]
            elif kind in(1024,2048):self.active|=kind;self.ex['bounce']=[i0,0,a if a>=0 else self.speed]
            elif kind in(4194304,8388608):self.active|=kind;self.ex['wrap']=i0
            elif kind==131072:self.active|=kind;self.ex['wait']=i0
            elif kind==8192:self.cull=i0;continue
            elif kind==16384:
                if not 0<=i0<21:raise UnsupportedWorld('sprite template index')
                self.typ=i0;self.color=i1;self.template=self.w.templates[i0];continue
            elif kind==262144:self.state='fade'
            elif kind==524288:continue # sound has no RNG in this isolated kinematic contract
            elif kind==16777216:
                nxt=self.tf.get(self.idx)
                if not nxt:raise UnsupportedWorld('missing child-secondary payload')
                _,_,count2,flags,angle,step=nxt;packed=i0&0xffffffff
                if self.w.target is None and (packed>>24)&127 in(0,2,4):raise UnsupportedWorld('aimed child pattern')
                self.idx+=1
                self.w.spawn_pattern(dict(args=[(packed>>16)&255,(packed>>8)&255,i1,count2,a,b,angle,step,flags],opcode=96+((packed>>24)&127),transforms=self.tf,offset=[0,0]),self.p,packed&255)
                if packed&0x80000000:self.state='fade'
                else:continue
            else:raise UnsupportedWorld('unimplemented active transform '+hex(kind))
            return
        raise UnsupportedWorld('transform dispatch bound')
    def step(self):
        if self.state=='dead':return False
        if self.state=='fade':
            self.p=[f32(self.p[j]+f32(self.v[j]/2))for j in range(2)];self.fade_time+=1
            if self.fade_time>self.template['ends'][3]:self.state='dead'
            return False
        if self.state=='spawn':
            div=(2,2.5,3)[self.spawn_kind];self.p=[f32(self.p[j]+f32(self.v[j]/div))for j in range(2)]
            if self.anm_time<self.template['ends'][self.spawn_kind]:self.anm_time+=1;return False
            self.state='fired';self.age=0
        self.advance()
        if self.active&1:
            t=self.ex['decel']
            if t<=16:self.v=vector(self.angle,f32(f32(5-f32(t*5/16))+self.speed))
            else:self.active^=1
            self.ex['decel']=t+1
        if self.active&16:
            s=self.ex['vector'];t,d,v=s
            if t>=d:self.active&=~16
            else:
                self.v=[f32(self.v[j]+v[j])for j in range(2)]
                if abs(self.v[0])>.0001 or abs(self.v[1])>.0001:self.angle=f32(math.atan2(self.v[1],self.v[0]))
            s[0]+=1
        if self.active&32:
            s=self.ex['polar'];t,d,ds,da=s
            if t>=d:self.active&=~32
            else:self.angle=norm(self.angle+da);self.speed=f32(self.speed+ds);self.v=vector(self.angle,self.speed)
            s[0]+=1
        for flag in(64,256,128):
            if self.active&flag:
                s=self.ex['direction'];t,interval,repeats,completed,a,speed=s
                if t>=interval:
                    s[3]+=1
                    if s[3]>=repeats:self.active&=~flag
                    self.angle=f32(self.angle+a)if flag==64 else a if flag==256 else norm(self.target_angle()+a)
                    self.speed=speed;mag=speed;s[0]=0
                else:mag=f32(self.speed-f32(f32(t*self.speed)/interval))
                self.v=vector(self.angle,mag);s[0]+=1
        if self.active&3072 and not within(self.p,self.template['width'],self.template['height']):
            if self.p[0]<0 or self.p[0]>=384:self.angle=norm(-self.angle-PI)
            if self.p[1]<0 or(self.p[1]>=448 and self.active&1024):self.angle=-self.angle
            s=self.ex['bounce'];self.speed=s[2];self.v=vector(self.angle,self.speed);s[1]+=1
            if s[1]>=s[0]:self.active&=~3072
        for flag,axis,span in((4194304,0,384),(8388608,1,448)):
            if self.active&flag:
                if self.p[axis]<0:self.p[axis]=f32(self.p[axis]+span)
                elif self.p[axis]>span:self.p[axis]=f32(self.p[axis]-span)
                if self.ex['wrap']<=0:self.active^=flag
                else:self.ex['wrap']-=1
        if self.active&131072:
            if self.ex['wait']<=0:self.active^=131072
            else:self.ex['wait']-=1
        if self.cull:self.cull-=1
        self.p=[f32(self.p[j]+self.v[j])for j in range(2)]
        if not self.cull:
            if not within(self.p,self.template['width'],self.template['height']):
                if self.active&(64|128|256|1024|2048):
                    self.offscreen+=1
                    if self.offscreen>=128:self.state='dead';return False
                elif self.offscreen==0:self.state='dead';return False
                else:self.offscreen-=1
            else:self.offscreen=0
        self.age+=1
        return not self.disabled # this frame entered the FIRED path even if advance changed its state

class World:
    def __init__(self,templates,origin=(192,128),target=None,seed=None,capacity=1536):
        self.templates=templates;self.origin=origin;self.target=target;self.rng=RNG(seed)if seed is not None else None
        self.pool=[None]*capacity;self.cursor=0;self.tick=0;self.requests=0;self.spawned=0;self.dropped=0;self.max_live=0;self.in_tick=0;self.active_count=0;self.attempts=0
    def spawn_pattern(self,event,origin=None,start=0):
        typ,col,n1,n2,s1,s2,base,step,flags=event['args'];flags&=0xffffffff;mode=event['opcode']-96
        if not 0<=typ<21 or n1<0 or n2<0 or n1*n2>100000:raise UnsupportedWorld('pattern bounds')
        if flags&0x18000:raise UnsupportedWorld('form-gated owner context omitted')
        if mode in(0,2,4)and self.target is None:raise UnsupportedWorld('candidate-dependent firing')
        if mode in(6,7,8)and not self.rng:raise UnsupportedWorld('unbound random pattern')
        if not 0<=mode<=8:raise UnsupportedWorld('aim mode')
        self.requests+=n1*n2
        if self.active_count>=len(self.pool):self.dropped+=n1*n2;return
        off=event.get('offset',[0,0]);o=origin or self.origin;p=[f32(o[j]+off[j])for j in range(2)]
        aim=math.atan2(self.target(self.tick)[1]-p[1],self.target(self.tick)[0]-p[0])if mode in(0,2,4)else 0
        tf={int(k):v for k,v in event.get('transforms',{}).items()}
        for j in range(n2):
            for i in range(n1):
                self.attempts+=1;self.in_tick+=1
                if self.in_tick>30000:raise UnsupportedWorld('spawn work cap')
                slot=None
                for k in range(len(self.pool)):
                    ix=(self.cursor+k)%len(self.pool);b=self.pool[ix]
                    if b is None or b.state=='dead':slot=ix;break
                if slot is None:self.dropped+=(n2-j-1)*n1+(n1-i);return
                speed=f32(s1-f32(f32(s1-s2)*j)/n2)if n2>1 else s1
                if mode in(0,1):
                    a=f32(((i+1)//2)*step)if n1&1 else f32((i//2)*step+step*.5)
                    if i&1:a=-a
                    a=f32(f32(a+aim)+base)
                elif mode in(2,3,7):a=f32(f32(aim+f32(i*TAU/n1))+f32(j*step+base))
                elif mode in(4,5):a=f32(f32(f32(aim+PI/n1)+f32(i*TAU/n1))+base)
                else:a=f32(f32(self.rng.unit()*f32(base-step))+step)
                if mode in(7,8):speed=f32(f32(self.rng.unit()*f32(s1-s2))+s2)
                # Reserve before constructor because transforms may recursively allocate.
                placeholder=SimpleNamespace(state="constructing");self.pool[slot]=placeholder
                try:b=Bullet(self,p,a,speed,typ,col,flags,tf,start)
                except Exception:self.pool[slot]=None;raise
                self.pool[slot]=b;self.cursor=(slot+1)%len(self.pool);self.spawned+=1
    def step(self,events):
        self.in_tick=0
        for e in events:self.spawn_pattern(e)
        boxes=[];self.active_count=0
        for idx in [0]+list(range(len(self.pool)-1,0,-1)):
            b=self.pool[idx]
            if b is not None and b.state!='dead':self.active_count+=1
            if b is not None and b.step():boxes.append([b.p[0],b.p[1],b.template['size']/2,b.template['size']/2])
        self.max_live=max(self.max_live,sum(b is not None and b.state!='dead'for b in self.pool));self.tick+=1;return boxes
