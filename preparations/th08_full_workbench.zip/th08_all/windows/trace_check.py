#!/usr/bin/env python3
import sys,json,argparse
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from th08lab.trace import read,first_difference,audit
p=argparse.ArgumentParser();p.add_argument('trace',type=Path);p.add_argument('--reference',type=Path);p.add_argument('--float-tolerance',type=float,default=0.);a=p.parse_args()
try:
 rows=read(a.trace);r=audit(rows)
 if a.reference:
  r['first_difference']=first_difference(read(a.reference),rows,a.float_tolerance)
  r['matching_records']=r['first_difference']is None
 print(json.dumps(r,ensure_ascii=False,indent=2));sys.exit(1 if r.get('first_difference')else 0)
except (OSError,KeyError,ValueError,TypeError)as ex:print('ERROR:',ex,file=sys.stderr);sys.exit(2)
