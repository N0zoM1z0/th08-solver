#!/usr/bin/env python3
"""Export only input records from the user's embedded demos; does not play them."""
import sys,json,argparse,csv
from pathlib import Path
R=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--out',type=Path,default=R/'build/demo_inputs');a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
for r in json.loads((R/'reports/embedded_replays.json').read_text()):
 for s in r['stage_records']:
  dest=a.out/f'{Path(r["file"]).stem}_stage{s["stage_index"]}.csv'
  with dest.open('w',newline='')as f:
   w=csv.writer(f);w.writerow(['serialized_record_index','input_mask']);w.writerows(enumerate(s['inputs']))
  meta={k:v for k,v in s.items()if k!='inputs'};meta.update(difficulty=r['difficulty'],shot_type=r['shot_type'],raw_input_only=True,execution_contract='Use the original replay loader for exact stage setup; these CSV records are NOT wall-clock-timed keyboard commands.')
  dest.with_suffix('.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2));print(dest)
