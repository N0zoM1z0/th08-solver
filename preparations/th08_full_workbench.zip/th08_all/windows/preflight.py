#!/usr/bin/env python3
"""Read-only identity check. Does not launch, attach to, patch, or control a game."""
import argparse,hashlib,json,struct,subprocess,sys
from pathlib import Path
DAT='9d7edf43b8ddd347cbb641836f6b5050745dd936f688daebbf9382ca557043bb'
EXE='330fbdbf58a710829d65277b4f312cfbb38d5448b3df523e79350b879213d924'
HEAD='a45e99fb1942714e6edded20847e32a654d56f97'
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
 return h.hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--dat',required=True,type=Path);ap.add_argument('--exe',type=Path);ap.add_argument('--source',type=Path);a=ap.parse_args()
 result=dict(dat_sha256=sha(a.dat),dat_matches=False,original_game_tested=False)
 result['dat_matches']=result['dat_sha256']==DAT;ok=result['dat_matches']
 if a.exe:
  result['exe_sha256']=sha(a.exe);result['exe_matches']=result['exe_sha256']==EXE;ok &= result['exe_matches']
  with a.exe.open('rb')as f:
   h=f.read(64)
   if len(h)<64 or h[:2]!=b'MZ':raise ValueError('Not a PE executable')
   f.seek(struct.unpack_from('<I',h,60)[0]);pe=f.read(6)
   if pe[:4]!=b'PE\0\0':raise ValueError('PE signature')
   result['pe_machine']=hex(struct.unpack_from('<H',pe,4)[0])
 if a.source:
  g=subprocess.run(['git','-C',str(a.source),'rev-parse','HEAD'],check=True,capture_output=True,text=True)
  result['source_head']=g.stdout.strip();result['source_matches']=result['source_head']==HEAD;ok &= result['source_matches']
  result['source_dirty']=bool(subprocess.run(['git','-C',str(a.source),'status','--porcelain'],check=True,capture_output=True,text=True).stdout)
  ok &= not result['source_dirty']
 result['identity_check_passed']=bool(ok);result['meaning']='Matching identity is not a runtime or NMNB verification.'
 print(json.dumps(result,ensure_ascii=False,indent=2));return 0 if ok else 2
if __name__=='__main__':
 try:sys.exit(main())
 except (OSError,ValueError,subprocess.SubprocessError)as e:print(str(e),file=sys.stderr);sys.exit(2)
