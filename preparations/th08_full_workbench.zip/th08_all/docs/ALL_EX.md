# 全部 32 个 EX 回调

站点是语法观察；本文件的验收规格尚不等于完整游戏实现。

## EX 0: ConfigureNightBlindness
资源站点 16 个。

ANM参与逻辑：执行必要的动画状态机与随机消耗；只删除绘制提交，不删除逻辑。 验收：追踪VM角度/type/生死/中断、共享RNG、恢复中断后的PC。

```text
ecldata2.ecl sub50 0x742c mask=0xff repeating=False
ecldata2.ecl sub50 0x746c mask=0xff repeating=False
ecldata2.ecl sub56 0x8360 mask=0xff repeating=False
ecldata2.ecl sub56 0x8450 mask=0xff repeating=False
ecldata2.ecl sub57 0x84e8 mask=0xff repeating=False
ecldata2.ecl sub60 0x9008 mask=0xff repeating=False
ecldata2.ecl sub60 0x90cc mask=0xff repeating=False
ecldata2sp.ecl sub34 0x584c mask=0xff repeating=False
ecldata2sp.ecl sub34 0x588c mask=0xff repeating=False
ecldata2sp.ecl sub40 0x6780 mask=0xff repeating=False
ecldata2sp.ecl sub40 0x6870 mask=0xff repeating=False
ecldata2sp.ecl sub41 0x6908 mask=0xff repeating=False
ecldata2sp.ecl sub44 0x7428 mask=0xff repeating=False
ecldata2sp.ecl sub44 0x74ec mask=0xff repeating=False
ecldata2sp.ecl sub47 0x7b3c mask=0xff repeating=False
ecldata2sp.ecl sub47 0x7ba8 mask=0xff repeating=False
```

## EX 1: TriggerShortScreenPulse
资源站点 7 个。

ANM参与逻辑：执行必要的动画状态机与随机消耗；只删除绘制提交，不删除逻辑。 验收：追踪VM角度/type/生死/中断、共享RNG、恢复中断后的PC。

```text
ecldata2.ecl sub44 0x6b00 mask=0xff repeating=False
ecldata2.ecl sub52 0x7c00 mask=0xff repeating=False
ecldata2.ecl sub58 0x88cc mask=0xff repeating=False
ecldata2sp.ecl sub28 0x4f20 mask=0xff repeating=False
ecldata2sp.ecl sub36 0x6020 mask=0xff repeating=False
ecldata2sp.ecl sub42 0x6cec mask=0xff repeating=False
ecldata2sp.ecl sub46 0x7a50 mask=0xff repeating=False
```

## EX 2: UpdateBouncingEnemyMotion
资源站点 6 个。

敌人本体判定：沿所有CheckLethalCollision调用导出危险，不以敌弹池替代。 验收：77/78尺寸及79/80/81的取反语义；形态影响使魔可碰撞状态。

```text
ecldata4a.ecl sub18 0x2120 mask=0xff repeating=True
ecldata4a.ecl sub20 0x2b18 mask=0xff repeating=True
ecldata4a.ecl sub38 0x6c5c mask=0xff repeating=True
ecldata4asp.ecl sub3 0xd38 mask=0xff repeating=True
ecldata4asp.ecl sub5 0x1730 mask=0xff repeating=True
ecldata4asp.ecl sub23 0x5874 mask=0xff repeating=True
```

## EX 3: StartNarrowBulletWarpBarrier
资源站点 2 个。

结界映射：分别实现窄/中/宽映射，事件前后安全区用真实位置。 验收：保留宽结界-32/-31.100006的不对称及2tick冷却。

ANM参与逻辑：执行必要的动画状态机与随机消耗；只删除绘制提交，不删除逻辑。 验收：追踪VM角度/type/生死/中断、共享RNG、恢复中断后的PC。

```text
ecldata4a.ecl sub28 0x4724 mask=0xf3 repeating=False
ecldata4asp.ecl sub13 0x333c mask=0xf3 repeating=False
```

## EX 4: WarpBulletsAcrossNarrowBarrier
资源站点 2 个。

结界映射：分别实现窄/中/宽映射，事件前后安全区用真实位置。 验收：保留宽结界-32/-31.100006的不对称及2tick冷却。

```text
ecldata4a.ecl sub28 0x4738 mask=0xf3 repeating=True
ecldata4asp.ecl sub13 0x3350 mask=0xf3 repeating=True
```

## EX 5: StopBulletWarpBarrier
资源站点 17 个。

结界映射：分别实现窄/中/宽映射，事件前后安全区用真实位置。 验收：保留宽结界-32/-31.100006的不对称及2tick冷却。

ANM参与逻辑：执行必要的动画状态机与随机消耗；只删除绘制提交，不删除逻辑。 验收：追踪VM角度/type/生死/中断、共享RNG、恢复中断后的PC。

```text
ecldata4a.ecl sub17 0x1734 mask=0xff repeating=False
ecldata4a.ecl sub19 0x2178 mask=0xff repeating=False
ecldata4a.ecl sub25 0x2e6c mask=0xff repeating=False
ecldata4a.ecl sub26 0x3704 mask=0xff repeating=False
ecldata4a.ecl sub53 0x8c00 mask=0xff repeating=False
ecldata4asp.ecl sub2 0x34c mask=0xff repeating=False
ecldata4asp.ecl sub4 0xd90 mask=0xff repeating=False
ecldata4asp.ecl sub10 0x1a84 mask=0xff repeating=False
ecldata4asp.ecl sub11 0x231c mask=0xff repeating=False
ecldata4asp.ecl sub38 0x7818 mask=0xff repeating=False
ecldata4asp.ecl sub51 0x9ee4 mask=0xff repeating=False
ecldata4b.ecl sub17 0x1778 mask=0xff repeating=False
ecldata4b.ecl sub22 0x2480 mask=0xff repeating=False
ecldata4b.ecl sub28 0x2f5c mask=0xff repeating=False
ecldata4bsp.ecl sub2 0x39c mask=0xff repeating=False
ecldata4bsp.ecl sub7 0x10a4 mask=0xff repeating=False
ecldata4bsp.ecl sub13 0x1b80 mask=0xff repeating=False
```

## EX 6: StartWideBulletWarpBarrier
资源站点 2 个。

结界映射：分别实现窄/中/宽映射，事件前后安全区用真实位置。 验收：保留宽结界-32/-31.100006的不对称及2tick冷却。

ANM参与逻辑：执行必要的动画状态机与随机消耗；只删除绘制提交，不删除逻辑。 验收：追踪VM角度/type/生死/中断、共享RNG、恢复中断后的PC。

```text
ecldata4a.ecl sub46 0x81dc mask=0xff repeating=False
ecldata4asp.ecl sub31 0x6df4 mask=0xff repeating=False
```

## EX 7: WarpBulletsAcrossWideBarrier
资源站点 2 个。

结界映射：分别实现窄/中/宽映射，事件前后安全区用真实位置。 验收：保留宽结界-32/-31.100006的不对称及2tick冷却。

```text
ecldata4a.ecl sub46 0x81f0 mask=0xff repeating=True
ecldata4asp.ecl sub31 0x6e08 mask=0xff repeating=True
```

## EX 8: SynchronizeOrbitingChildFormation
资源站点 14 个。

实体/使魔生成：以生成图和对象池生命周期为世界状态；尽早选择有利的生成/击破位置。 验收：子程序出生即执行；序号遍历可导致同帧再次推进。

敌人本体判定：沿所有CheckLethalCollision调用导出危险，不以敌弹池替代。 验收：77/78尺寸及79/80/81的取反语义；形态影响使魔可碰撞状态。

```text
ecldata4b.ecl sub21 0x23bc mask=0xff repeating=True
ecldata4b.ecl sub24 0x2c8c mask=0xff repeating=True
ecldata4b.ecl sub30 0x3738 mask=0xff repeating=True
ecldata4b.ecl sub33 0x3f20 mask=0xff repeating=True
ecldata4b.ecl sub40 0x5328 mask=0xff repeating=True
ecldata4b.ecl sub46 0x60c0 mask=0xff repeating=True
ecldata4b.ecl sub52 0x76c0 mask=0xff repeating=True
ecldata4bsp.ecl sub6 0xfe0 mask=0xff repeating=True
ecldata4bsp.ecl sub9 0x18b0 mask=0xff repeating=True
ecldata4bsp.ecl sub15 0x235c mask=0xff repeating=True
ecldata4bsp.ecl sub18 0x2b44 mask=0xff repeating=True
ecldata4bsp.ecl sub25 0x3f4c mask=0xff repeating=True
ecldata4bsp.ecl sub31 0x4ce4 mask=0xff repeating=True
ecldata4bsp.ecl sub37 0x62e4 mask=0xff repeating=True
```

## EX 9: UpdateNarrowRotatingLaserHitbox
资源站点 2 个。

EX直接激光：读取真正的角度所属VM及控制器阶段，不能只导出Laser池。 验收：对应ANM和ECL联合查角度演化；检查外矩形与擦弹内矩形。

ANM参与逻辑：执行必要的动画状态机与随机消耗；只删除绘制提交，不删除逻辑。 验收：追踪VM角度/type/生死/中断、共享RNG、恢复中断后的PC。

```text
ecldata4b.ecl sub57 0x87a4 mask=0xff repeating=True
ecldata4bsp.ecl sub42 0x73c8 mask=0xff repeating=True
```

## EX 10: TriggerScreenPulseAndShake
资源站点 10 个。

ANM参与逻辑：执行必要的动画状态机与随机消耗；只删除绘制提交，不删除逻辑。 验收：追踪VM角度/type/生死/中断、共享RNG、恢复中断后的PC。

```text
ecldata4b.ecl sub55 0x7f58 mask=0xff repeating=False
ecldata4b.ecl sub55 0x8234 mask=0xff repeating=False
ecldata4b.ecl sub67 0xa3ec mask=0xff repeating=False
ecldata4b.ecl sub67 0xa58c mask=0xff repeating=False
ecldata4bsp.ecl sub40 0x6b7c mask=0xff repeating=False
ecldata4bsp.ecl sub40 0x6e58 mask=0xff repeating=False
ecldata4bsp.ecl sub52 0x9010 mask=0xff repeating=False
ecldata4bsp.ecl sub52 0x91b0 mask=0xff repeating=False
ecldata4bsp.ecl sub60 0xa7f4 mask=0xff repeating=False
ecldata4bsp.ecl sub60 0xa9bc mask=0xff repeating=False
```

## EX 11: UpdateMediumRotatingLaserHitbox
资源站点 2 个。

EX直接激光：读取真正的角度所属VM及控制器阶段，不能只导出Laser池。 验收：对应ANM和ECL联合查角度演化；检查外矩形与擦弹内矩形。

ANM参与逻辑：执行必要的动画状态机与随机消耗；只删除绘制提交，不删除逻辑。 验收：追踪VM角度/type/生死/中断、共享RNG、恢复中断后的PC。

```text
ecldata4b.ecl sub70 0xaa4c mask=0xff repeating=True
ecldata4bsp.ecl sub55 0x9670 mask=0xff repeating=True
```

## EX 12: ReisenFreezeBullets
资源站点 36 个。

铃仙碰撞开关：构造未来恢复碰撞时仍有出口的通道；其他弹仍按常规处理。 验收：核对初始ANM.type、marker和碰撞开关；透明度不得代替collidable。

冻结/倍率/局部时钟：保留各子系统时钟，不能统一dt=0；对输入队列单独推进。 验收：测试停表/子帧/强制暂停/已有速度缩放并核对恢复帧。

ANM参与逻辑：执行必要的动画状态机与随机消耗；只删除绘制提交，不删除逻辑。 验收：追踪VM角度/type/生死/中断、共享RNG、恢复中断后的PC。

```text
ecldata5.ecl sub62 0x6588 mask=0xff repeating=False
ecldata5.ecl sub62 0x65c4 mask=0xff repeating=False
ecldata5.ecl sub62 0x6600 mask=0xff repeating=False
ecldata5.ecl sub62 0x6628 mask=0xff repeating=False
ecldata5.ecl sub63 0x6f70 mask=0xff repeating=False
ecldata5.ecl sub63 0x6fac mask=0xff repeating=False
ecldata5.ecl sub66 0x77a4 mask=0xff repeating=False
ecldata5.ecl sub66 0x77e0 mask=0xff repeating=False
ecldata5.ecl sub66 0x7830 mask=0xff repeating=False
ecldata5.ecl sub66 0x7858 mask=0xff repeating=False
ecldata5.ecl sub78 0x8dc8 mask=0xff repeating=False
ecldata5.ecl sub78 0x8e04 mask=0xff repeating=False
ecldata5.ecl sub78 0x8e54 mask=0xff repeating=False
ecldata5.ecl sub78 0x8e7c mask=0xff repeating=False
ecldata5.ecl sub78 0x8f5c mask=0xff repeating=False
ecldata5.ecl sub78 0x8f98 mask=0xff repeating=False
ecldata5.ecl sub78 0x8fe8 mask=0xff repeating=False
ecldata5.ecl sub78 0x9010 mask=0xff repeating=False
ecldata5sp.ecl sub15 0x1bd4 mask=0xff repeating=False
ecldata5sp.ecl sub15 0x1c10 mask=0xff repeating=False
ecldata5sp.ecl sub15 0x1c4c mask=0xff repeating=False
ecldata5sp.ecl sub15 0x1c74 mask=0xff repeating=False
ecldata5sp.ecl sub16 0x25bc mask=0xff repeating=False
ecldata5sp.ecl sub16 0x25f8 mask=0xff repeating=False
ecldata5sp.ecl sub19 0x2df0 mask=0xff repeating=False
ecldata5sp.ecl sub19 0x2e2c mask=0xff repeating=False
ecldata5sp.ecl sub19 0x2e7c mask=0xff repeating=False
ecldata5sp.ecl sub19 0x2ea4 mask=0xff repeating=False
ecldata5sp.ecl sub31 0x4414 mask=0xff repeating=False
ecldata5sp.ecl sub31 0x4450 mask=0xff repeating=False
ecldata5sp.ecl sub31 0x44a0 mask=0xff repeating=False
ecldata5sp.ecl sub31 0x44c8 mask=0xff repeating=False
ecldata5sp.ecl sub31 0x45a8 mask=0xff repeating=False
ecldata5sp.ecl sub31 0x45e4 mask=0xff repeating=False
ecldata5sp.ecl sub31 0x4634 mask=0xff repeating=False
ecldata5sp.ecl sub31 0x465c mask=0xff repeating=False
```

## EX 13: ApplyRedBackgroundTint
资源站点 4 个。

ANM参与逻辑：执行必要的动画状态机与随机消耗；只删除绘制提交，不删除逻辑。 验收：追踪VM角度/type/生死/中断、共享RNG、恢复中断后的PC。

```text
ecldata5.ecl sub85 0x98a0 mask=0xff repeating=True
ecldata5sp.ecl sub38 0x4eec mask=0xff repeating=True
ecldata6.ecl sub86 0xc63c mask=0xff repeating=True
ecldata6sp.ecl sub74 0xb8c0 mask=0xff repeating=True
```

## EX 14: AdvanceReisenBulletPhase
资源站点 18 个。

铃仙碰撞开关：构造未来恢复碰撞时仍有出口的通道；其他弹仍按常规处理。 验收：核对初始ANM.type、marker和碰撞开关；透明度不得代替collidable。

ANM参与逻辑：执行必要的动画状态机与随机消耗；只删除绘制提交，不删除逻辑。 验收：追踪VM角度/type/生死/中断、共享RNG、恢复中断后的PC。

```text
ecldata5.ecl sub75 0x84dc mask=0xff repeating=False
ecldata5.ecl sub75 0x8518 mask=0xff repeating=False
ecldata5.ecl sub75 0x8540 mask=0xff repeating=False
ecldata5.ecl sub75 0x8568 mask=0xff repeating=False
ecldata5.ecl sub75 0x85a4 mask=0xff repeating=False
ecldata5.ecl sub75 0x85cc mask=0xff repeating=False
ecldata5sp.ecl sub28 0x3b28 mask=0xff repeating=False
ecldata5sp.ecl sub28 0x3b64 mask=0xff repeating=False
ecldata5sp.ecl sub28 0x3b8c mask=0xff repeating=False
ecldata5sp.ecl sub28 0x3bb4 mask=0xff repeating=False
ecldata5sp.ecl sub28 0x3bf0 mask=0xff repeating=False
ecldata5sp.ecl sub28 0x3c18 mask=0xff repeating=False
ecldata5sp.ecl sub40 0x52b8 mask=0xff repeating=False
ecldata5sp.ecl sub40 0x52f4 mask=0xff repeating=False
ecldata5sp.ecl sub40 0x531c mask=0xff repeating=False
ecldata5sp.ecl sub40 0x5344 mask=0xff repeating=False
ecldata5sp.ecl sub40 0x5380 mask=0xff repeating=False
ecldata5sp.ecl sub40 0x53a8 mask=0xff repeating=False
```

## EX 15: TriggerScreenShake
资源站点 12 个。

ANM参与逻辑：执行必要的动画状态机与随机消耗；只删除绘制提交，不删除逻辑。 验收：追踪VM角度/type/生死/中断、共享RNG、恢复中断后的PC。

```text
ecldata6.ecl sub36 0x4610 mask=0xff repeating=False
ecldata6.ecl sub40 0x4d5c mask=0xff repeating=False
ecldata6.ecl sub44 0x55f8 mask=0xff repeating=False
ecldata6sp.ecl sub24 0x3894 mask=0xff repeating=False
ecldata6sp.ecl sub28 0x3fe0 mask=0xff repeating=False
ecldata6sp.ecl sub32 0x487c mask=0xff repeating=False
ecldata7.ecl sub31 0x4434 mask=0xff repeating=False
ecldata7.ecl sub34 0x4cfc mask=0xff repeating=False
ecldata7.ecl sub38 0x5634 mask=0xff repeating=False
ecldata7sp.ecl sub21 0x38ac mask=0xff repeating=False
ecldata7sp.ecl sub24 0x4174 mask=0xff repeating=False
ecldata7sp.ecl sub28 0x4aac mask=0xff repeating=False
```

## EX 16: TriggerChildrenNearMarkedBullets
资源站点 2 个。

实体/使魔生成：以生成图和对象池生命周期为世界状态；尽早选择有利的生成/击破位置。 验收：子程序出生即执行；序号遍历可导致同帧再次推进。

子ECL并行上下文：每个上下文保存独立时钟、call栈、per-frame回调和插值槽。 验收：同时运行主/子上下文，核对先后顺序及冻结行为。

```text
ecldata6.ecl sub73 0xa2b0 mask=0xff repeating=True
ecldata6sp.ecl sub61 0x9534 mask=0xff repeating=True
```

## EX 17: TriggerLongScreenPulse
资源站点 2 个。

ANM参与逻辑：执行必要的动画状态机与随机消耗；只删除绘制提交，不删除逻辑。 验收：追踪VM角度/type/生死/中断、共享RNG、恢复中断后的PC。

```text
ecldata6.ecl sub30 0x3934 mask=0xff repeating=False
ecldata6sp.ecl sub18 0x2bb8 mask=0xff repeating=False
```

## EX 18: SetFrameRateDivisor
资源站点 16 个。

冻结/倍率/局部时钟：保留各子系统时钟，不能统一dt=0；对输入队列单独推进。 验收：测试停表/子帧/强制暂停/已有速度缩放并核对恢复帧。

```text
ecldata6.ecl sub50 0x5cec mask=0xff repeating=False
ecldata6.ecl sub50 0x6070 mask=0xff repeating=False
ecldata6.ecl sub84 0xc23c mask=0xff repeating=False
ecldata6sp.ecl sub38 0x4f70 mask=0xff repeating=False
ecldata6sp.ecl sub38 0x52f4 mask=0xff repeating=False
ecldata6sp.ecl sub72 0xb4c0 mask=0xff repeating=False
ecldata7.ecl sub44 0x5c44 mask=0xff repeating=False
ecldata7.ecl sub44 0x6018 mask=0xff repeating=False
ecldata7sp.ecl sub34 0x50bc mask=0xff repeating=False
ecldata7sp.ecl sub34 0x5490 mask=0xff repeating=False
ecldata8.ecl sub86 0x87d4 mask=0xff repeating=False
ecldata8.ecl sub86 0x8b58 mask=0xff repeating=False
ecldata8sp.ecl sub40 0x5b68 mask=0xff repeating=False
ecldata8sp.ecl sub40 0x5eec mask=0xff repeating=False
ecldata_yk.ecl sub17 0x5844 mask=0xff repeating=False
ecldata_yk.ecl sub17 0x5be4 mask=0xff repeating=False
```

## EX 19: PublishCurrentSpellCardNumber
资源站点 15 个。

生命/计时回调：击破时间为由合法射击实现的控制结果；把安全出口与下阶段入口连接。 验收：验证刚好过阈值、超时、同帧多伤害和转阶段清弹/无敌。

```text
ecldata1sp.ecl sub42 0x96f0 mask=0xff repeating=False
ecldata2sp.ecl sub52 0x8d20 mask=0xff repeating=False
ecldata3sp.ecl sub63 0x9b04 mask=0xff repeating=False
ecldata4asp.ecl sub50 0x9988 mask=0xff repeating=False
ecldata4bsp.ecl sub70 0xbd48 mask=0xff repeating=False
ecldata5sp.ecl sub52 0x73e8 mask=0xff repeating=False
ecldata6sp.ecl sub80 0xbffc mask=0xff repeating=False
ecldata7sp.ecl sub83 0x10c40 mask=0xff repeating=False
ecldata8sp.ecl sub116 0x11780 mask=0xff repeating=False
ecldata_al.ecl sub8 0x180c mask=0xff repeating=False
ecldata_rm.ecl sub8 0x1460 mask=0xff repeating=False
ecldata_sk.ecl sub9 0x1580 mask=0xff repeating=False
ecldata_yk.ecl sub18 0x5c38 mask=0xff repeating=False
ecldata_ym.ecl sub10 0x15cc mask=0xff repeating=False
ecldata_yy.ecl sub11 0x22bc mask=0xff repeating=False
```

## EX 20: StartMediumBulletWarpBarrier
资源站点 2 个。

结界映射：分别实现窄/中/宽映射，事件前后安全区用真实位置。 验收：保留宽结界-32/-31.100006的不对称及2tick冷却。

ANM参与逻辑：执行必要的动画状态机与随机消耗；只删除绘制提交，不删除逻辑。 验收：追踪VM角度/type/生死/中断、共享RNG、恢复中断后的PC。

```text
ecldata4a.ecl sub28 0x474c mask=0xfc repeating=False
ecldata4asp.ecl sub13 0x3364 mask=0xfc repeating=False
```

## EX 21: WarpBulletsAcrossMediumBarrier
资源站点 2 个。

结界映射：分别实现窄/中/宽映射，事件前后安全区用真实位置。 验收：保留宽结界-32/-31.100006的不对称及2tick冷却。

```text
ecldata4a.ecl sub28 0x4760 mask=0xfc repeating=True
ecldata4asp.ecl sub13 0x3378 mask=0xfc repeating=True
```

## EX 22: MokouResurrection
资源站点 4 个。

生命/计时回调：击破时间为由合法射击实现的控制结果；把安全出口与下阶段入口连接。 验收：验证刚好过阈值、超时、同帧多伤害和转阶段清弹/无敌。

清弹/清实体：把清除语义、道具生成、cancel免疫作为原版状态变换。 验收：测试被清除的对象、留下的子弹、随机数和道具副作用。

实体/使魔生成：以生成图和对象池生命周期为世界状态；尽早选择有利的生成/击破位置。 验收：子程序出生即执行；序号遍历可导致同帧再次推进。

ANM参与逻辑：执行必要的动画状态机与随机消耗；只删除绘制提交，不删除逻辑。 验收：追踪VM角度/type/生死/中断、共享RNG、恢复中断后的PC。

```text
ecldata8.ecl sub88 0x93f0 mask=0xff repeating=False
ecldata8.ecl sub92 0x9d10 mask=0xff repeating=False
ecldata8sp.ecl sub42 0x6784 mask=0xff repeating=False
ecldata8sp.ecl sub46 0x70a4 mask=0xff repeating=False
```

## EX 23: HideSpellCardPresentation
资源站点 4 个。

ANM参与逻辑：执行必要的动画状态机与随机消耗；只删除绘制提交，不删除逻辑。 验收：追踪VM角度/type/生死/中断、共享RNG、恢复中断后的PC。

```text
ecldata8.ecl sub89 0x94f0 mask=0xff repeating=False
ecldata8.ecl sub92 0x9ea8 mask=0xff repeating=False
ecldata8sp.ecl sub43 0x6884 mask=0xff repeating=False
ecldata8sp.ecl sub46 0x723c mask=0xff repeating=False
```

## EX 24: PublishCapturedSpellCardCount
资源站点 2 个。

生命/计时回调：击破时间为由合法射击实现的控制结果；把安全出口与下阶段入口连接。 验收：验证刚好过阈值、超时、同帧多伤害和转阶段清弹/无敌。

```text
ecldata8.ecl sub84 0x8508 mask=0xff repeating=False
ecldata8sp.ecl sub38 0x589c mask=0xff repeating=False
```

## EX 25: UpdateWideRotatingLaserHitbox
资源站点 1 个。

EX直接激光：读取真正的角度所属VM及控制器阶段，不能只导出Laser池。 验收：对应ANM和ECL联合查角度演化；检查外矩形与擦弹内矩形。

ANM参与逻辑：执行必要的动画状态机与随机消耗；只删除绘制提交，不删除逻辑。 验收：追踪VM角度/type/生死/中断、共享RNG、恢复中断后的PC。

```text
ecldata4bsp.ecl sub63 0xad38 mask=0xff repeating=True
```

## EX 26: SetScriptedUpdateFreeze
资源站点 2 个。

冻结/倍率/局部时钟：保留各子系统时钟，不能统一dt=0；对输入队列单独推进。 验收：测试停表/子帧/强制暂停/已有速度缩放并核对恢复帧。

```text
ecldata_sk.ecl sub1 0x398 mask=0xff repeating=False
ecldata_sk.ecl sub1 0x410 mask=0xff repeating=False
```

## EX 27: SpawnEnemiesFromMarkedBullets
资源站点 1 个。

实体/使魔生成：以生成图和对象池生命周期为世界状态；尽早选择有利的生成/击破位置。 验收：子程序出生即执行；序号遍历可导致同帧再次推进。

```text
ecldata_sk.ecl sub1 0x3c0 mask=0xff repeating=False
```

## EX 28: EnterScaledBulletTime
资源站点 1 个。

冻结/倍率/局部时钟：保留各子系统时钟，不能统一dt=0；对输入队列单独推进。 验收：测试停表/子帧/强制暂停/已有速度缩放并核对恢复帧。

```text
ecldata_ym.ecl sub1 0x3bc mask=0xff repeating=False
```

## EX 29: ExitScaledBulletTime
资源站点 2 个。

冻结/倍率/局部时钟：保留各子系统时钟，不能统一dt=0；对输入队列单独推进。 验收：测试停表/子帧/强制暂停/已有速度缩放并核对恢复帧。

```text
ecldata_ym.ecl sub1 0x3e0 mask=0xff repeating=False
ecldata_ym.ecl sub11 0x1894 mask=0xff repeating=False
```

## EX 30: SetScreenEffectCounter
资源站点 10 个。

ANM参与逻辑：执行必要的动画状态机与随机消耗；只删除绘制提交，不删除逻辑。 验收：追踪VM角度/type/生死/中断、共享RNG、恢复中断后的PC。

```text
ecldata4b.ecl sub61 0x8b34 mask=0xff repeating=False
ecldata4b.ecl sub61 0x8b54 mask=0xff repeating=False
ecldata4b.ecl sub66 0x9e6c mask=0xff repeating=False
ecldata4b.ecl sub66 0x9e80 mask=0xff repeating=False
ecldata4bsp.ecl sub46 0x7758 mask=0xff repeating=False
ecldata4bsp.ecl sub46 0x7778 mask=0xff repeating=False
ecldata4bsp.ecl sub51 0x8a90 mask=0xff repeating=False
ecldata4bsp.ecl sub51 0x8aa4 mask=0xff repeating=False
ecldata4bsp.ecl sub71 0xc388 mask=0xff repeating=False
ecldata4bsp.ecl sub71 0xc39c mask=0xff repeating=False
```

## EX 31: SpawnBombOrExtendItem
资源站点 1 个。

清弹/清实体：把清除语义、道具生成、cancel免疫作为原版状态变换。 验收：测试被清除的对象、留下的子弹、随机数和道具副作用。

随机数依赖：保存游戏随机相位与真实消耗顺序；允许共享已确定的弹，不共享未证明相同的后续随机发射。 验收：增减一次发射/擦弹/ANM随机调用，检查第一失配相位。

```text
ecldata8.ecl sub30 0x24bc mask=0xff repeating=False
```
