# 全阶段／全符卡资源索引

本篇Lunatic列表是开符掩码包含bit8的语法记录，包含不同路线、条件LastSpell与不可同时进入的变体；不是一局必须经历的顺序。ID为资源原始编号。

## ecldata1.ecl
53 个子程序；2 条timeline。完整字节码见 `reports/disassembly/ecldata1.ecl.txt`。

- ID 000 蛍符「地上の流星」；sub 22 / 0x31c0 / mask 0xf4。
- ID 001 蛍符「地上の彗星」；sub 22 / 0x32b4 / mask 0xf8。
- ID 002 灯符「ファイヤフライフェノメノン」；sub 38 / 0x5a64 / mask 0xf1。
- ID 003 灯符「ファイヤフライフェノメノン」；sub 38 / 0x5b58 / mask 0xf2。
- ID 004 灯符「ファイヤフライフェノメノン」；sub 38 / 0x5c4c / mask 0xf4。
- ID 005 灯符「ファイヤフライフェノメノン」；sub 38 / 0x5d40 / mask 0xf8。
- ID 006 蠢符「リトルバグ」；sub 44 / 0x6e58 / mask 0xf1。
- ID 007 蠢符「リトルバグストーム」；sub 44 / 0x6f4c / mask 0xf2。
- ID 008 蠢符「ナイトバグストーム」；sub 44 / 0x7040 / mask 0xf4。
- ID 009 蠢符「ナイトバグトルネード」；sub 44 / 0x7134 / mask 0xf8。
- ID 010 隠蟲「永夜蟄居」；sub 48 / 0x8128 / mask 0xf2。
- ID 011 隠蟲「永夜蟄居」；sub 48 / 0x821c / mask 0xf4。
- ID 012 隠蟲「永夜蟄居」；sub 48 / 0x8310 / mask 0xf8。

## ecldata1sp.ecl
43 个子程序；1 条timeline。完整字节码见 `reports/disassembly/ecldata1sp.ecl.txt`。

- ID 000 蛍符「地上の流星」；sub 8 / 0x1e20 / mask 0xf4。
- ID 001 蛍符「地上の彗星」；sub 8 / 0x1f14 / mask 0xf8。
- ID 002 灯符「ファイヤフライフェノメノン」；sub 24 / 0x46c4 / mask 0xf1。
- ID 003 灯符「ファイヤフライフェノメノン」；sub 24 / 0x47b8 / mask 0xf2。
- ID 004 灯符「ファイヤフライフェノメノン」；sub 24 / 0x48ac / mask 0xf4。
- ID 005 灯符「ファイヤフライフェノメノン」；sub 24 / 0x49a0 / mask 0xf8。
- ID 006 蠢符「リトルバグ」；sub 30 / 0x5ab8 / mask 0xf1。
- ID 007 蠢符「リトルバグストーム」；sub 30 / 0x5bac / mask 0xf2。
- ID 008 蠢符「ナイトバグストーム」；sub 30 / 0x5ca0 / mask 0xf4。
- ID 009 蠢符「ナイトバグトルネード」；sub 30 / 0x5d94 / mask 0xf8。
- ID 010 隠蟲「永夜蟄居」；sub 34 / 0x6d88 / mask 0xf2。
- ID 011 隠蟲「永夜蟄居」；sub 34 / 0x6e7c / mask 0xf4。
- ID 012 隠蟲「永夜蟄居」；sub 34 / 0x6f70 / mask 0xf8。
- ID 205 「季節外れのバタフライストーム」；sub 36 / 0x7c20 / mask 0xff。

## ecldata2.ecl
65 个子程序；2 条timeline。完整字节码见 `reports/disassembly/ecldata2.ecl.txt`。

- ID 013 声符「梟の夜鳴声」；sub 23 / 0x2900 / mask 0xf1。
- ID 014 声符「梟の夜鳴声」；sub 23 / 0x29f4 / mask 0xf2。
- ID 015 声符「木菟咆哮」；sub 23 / 0x2ae8 / mask 0xf4。
- ID 016 声符「木菟咆哮」；sub 23 / 0x2bdc / mask 0xf8。
- ID 017 蛾符「天蛾の蠱道」；sub 33 / 0x4b40 / mask 0xf1。
- ID 018 蛾符「天蛾の蠱道」；sub 33 / 0x4c34 / mask 0xf2。
- ID 019 毒符「毒蛾の鱗粉」；sub 33 / 0x4d28 / mask 0xf4。
- ID 020 猛毒「毒蛾の暗闇演舞」；sub 33 / 0x4e1c / mask 0xf8。
- ID 019 毒符「毒蛾の鱗粉」；sub 38 / 0x586c / mask 0xf4。
- ID 020 猛毒「毒蛾の暗闇演舞」；sub 38 / 0x5960 / mask 0xf8。
- ID 021 鷹符「イルスタードダイブ」；sub 44 / 0x64d4 / mask 0xf1。
- ID 022 鷹符「イルスタードダイブ」；sub 44 / 0x65c8 / mask 0xf2。
- ID 023 鷹符「イルスタードダイブ」；sub 44 / 0x66bc / mask 0xf4。
- ID 024 鷹符「イルスタードダイブ」；sub 44 / 0x67b0 / mask 0xf8。
- ID 025 夜盲「夜雀の歌」；sub 52 / 0x75f4 / mask 0xf1。
- ID 026 夜盲「夜雀の歌」；sub 52 / 0x76e8 / mask 0xf2。
- ID 027 夜盲「夜雀の歌」；sub 52 / 0x77dc / mask 0xf4。
- ID 028 夜盲「夜雀の歌」；sub 52 / 0x78d0 / mask 0xf8。
- ID 029 夜雀「真夜中のコーラスマスター」；sub 58 / 0x85d0 / mask 0xf2。
- ID 030 夜雀「真夜中のコーラスマスター」；sub 58 / 0x86c4 / mask 0xf4。
- ID 031 夜雀「真夜中のコーラスマスター」；sub 58 / 0x87b8 / mask 0xf8。

## ecldata2sp.ecl
53 个子程序；1 条timeline。完整字节码见 `reports/disassembly/ecldata2sp.ecl.txt`。

- ID 013 声符「梟の夜鳴声」；sub 7 / 0xd20 / mask 0xf1。
- ID 014 声符「梟の夜鳴声」；sub 7 / 0xe14 / mask 0xf2。
- ID 015 声符「木菟咆哮」；sub 7 / 0xf08 / mask 0xf4。
- ID 016 声符「木菟咆哮」；sub 7 / 0xffc / mask 0xf8。
- ID 017 蛾符「天蛾の蠱道」；sub 17 / 0x2f60 / mask 0xf1。
- ID 018 蛾符「天蛾の蠱道」；sub 17 / 0x3054 / mask 0xf2。
- ID 019 毒符「毒蛾の鱗粉」；sub 17 / 0x3148 / mask 0xf4。
- ID 020 猛毒「毒蛾の暗闇演舞」；sub 17 / 0x323c / mask 0xf8。
- ID 019 毒符「毒蛾の鱗粉」；sub 22 / 0x3c8c / mask 0xf4。
- ID 020 猛毒「毒蛾の暗闇演舞」；sub 22 / 0x3d80 / mask 0xf8。
- ID 021 鷹符「イルスタードダイブ」；sub 28 / 0x48f4 / mask 0xf1。
- ID 022 鷹符「イルスタードダイブ」；sub 28 / 0x49e8 / mask 0xf2。
- ID 023 鷹符「イルスタードダイブ」；sub 28 / 0x4adc / mask 0xf4。
- ID 024 鷹符「イルスタードダイブ」；sub 28 / 0x4bd0 / mask 0xf8。
- ID 025 夜盲「夜雀の歌」；sub 36 / 0x5a14 / mask 0xf1。
- ID 026 夜盲「夜雀の歌」；sub 36 / 0x5b08 / mask 0xf2。
- ID 027 夜盲「夜雀の歌」；sub 36 / 0x5bfc / mask 0xf4。
- ID 028 夜盲「夜雀の歌」；sub 36 / 0x5cf0 / mask 0xf8。
- ID 029 夜雀「真夜中のコーラスマスター」；sub 42 / 0x69f0 / mask 0xf2。
- ID 030 夜雀「真夜中のコーラスマスター」；sub 42 / 0x6ae4 / mask 0xf4。
- ID 031 夜雀「真夜中のコーラスマスター」；sub 42 / 0x6bd8 / mask 0xf8。
- ID 206 「ブラインドナイトバード」；sub 46 / 0x793c / mask 0xff。

## ecldata3.ecl
78 个子程序；4 条timeline。完整字节码见 `reports/disassembly/ecldata3.ecl.txt`。

- ID 032 産霊「ファーストピラミッド」；sub 30 / 0x30c8 / mask 0xf1。
- ID 033 産霊「ファーストピラミッド」；sub 30 / 0x31bc / mask 0xf2。
- ID 034 産霊「ファーストピラミッド」；sub 30 / 0x32b0 / mask 0xf4。
- ID 035 産霊「ファーストピラミッド」；sub 30 / 0x33a4 / mask 0xf8。
- ID 036 始符「エフェメラリティ137」；sub 44 / 0x566c / mask 0xf2。
- ID 037 始符「エフェメラリティ137」；sub 44 / 0x5760 / mask 0xf4。
- ID 038 始符「エフェメラリティ137」；sub 44 / 0x5854 / mask 0xf8。
- ID 039 野符「武烈クライシス」；sub 47 / 0x62b8 / mask 0xf1。
- ID 040 野符「将門クライシス」；sub 47 / 0x63ac / mask 0xf2。
- ID 041 野符「義満クライシス」；sub 47 / 0x64a0 / mask 0xf4。
- ID 042 野符「GHQクライシス」；sub 47 / 0x6594 / mask 0xf8。
- ID 043 国符「三種の神器　剣」；sub 50 / 0x7050 / mask 0xff。
- ID 044 国符「三種の神器　玉」；sub 54 / 0x770c / mask 0xff。
- ID 045 国符「三種の神器　鏡」；sub 58 / 0x801c / mask 0xff。
- ID 046 国体「三種の神器　郷」；sub 62 / 0x8784 / mask 0xff。
- ID 047 終符「幻想天皇」；sub 67 / 0x8ec4 / mask 0xf1。
- ID 048 終符「幻想天皇」；sub 67 / 0x8fb8 / mask 0xf2。
- ID 049 虚史「幻想郷伝説」；sub 67 / 0x90ac / mask 0xf4。
- ID 050 虚史「幻想郷伝説」；sub 67 / 0x91a0 / mask 0xf8。
- ID 051 未来「高天原」；sub 71 / 0x9bbc / mask 0xf2。
- ID 052 未来「高天原」；sub 71 / 0x9cb0 / mask 0xf4。
- ID 053 未来「高天原」；sub 71 / 0x9da4 / mask 0xf8。

## ecldata3sp.ecl
64 个子程序；1 条timeline。完整字节码见 `reports/disassembly/ecldata3sp.ecl.txt`。

- ID 032 産霊「ファーストピラミッド」；sub 11 / 0x106c / mask 0xf1。
- ID 033 産霊「ファーストピラミッド」；sub 11 / 0x1160 / mask 0xf2。
- ID 034 産霊「ファーストピラミッド」；sub 11 / 0x1254 / mask 0xf4。
- ID 035 産霊「ファーストピラミッド」；sub 11 / 0x1348 / mask 0xf8。
- ID 036 始符「エフェメラリティ137」；sub 25 / 0x3610 / mask 0xf2。
- ID 037 始符「エフェメラリティ137」；sub 25 / 0x3704 / mask 0xf4。
- ID 038 始符「エフェメラリティ137」；sub 25 / 0x37f8 / mask 0xf8。
- ID 039 野符「武烈クライシス」；sub 28 / 0x425c / mask 0xf1。
- ID 040 野符「将門クライシス」；sub 28 / 0x4350 / mask 0xf2。
- ID 041 野符「義満クライシス」；sub 28 / 0x4444 / mask 0xf4。
- ID 042 野符「GHQクライシス」；sub 28 / 0x4538 / mask 0xf8。
- ID 043 国符「三種の神器　剣」；sub 31 / 0x4ff4 / mask 0xff。
- ID 044 国符「三種の神器　玉」；sub 35 / 0x56b0 / mask 0xff。
- ID 045 国符「三種の神器　鏡」；sub 39 / 0x5fc0 / mask 0xff。
- ID 046 国体「三種の神器　郷」；sub 43 / 0x6728 / mask 0xff。
- ID 047 終符「幻想天皇」；sub 48 / 0x6e68 / mask 0xf1。
- ID 048 終符「幻想天皇」；sub 48 / 0x6f5c / mask 0xf2。
- ID 049 虚史「幻想郷伝説」；sub 48 / 0x7050 / mask 0xf4。
- ID 050 虚史「幻想郷伝説」；sub 48 / 0x7144 / mask 0xf8。
- ID 051 未来「高天原」；sub 52 / 0x7b60 / mask 0xf2。
- ID 052 未来「高天原」；sub 52 / 0x7c54 / mask 0xf4。
- ID 053 未来「高天原」；sub 52 / 0x7d48 / mask 0xf8。
- ID 207 「日出づる国の天子」；sub 56 / 0x8584 / mask 0xff。

## ecldata4a.ecl
61 个子程序；2 条timeline。完整字节码见 `reports/disassembly/ecldata4a.ecl.txt`。

- ID 054 夢符「二重結界」；sub 28 / 0x4334 / mask 0xf1。
- ID 055 夢符「二重結界」；sub 28 / 0x4428 / mask 0xf2。
- ID 056 夢境「二重大結界」；sub 28 / 0x451c / mask 0xf4。
- ID 057 夢境「二重大結界」；sub 28 / 0x4610 / mask 0xf8。
- ID 058 霊符「夢想封印　散」；sub 30 / 0x4c64 / mask 0xf1。
- ID 059 霊符「夢想封印　散」；sub 30 / 0x4d58 / mask 0xf2。
- ID 060 散霊「夢想封印　寂」；sub 30 / 0x4e4c / mask 0xf4。
- ID 061 散霊「夢想封印　寂」；sub 30 / 0x4f40 / mask 0xf8。
- ID 062 夢符「封魔陣」；sub 33 / 0x5588 / mask 0xf1。
- ID 063 夢符「封魔陣」；sub 33 / 0x567c / mask 0xf2。
- ID 064 神技「八方鬼縛陣」；sub 33 / 0x5770 / mask 0xf4。
- ID 065 神技「八方龍殺陣」；sub 33 / 0x5864 / mask 0xf8。
- ID 066 霊符「夢想封印　集」；sub 41 / 0x6f04 / mask 0xf1。
- ID 067 霊符「夢想封印　集」；sub 41 / 0x6ff8 / mask 0xf2。
- ID 068 回霊「夢想封印　侘」；sub 41 / 0x70ec / mask 0xf4。
- ID 069 回霊「夢想封印　侘」；sub 41 / 0x71e0 / mask 0xf8。
- ID 070 境界「二重弾幕結界」；sub 46 / 0x7dec / mask 0xf1。
- ID 071 境界「二重弾幕結界」；sub 46 / 0x7ee0 / mask 0xf2。
- ID 072 大結界「博麗弾幕結界」；sub 46 / 0x7fd4 / mask 0xf4。
- ID 073 大結界「博麗弾幕結界」；sub 46 / 0x80c8 / mask 0xf8。
- ID 074 神霊「夢想封印　瞬」；sub 54 / 0x8d44 / mask 0xf2。
- ID 075 神霊「夢想封印　瞬」；sub 54 / 0x8e38 / mask 0xf4。
- ID 076 神霊「夢想封印　瞬」；sub 54 / 0x8f2c / mask 0xf8。

## ecldata4asp.ecl
52 个子程序；1 条timeline。完整字节码见 `reports/disassembly/ecldata4asp.ecl.txt`。

- ID 054 夢符「二重結界」；sub 13 / 0x2f4c / mask 0xf1。
- ID 055 夢符「二重結界」；sub 13 / 0x3040 / mask 0xf2。
- ID 056 夢境「二重大結界」；sub 13 / 0x3134 / mask 0xf4。
- ID 057 夢境「二重大結界」；sub 13 / 0x3228 / mask 0xf8。
- ID 058 霊符「夢想封印　散」；sub 15 / 0x387c / mask 0xf1。
- ID 059 霊符「夢想封印　散」；sub 15 / 0x3970 / mask 0xf2。
- ID 060 散霊「夢想封印　寂」；sub 15 / 0x3a64 / mask 0xf4。
- ID 061 散霊「夢想封印　寂」；sub 15 / 0x3b58 / mask 0xf8。
- ID 062 夢符「封魔陣」；sub 18 / 0x41a0 / mask 0xf1。
- ID 063 夢符「封魔陣」；sub 18 / 0x4294 / mask 0xf2。
- ID 064 神技「八方鬼縛陣」；sub 18 / 0x4388 / mask 0xf4。
- ID 065 神技「八方龍殺陣」；sub 18 / 0x447c / mask 0xf8。
- ID 066 霊符「夢想封印　集」；sub 26 / 0x5b1c / mask 0xf1。
- ID 067 霊符「夢想封印　集」；sub 26 / 0x5c10 / mask 0xf2。
- ID 068 回霊「夢想封印　侘」；sub 26 / 0x5d04 / mask 0xf4。
- ID 069 回霊「夢想封印　侘」；sub 26 / 0x5df8 / mask 0xf8。
- ID 070 境界「二重弾幕結界」；sub 31 / 0x6a04 / mask 0xf1。
- ID 071 境界「二重弾幕結界」；sub 31 / 0x6af8 / mask 0xf2。
- ID 072 大結界「博麗弾幕結界」；sub 31 / 0x6bec / mask 0xf4。
- ID 073 大結界「博麗弾幕結界」；sub 31 / 0x6ce0 / mask 0xf8。
- ID 074 神霊「夢想封印　瞬」；sub 39 / 0x795c / mask 0xf2。
- ID 075 神霊「夢想封印　瞬」；sub 39 / 0x7a50 / mask 0xf4。
- ID 076 神霊「夢想封印　瞬」；sub 39 / 0x7b44 / mask 0xf8。
- ID 214 「夢想天生」；sub 43 / 0x8290 / mask 0xff。

## ecldata4b.ecl
78 个子程序；2 条timeline。完整字节码见 `reports/disassembly/ecldata4b.ecl.txt`。

- ID 077 魔符「ミルキーウェイ」；sub 36 / 0x4540 / mask 0xf1。
- ID 078 魔符「ミルキーウェイ」；sub 36 / 0x4634 / mask 0xf2。
- ID 079 魔空「アステロイドベルト」；sub 36 / 0x4728 / mask 0xf4。
- ID 080 魔空「アステロイドベルト」；sub 36 / 0x481c / mask 0xf8。
- ID 081 魔符「スターダストレヴァリエ」；sub 41 / 0x54b0 / mask 0xf1。
- ID 082 魔符「スターダストレヴァリエ」；sub 41 / 0x55a4 / mask 0xf2。
- ID 083 黒魔「イベントホライズン」；sub 41 / 0x5698 / mask 0xf4。
- ID 084 黒魔「イベントホライズン」；sub 41 / 0x578c / mask 0xf8。
- ID 085 恋符「ノンディレクショナルレーザー」；sub 47 / 0x64dc / mask 0xf1。
- ID 086 恋符「ノンディレクショナルレーザー」；sub 47 / 0x65d0 / mask 0xf2。
- ID 087 恋風「スターライトタイフーン」；sub 47 / 0x66c4 / mask 0xf4。
- ID 088 恋風「スターライトタイフーン」；sub 47 / 0x67b8 / mask 0xf8。
- ID 089 恋符「マスタースパーク」；sub 55 / 0x79fc / mask 0xf1。
- ID 090 恋符「マスタースパーク」；sub 55 / 0x7af0 / mask 0xf2。
- ID 091 恋心「ダブルスパーク」；sub 55 / 0x7be4 / mask 0xf4。
- ID 092 恋心「ダブルスパーク」；sub 55 / 0x7cd8 / mask 0xf8。
- ID 093 光符「アースライトレイ」；sub 62 / 0x8c44 / mask 0xf1。
- ID 094 光符「アースライトレイ」；sub 62 / 0x8d38 / mask 0xf2。
- ID 095 光撃「シュート・ザ・ムーン」；sub 62 / 0x8e2c / mask 0xf4。
- ID 096 光撃「シュート・ザ・ムーン」；sub 62 / 0x8f20 / mask 0xf8。
- ID 097 魔砲「ファイナルスパーク」；sub 67 / 0x9fa8 / mask 0xf2。
- ID 098 魔砲「ファイナルスパーク」；sub 67 / 0xa09c / mask 0xf4。
- ID 099 魔砲「ファイナルマスタースパーク」；sub 67 / 0xa190 / mask 0xf8。

## ecldata4bsp.ecl
72 个子程序；1 条timeline。完整字节码见 `reports/disassembly/ecldata4bsp.ecl.txt`。

- ID 077 魔符「ミルキーウェイ」；sub 21 / 0x3164 / mask 0xf1。
- ID 078 魔符「ミルキーウェイ」；sub 21 / 0x3258 / mask 0xf2。
- ID 079 魔空「アステロイドベルト」；sub 21 / 0x334c / mask 0xf4。
- ID 080 魔空「アステロイドベルト」；sub 21 / 0x3440 / mask 0xf8。
- ID 081 魔符「スターダストレヴァリエ」；sub 26 / 0x40d4 / mask 0xf1。
- ID 082 魔符「スターダストレヴァリエ」；sub 26 / 0x41c8 / mask 0xf2。
- ID 083 黒魔「イベントホライズン」；sub 26 / 0x42bc / mask 0xf4。
- ID 084 黒魔「イベントホライズン」；sub 26 / 0x43b0 / mask 0xf8。
- ID 085 恋符「ノンディレクショナルレーザー」；sub 32 / 0x5100 / mask 0xf1。
- ID 086 恋符「ノンディレクショナルレーザー」；sub 32 / 0x51f4 / mask 0xf2。
- ID 087 恋風「スターライトタイフーン」；sub 32 / 0x52e8 / mask 0xf4。
- ID 088 恋風「スターライトタイフーン」；sub 32 / 0x53dc / mask 0xf8。
- ID 089 恋符「マスタースパーク」；sub 40 / 0x6620 / mask 0xf1。
- ID 090 恋符「マスタースパーク」；sub 40 / 0x6714 / mask 0xf2。
- ID 091 恋心「ダブルスパーク」；sub 40 / 0x6808 / mask 0xf4。
- ID 092 恋心「ダブルスパーク」；sub 40 / 0x68fc / mask 0xf8。
- ID 093 光符「アースライトレイ」；sub 47 / 0x7868 / mask 0xf1。
- ID 094 光符「アースライトレイ」；sub 47 / 0x795c / mask 0xf2。
- ID 095 光撃「シュート・ザ・ムーン」；sub 47 / 0x7a50 / mask 0xf4。
- ID 096 光撃「シュート・ザ・ムーン」；sub 47 / 0x7b44 / mask 0xf8。
- ID 097 魔砲「ファイナルスパーク」；sub 52 / 0x8bcc / mask 0xf2。
- ID 098 魔砲「ファイナルスパーク」；sub 52 / 0x8cc0 / mask 0xf4。
- ID 099 魔砲「ファイナルマスタースパーク」；sub 52 / 0x8db4 / mask 0xf8。
- ID 215 「ブレイジングスター」；sub 60 / 0xa53c / mask 0xff。

## ecldata5.ecl
90 个子程序；1 条timeline。完整字节码见 `reports/disassembly/ecldata5.ecl.txt`。

- ID 100 波符「赤眼催眠(マインドシェイカー)」；sub 62 / 0x6030 / mask 0xf1。
- ID 101 波符「赤眼催眠(マインドシェイカー)」；sub 62 / 0x6124 / mask 0xf2。
- ID 102 幻波「赤眼催眠(マインドブローイング)」；sub 62 / 0x6218 / mask 0xf4。
- ID 103 幻波「赤眼催眠(マインドブローイング)」；sub 62 / 0x630c / mask 0xf8。
- ID 108 懶符「生神停止(アイドリングウェーブ」；sub 63 / 0x6880 / mask 0xf1。
- ID 109 懶符「生神停止(アイドリングウェーブ)」；sub 63 / 0x6974 / mask 0xf2。
- ID 110 懶惰「生神停止(マインドストッパー)」；sub 63 / 0x6a68 / mask 0xf4。
- ID 111 懶惰「生神停止(マインドストッパー)」；sub 63 / 0x6b5c / mask 0xf8。
- ID 104 狂符「幻視調律(ビジョナリチューニング)」；sub 66 / 0x72e0 / mask 0xf1。
- ID 105 狂符「幻視調律(ビジョナリチューニング)」；sub 66 / 0x73d4 / mask 0xf2。
- ID 106 狂視「狂視調律(イリュージョンシーカー)」；sub 66 / 0x74c8 / mask 0xf4。
- ID 107 狂視「狂視調律(イリュージョンシーカー)」；sub 66 / 0x75bc / mask 0xf8。
- ID 112 散符「真実の月(インビジブルフルムーン)」；sub 75 / 0x7fb0 / mask 0xf1。
- ID 113 散符「真実の月(インビジブルフルムーン)」；sub 75 / 0x80a4 / mask 0xf2。
- ID 114 散符「真実の月(インビジブルフルムーン)」；sub 75 / 0x8198 / mask 0xf4。
- ID 115 散符「真実の月(インビジブルフルムーン)」；sub 75 / 0x828c / mask 0xf8。
- ID 116 月眼「月兎遠隔催眠術(テレメスメリズム)」；sub 78 / 0x89f8 / mask 0xf2。
- ID 117 月眼「月兎遠隔催眠術(テレメスメリズム)」；sub 78 / 0x8aec / mask 0xf4。
- ID 118 月眼「月兎遠隔催眠術(テレメスメリズム)」；sub 78 / 0x8be0 / mask 0xf8。

## ecldata5sp.ecl
53 个子程序；1 条timeline。完整字节码见 `reports/disassembly/ecldata5sp.ecl.txt`。

- ID 100 波符「赤眼催眠(マインドシェイカー)」；sub 15 / 0x167c / mask 0xf1。
- ID 101 波符「赤眼催眠(マインドシェイカー)」；sub 15 / 0x1770 / mask 0xf2。
- ID 102 幻波「赤眼催眠(マインドブローイング)」；sub 15 / 0x1864 / mask 0xf4。
- ID 103 幻波「赤眼催眠(マインドブローイング)」；sub 15 / 0x1958 / mask 0xf8。
- ID 108 懶符「生神停止(アイドリングウェーブ」；sub 16 / 0x1ecc / mask 0xf1。
- ID 109 懶符「生神停止(アイドリングウェーブ)」；sub 16 / 0x1fc0 / mask 0xf2。
- ID 110 懶惰「生神停止(マインドストッパー)」；sub 16 / 0x20b4 / mask 0xf4。
- ID 111 懶惰「生神停止(マインドストッパー)」；sub 16 / 0x21a8 / mask 0xf8。
- ID 104 狂符「幻視調律(ビジョナリチューニング)」；sub 19 / 0x292c / mask 0xf1。
- ID 105 狂符「幻視調律(ビジョナリチューニング)」；sub 19 / 0x2a20 / mask 0xf2。
- ID 106 狂視「狂視調律(イリュージョンシーカー)」；sub 19 / 0x2b14 / mask 0xf4。
- ID 107 狂視「狂視調律(イリュージョンシーカー)」；sub 19 / 0x2c08 / mask 0xf8。
- ID 112 散符「真実の月(インビジブルフルムーン)」；sub 28 / 0x35fc / mask 0xf1。
- ID 113 散符「真実の月(インビジブルフルムーン)」；sub 28 / 0x36f0 / mask 0xf2。
- ID 114 散符「真実の月(インビジブルフルムーン)」；sub 28 / 0x37e4 / mask 0xf4。
- ID 115 散符「真実の月(インビジブルフルムーン)」；sub 28 / 0x38d8 / mask 0xf8。
- ID 116 月眼「月兎遠隔催眠術(テレメスメリズム)」；sub 31 / 0x4044 / mask 0xf2。
- ID 117 月眼「月兎遠隔催眠術(テレメスメリズム)」；sub 31 / 0x4138 / mask 0xf4。
- ID 118 月眼「月兎遠隔催眠術(テレメスメリズム)」；sub 31 / 0x422c / mask 0xf8。
- ID 208 「幻朧月睨(ルナティックレッドアイズ)」；sub 40 / 0x5068 / mask 0xff。
- ID 212 「エンシェントデューパー」；sub 43 / 0x57b0 / mask 0xff。

## ecldata6.ecl
88 个子程序；1 条timeline。完整字节码见 `reports/disassembly/ecldata6.ecl.txt`。

- ID 119 天丸「壺中の天地」；sub 21 / 0x26b0 / mask 0xf1。
- ID 120 天丸「壺中の天地」；sub 21 / 0x27a4 / mask 0xf2。
- ID 121 天丸「壺中の天地」；sub 21 / 0x2898 / mask 0xf4。
- ID 122 天丸「壺中の天地」；sub 21 / 0x298c / mask 0xf8。
- ID 123 覚神「神代の記憶」；sub 52 / 0x6600 / mask 0xf1。
- ID 124 覚神「神代の記憶」；sub 52 / 0x66f4 / mask 0xf2。
- ID 125 神符「天人の系譜」；sub 52 / 0x67e8 / mask 0xf4。
- ID 126 神符「天人の系譜」；sub 52 / 0x68dc / mask 0xf8。
- ID 127 蘇活「生命遊戯　-ライフゲーム-」；sub 56 / 0x7178 / mask 0xf1。
- ID 128 蘇活「生命遊戯　-ライフゲーム-」；sub 56 / 0x726c / mask 0xf2。
- ID 129 蘇生「ライジングゲーム」；sub 56 / 0x7360 / mask 0xf4。
- ID 130 蘇生「ライジングゲーム」；sub 56 / 0x7454 / mask 0xf8。
- ID 131 操神「オモイカネディバイス」；sub 63 / 0x8034 / mask 0xf1。
- ID 132 操神「オモイカネディバイス」；sub 63 / 0x8128 / mask 0xf2。
- ID 133 神脳「オモイカネブレイン」；sub 63 / 0x821c / mask 0xf4。
- ID 134 神脳「オモイカネブレイン」；sub 63 / 0x8310 / mask 0xf8。
- ID 135 天呪「アポロ１３」；sub 68 / 0x8db0 / mask 0xf1。
- ID 136 天呪「アポロ１３」；sub 68 / 0x8ea4 / mask 0xf2。
- ID 137 天呪「アポロ１３」；sub 68 / 0x8f98 / mask 0xf4。
- ID 138 天呪「アポロ１３」；sub 68 / 0x908c / mask 0xf8。
- ID 139 秘術「天文密葬法」；sub 73 / 0x9b98 / mask 0xf1。
- ID 140 秘術「天文密葬法」；sub 73 / 0x9c8c / mask 0xf2。
- ID 141 秘術「天文密葬法」；sub 73 / 0x9d80 / mask 0xf4。
- ID 142 秘術「天文密葬法」；sub 73 / 0x9e74 / mask 0xf8。
- ID 143 禁薬「蓬莱の薬」；sub 78 / 0xacc0 / mask 0xf1。
- ID 144 禁薬「蓬莱の薬」；sub 78 / 0xadb4 / mask 0xf2。
- ID 145 禁薬「蓬莱の薬」；sub 78 / 0xaea8 / mask 0xf4。
- ID 146 禁薬「蓬莱の薬」；sub 78 / 0xaf9c / mask 0xf8。

## ecldata6sp.ecl
81 个子程序；1 条timeline。完整字节码见 `reports/disassembly/ecldata6sp.ecl.txt`。

- ID 119 天丸「壺中の天地」；sub 9 / 0x1934 / mask 0xf1。
- ID 120 天丸「壺中の天地」；sub 9 / 0x1a28 / mask 0xf2。
- ID 121 天丸「壺中の天地」；sub 9 / 0x1b1c / mask 0xf4。
- ID 122 天丸「壺中の天地」；sub 9 / 0x1c10 / mask 0xf8。
- ID 123 覚神「神代の記憶」；sub 40 / 0x5884 / mask 0xf1。
- ID 124 覚神「神代の記憶」；sub 40 / 0x5978 / mask 0xf2。
- ID 125 神符「天人の系譜」；sub 40 / 0x5a6c / mask 0xf4。
- ID 126 神符「天人の系譜」；sub 40 / 0x5b60 / mask 0xf8。
- ID 127 蘇活「生命遊戯　-ライフゲーム-」；sub 44 / 0x63fc / mask 0xf1。
- ID 128 蘇活「生命遊戯　-ライフゲーム-」；sub 44 / 0x64f0 / mask 0xf2。
- ID 129 蘇生「ライジングゲーム」；sub 44 / 0x65e4 / mask 0xf4。
- ID 130 蘇生「ライジングゲーム」；sub 44 / 0x66d8 / mask 0xf8。
- ID 131 操神「オモイカネディバイス」；sub 51 / 0x72b8 / mask 0xf1。
- ID 132 操神「オモイカネディバイス」；sub 51 / 0x73ac / mask 0xf2。
- ID 133 神脳「オモイカネブレイン」；sub 51 / 0x74a0 / mask 0xf4。
- ID 134 神脳「オモイカネブレイン」；sub 51 / 0x7594 / mask 0xf8。
- ID 135 天呪「アポロ１３」；sub 56 / 0x8034 / mask 0xf1。
- ID 136 天呪「アポロ１３」；sub 56 / 0x8128 / mask 0xf2。
- ID 137 天呪「アポロ１３」；sub 56 / 0x821c / mask 0xf4。
- ID 138 天呪「アポロ１３」；sub 56 / 0x8310 / mask 0xf8。
- ID 139 秘術「天文密葬法」；sub 61 / 0x8e1c / mask 0xf1。
- ID 140 秘術「天文密葬法」；sub 61 / 0x8f10 / mask 0xf2。
- ID 141 秘術「天文密葬法」；sub 61 / 0x9004 / mask 0xf4。
- ID 142 秘術「天文密葬法」；sub 61 / 0x90f8 / mask 0xf8。
- ID 143 禁薬「蓬莱の薬」；sub 66 / 0x9f44 / mask 0xf1。
- ID 144 禁薬「蓬莱の薬」；sub 66 / 0xa038 / mask 0xf2。
- ID 145 禁薬「蓬莱の薬」；sub 66 / 0xa12c / mask 0xf4。
- ID 146 禁薬「蓬莱の薬」；sub 66 / 0xa220 / mask 0xf8。
- ID 209 「天網蜘網捕蝶の法」；sub 76 / 0xba4c / mask 0xff。

## ecldata7.ecl
89 个子程序；1 条timeline。完整字节码见 `reports/disassembly/ecldata7.ecl.txt`。

- ID 147 薬符「壺中の大銀河」；sub 19 / 0x24c8 / mask 0xf1。
- ID 148 薬符「壺中の大銀河」；sub 19 / 0x25bc / mask 0xf2。
- ID 149 薬符「壺中の大銀河」；sub 19 / 0x26b0 / mask 0xf4。
- ID 150 薬符「壺中の大銀河」；sub 19 / 0x27a4 / mask 0xf8。
- ID 151 難題「龍の頸の玉  -五色の弾丸-」；sub 50 / 0x6bbc / mask 0xf1。
- ID 152 難題「龍の頸の玉  -五色の弾丸-」；sub 50 / 0x6cb0 / mask 0xf2。
- ID 153 神宝「ブリリアントドラゴンバレッタ」；sub 50 / 0x6da4 / mask 0xf4。
- ID 154 神宝「ブリリアントドラゴンバレッタ」；sub 50 / 0x6e98 / mask 0xf8。
- ID 155 難題「仏の御石の鉢  -砕けぬ意思-」；sub 55 / 0x7e08 / mask 0xf1。
- ID 156 難題「仏の御石の鉢  -砕けぬ意思-」；sub 55 / 0x7efc / mask 0xf2。
- ID 157 神宝「ブディストダイアモンド」；sub 55 / 0x7ff0 / mask 0xf4。
- ID 158 神宝「ブディストダイアモンド」；sub 55 / 0x80e4 / mask 0xf8。
- ID 159 難題「火鼠の皮衣  -焦れぬ心-」；sub 61 / 0x8eb0 / mask 0xf1。
- ID 160 難題「火鼠の皮衣  -焦れぬ心-」；sub 61 / 0x8fa4 / mask 0xf2。
- ID 161 神宝「サラマンダーシールド」；sub 61 / 0x9098 / mask 0xf4。
- ID 162 神宝「サラマンダーシールド」；sub 61 / 0x918c / mask 0xf8。
- ID 163 難題「燕の子安貝  -永命線-」；sub 67 / 0x9df4 / mask 0xf1。
- ID 164 難題「燕の子安貝  -永命線-」；sub 67 / 0x9ee8 / mask 0xf2。
- ID 165 神宝「ライフスプリングインフィニティ」；sub 67 / 0x9fdc / mask 0xf4。
- ID 166 神宝「ライフスプリングインフィニティ」；sub 67 / 0xa0d0 / mask 0xf8。
- ID 167 難題「蓬莱の弾の枝  -虹色の弾幕-」；sub 71 / 0xaa84 / mask 0xf1。
- ID 168 難題「蓬莱の弾の枝  -虹色の弾幕-」；sub 71 / 0xab78 / mask 0xf2。
- ID 169 神宝「蓬莱の玉の枝  -夢色の郷-」；sub 71 / 0xac6c / mask 0xf4。
- ID 170 神宝「蓬莱の玉の枝  -夢色の郷-」；sub 71 / 0xad60 / mask 0xf8。
- ID 171 「永夜返し  -初月-」；sub 77 / 0xd7e8 / mask 0xf1。
- ID 172 「永夜返し  -三日月-」；sub 77 / 0xd8dc / mask 0xf2。
- ID 173 「永夜返し  -上つ弓張-」；sub 77 / 0xd9d0 / mask 0xf4。
- ID 174 「永夜返し  -待宵-」；sub 77 / 0xdac4 / mask 0xf8。
- ID 175 「永夜返し  -子の刻-」；sub 80 / 0xdf0c / mask 0xf1。
- ID 176 「永夜返し  -子の二つ-」；sub 80 / 0xe000 / mask 0xf2。
- ID 177 「永夜返し  -子の三つ-」；sub 80 / 0xe0f4 / mask 0xf4。
- ID 178 「永夜返し  -子の四つ-」；sub 80 / 0xe1e8 / mask 0xf8。
- ID 179 「永夜返し  -丑の刻-」；sub 82 / 0xe69c / mask 0xf1。
- ID 180 「永夜返し  -丑の二つ-」；sub 82 / 0xe790 / mask 0xf2。
- ID 181 「永夜返し  -丑三つ時-」；sub 82 / 0xe884 / mask 0xf4。
- ID 182 「永夜返し  -丑の四つ-」；sub 82 / 0xe978 / mask 0xf8。
- ID 183 「永夜返し  -寅の刻-」；sub 84 / 0xedb4 / mask 0xf1。
- ID 184 「永夜返し  -寅の二つ-」；sub 84 / 0xeea8 / mask 0xf2。
- ID 185 「永夜返し  -寅の三つ-」；sub 84 / 0xef9c / mask 0xf4。
- ID 186 「永夜返し  -寅の四つ-」；sub 84 / 0xf090 / mask 0xf8。
- ID 187 「永夜返し  -朝靄-」；sub 87 / 0xf648 / mask 0xf1。
- ID 188 「永夜返し  -夜明け-」；sub 87 / 0xf73c / mask 0xf2。
- ID 189 「永夜返し  -明けの明星-」；sub 87 / 0xf830 / mask 0xf4。
- ID 190 「永夜返し  -世明け-」；sub 87 / 0xf924 / mask 0xf8。

## ecldata7sp.ecl
84 个子程序；1 条timeline。完整字节码见 `reports/disassembly/ecldata7sp.ecl.txt`。

- ID 147 薬符「壺中の大銀河」；sub 9 / 0x1940 / mask 0xf1。
- ID 148 薬符「壺中の大銀河」；sub 9 / 0x1a34 / mask 0xf2。
- ID 149 薬符「壺中の大銀河」；sub 9 / 0x1b28 / mask 0xf4。
- ID 150 薬符「壺中の大銀河」；sub 9 / 0x1c1c / mask 0xf8。
- ID 151 難題「龍の頸の玉  -五色の弾丸-」；sub 40 / 0x6034 / mask 0xf1。
- ID 152 難題「龍の頸の玉  -五色の弾丸-」；sub 40 / 0x6128 / mask 0xf2。
- ID 153 神宝「ブリリアントドラゴンバレッタ」；sub 40 / 0x621c / mask 0xf4。
- ID 154 神宝「ブリリアントドラゴンバレッタ」；sub 40 / 0x6310 / mask 0xf8。
- ID 155 難題「仏の御石の鉢  -砕けぬ意思-」；sub 45 / 0x7280 / mask 0xf1。
- ID 156 難題「仏の御石の鉢  -砕けぬ意思-」；sub 45 / 0x7374 / mask 0xf2。
- ID 157 神宝「ブディストダイアモンド」；sub 45 / 0x7468 / mask 0xf4。
- ID 158 神宝「ブディストダイアモンド」；sub 45 / 0x755c / mask 0xf8。
- ID 159 難題「火鼠の皮衣  -焦れぬ心-」；sub 51 / 0x8328 / mask 0xf1。
- ID 160 難題「火鼠の皮衣  -焦れぬ心-」；sub 51 / 0x841c / mask 0xf2。
- ID 161 神宝「サラマンダーシールド」；sub 51 / 0x8510 / mask 0xf4。
- ID 162 神宝「サラマンダーシールド」；sub 51 / 0x8604 / mask 0xf8。
- ID 163 難題「燕の子安貝  -永命線-」；sub 57 / 0x926c / mask 0xf1。
- ID 164 難題「燕の子安貝  -永命線-」；sub 57 / 0x9360 / mask 0xf2。
- ID 165 神宝「ライフスプリングインフィニティ」；sub 57 / 0x9454 / mask 0xf4。
- ID 166 神宝「ライフスプリングインフィニティ」；sub 57 / 0x9548 / mask 0xf8。
- ID 167 難題「蓬莱の弾の枝  -虹色の弾幕-」；sub 61 / 0x9efc / mask 0xf1。
- ID 168 難題「蓬莱の弾の枝  -虹色の弾幕-」；sub 61 / 0x9ff0 / mask 0xf2。
- ID 169 神宝「蓬莱の玉の枝  -夢色の郷-」；sub 61 / 0xa0e4 / mask 0xf4。
- ID 170 神宝「蓬莱の玉の枝  -夢色の郷-」；sub 61 / 0xa1d8 / mask 0xf8。
- ID 171 「永夜返し  -初月-」；sub 67 / 0xcc60 / mask 0xf1。
- ID 172 「永夜返し  -三日月-」；sub 67 / 0xcd54 / mask 0xf2。
- ID 173 「永夜返し  -上つ弓張-」；sub 67 / 0xce48 / mask 0xf4。
- ID 174 「永夜返し  -待宵-」；sub 67 / 0xcf3c / mask 0xf8。
- ID 175 「永夜返し  -子の刻-」；sub 70 / 0xd384 / mask 0xf1。
- ID 176 「永夜返し  -子の二つ-」；sub 70 / 0xd478 / mask 0xf2。
- ID 177 「永夜返し  -子の三つ-」；sub 70 / 0xd56c / mask 0xf4。
- ID 178 「永夜返し  -子の四つ-」；sub 70 / 0xd660 / mask 0xf8。
- ID 179 「永夜返し  -丑の刻-」；sub 72 / 0xdb14 / mask 0xf1。
- ID 180 「永夜返し  -丑の二つ-」；sub 72 / 0xdc08 / mask 0xf2。
- ID 181 「永夜返し  -丑三つ時-」；sub 72 / 0xdcfc / mask 0xf4。
- ID 182 「永夜返し  -丑の四つ-」；sub 72 / 0xddf0 / mask 0xf8。
- ID 183 「永夜返し  -寅の刻-」；sub 74 / 0xe22c / mask 0xf1。
- ID 184 「永夜返し  -寅の二つ-」；sub 74 / 0xe320 / mask 0xf2。
- ID 185 「永夜返し  -寅の三つ-」；sub 74 / 0xe414 / mask 0xf4。
- ID 186 「永夜返し  -寅の四つ-」；sub 74 / 0xe508 / mask 0xf8。
- ID 187 「永夜返し  -朝靄-」；sub 77 / 0xeac0 / mask 0xf1。
- ID 188 「永夜返し  -夜明け-」；sub 77 / 0xebb4 / mask 0xf2。
- ID 189 「永夜返し  -明けの明星-」；sub 77 / 0xeca8 / mask 0xf4。
- ID 190 「永夜返し  -世明け-」；sub 77 / 0xed9c / mask 0xf8。
- ID 210 「蓬莱の樹海」；sub 79 / 0xf870 / mask 0xff。

## ecldata8.ecl
156 个子程序；2 条timeline。完整字节码见 `reports/disassembly/ecldata8.ecl.txt`。

- ID 191 旧史「旧秘境史　-オールドヒストリー-」；sub 51 / 0x3fa4 / mask 0xff。
- ID 192 転世「一条戻り橋」；sub 56 / 0x4cbc / mask 0xff。
- ID 193 新史「新幻想史　-ネクストヒストリー-」；sub 60 / 0x55a0 / mask 0xff。
- ID 194 時効「月のいはかさの呪い」；sub 93 / 0x9fc4 / mask 0xff。
- ID 195 不死「火の鳥　-鳳翼天翔-」；sub 97 / 0xa600 / mask 0xff。
- ID 196 藤原「滅罪寺院傷」；sub 100 / 0xb7e0 / mask 0xff。
- ID 197 不死「徐福時空」；sub 103 / 0xbc40 / mask 0xff。
- ID 198 滅罪「正直者の死」；sub 108 / 0xc4c0 / mask 0xff。
- ID 199 虚人「ウー」；sub 113 / 0xcb88 / mask 0xff。
- ID 200 不滅「フェニックスの尾」；sub 118 / 0xd330 / mask 0xff。
- ID 201 蓬莱「凱風快晴　-フジヤマヴォルケイノ-」；sub 126 / 0xdcc0 / mask 0xff。
- ID 202 「パゼストバイフェニックス」；sub 131 / 0xe764 / mask 0xff。
- ID 203 「蓬莱人形」；sub 143 / 0xf5c8 / mask 0xff。
- ID 204 「インペリシャブルシューティング」；sub 149 / 0xfce8 / mask 0xff。

## ecldata8sp.ecl
117 个子程序；1 条timeline。完整字节码见 `reports/disassembly/ecldata8sp.ecl.txt`。

- ID 191 旧史「旧秘境史　-オールドヒストリー-」；sub 5 / 0x1338 / mask 0xff。
- ID 192 転世「一条戻り橋」；sub 10 / 0x2050 / mask 0xff。
- ID 193 新史「新幻想史　-ネクストヒストリー-」；sub 14 / 0x2934 / mask 0xff。
- ID 194 時効「月のいはかさの呪い」；sub 47 / 0x7358 / mask 0xff。
- ID 195 不死「火の鳥　-鳳翼天翔-」；sub 51 / 0x7994 / mask 0xff。
- ID 196 藤原「滅罪寺院傷」；sub 54 / 0x8b74 / mask 0xff。
- ID 197 不死「徐福時空」；sub 57 / 0x8fd4 / mask 0xff。
- ID 198 滅罪「正直者の死」；sub 62 / 0x9854 / mask 0xff。
- ID 199 虚人「ウー」；sub 67 / 0x9f1c / mask 0xff。
- ID 200 不滅「フェニックスの尾」；sub 72 / 0xa6c4 / mask 0xff。
- ID 201 蓬莱「凱風快晴　-フジヤマヴォルケイノ-」；sub 80 / 0xb054 / mask 0xff。
- ID 202 「パゼストバイフェニックス」；sub 85 / 0xbaf8 / mask 0xff。
- ID 203 「蓬莱人形」；sub 97 / 0xc95c / mask 0xff。
- ID 204 「インペリシャブルシューティング」；sub 103 / 0xd07c / mask 0xff。
- ID 211 「フェニックス再誕」；sub 110 / 0xf9ac / mask 0xff。
- ID 213 「無何有浄化」；sub 113 / 0x10fcc / mask 0xff。

## ecldata_al.ecl
9 个子程序；1 条timeline。完整字节码见 `reports/disassembly/ecldata_al.ecl.txt`。

- ID 218 「グランギニョル座の怪人」；sub 1 / 0x204 / mask 0xff。

## ecldata_rm.ecl
9 个子程序；1 条timeline。完整字节码见 `reports/disassembly/ecldata_rm.ecl.txt`。

- ID 219 「スカーレットディスティニー」；sub 1 / 0x204 / mask 0xff。

## ecldata_sk.ecl
10 个子程序；1 条timeline。完整字节码见 `reports/disassembly/ecldata_sk.ecl.txt`。

- ID 216 「デフレーションワールド」；sub 1 / 0x224 / mask 0xff。

## ecldata_yk.ecl
20 个子程序；1 条timeline。完整字节码见 `reports/disassembly/ecldata_yk.ecl.txt`。

- ID 221 「深弾幕結界　-夢幻泡影-」；sub 4 / 0xf3c / mask 0xff。

## ecldata_ym.ecl
12 个子程序；1 条timeline。完整字节码见 `reports/disassembly/ecldata_ym.ecl.txt`。

- ID 217 「待宵反射衛星斬」；sub 1 / 0x21c / mask 0xff。

## ecldata_yy.ecl
12 个子程序；1 条timeline。完整字节码见 `reports/disassembly/ecldata_yy.ecl.txt`。

- ID 220 「西行寺無余涅槃」；sub 1 / 0x210 / mask 0xff。
