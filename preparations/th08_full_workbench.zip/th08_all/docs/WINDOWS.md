# Windows 上机指南与接入契约

## 当前能运行到哪里

本包可直接在Windows构建并运行资源分析、原生几何/延迟路径实验和追踪检查；**没有已经连上原版的实时代理**。C++编译和计算测试在Linux做过，本次没有在Windows运行过这些命令。这里既给出可立即执行的命令，也列明需要在游戏侧补上的接口，不把接口文档叫作已经实现的桥。

## 1. 环境与身份

使用Python 3.10或更新版本，标准库即可，不需要pip依赖。原生测试需要CMake和支持C++17的编译器，例如Visual Studio开发者命令提示符。为避免旧编译缓存干扰，Windows重新创建build目录。

```powershell
cd D:\th08_all
py -3 windows\preflight.py --dat D:\Games\th08\th08.dat --exe D:\Games\th08\th08.exe
```

这只读文件，不启动/注入/修改进程。哈希不符时退出2，先识别版本差异再使用地址或假设。匹配只代表身份，不代表模型已验证。

源码版本：

```powershell
py -3 windows\preflight.py --dat D:\Games\th08\th08.dat --source D:\src\th08
```

预期源码提交为a45e99fb1942714e6edded20847e32a654d56f97。提交不同或有本地改动不是说你的代码错误，而是本包的已有结果不能不经重新验证直接套用。

## 2. 一条命令复现工作台

```powershell
py -3 tools\run_all.py --dat D:\Games\th08\th08.dat --mode all
```

仅重建分析与基础单测：

```powershell
py -3 tools\run_all.py --dat D:\Games\th08\th08.dat --mode quick
```

all会重跑全入口、214条描述符轨迹和88个条件场景；quick保留附带的历史计算结果供浏览，不将它们称为本机新跑的结果。查看 `reports\run_receipt.json` 区分。

运行后双击index.html。页面无外部脚本、字体或CDN，直接file://打开即可。主报告和逐符卡档案为UTF-8 Markdown。

## 3. 原生控制器单独构建与运行

```powershell
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release --parallel 2
ctest --test-dir build -C Release --output-on-failure
py -3 tools\bench_cases.py --keep-scenes
```

Visual Studio通常输出 `build\Release\th08lab_planner.exe`；单配置生成器通常输出 `build\th08lab_planner.exe`。脚本会检测这两个位置。

单个场景示例：

```powershell
build\Release\th08lab_planner.exe build\scenes\<case-key>.txt 64 8 greedy
```

参数依次为输入场景、beam宽度、**搜索**预算毫秒、方法。8ms不包含文件读取/建索引，也不是完整帧预算；文本文件模式只用于实验，实时应改用内存接口。budget=0是离线不设搜索上限。

输出里的 `actions` 是内部方向编号：0不动、1上、2右上、3右、4右下、5下、6左下、7左、8左上。**它们不是原版replay bitmask，也不是Windows虚拟键值。** 该控制器固定focus，不模拟射击、bomb或完整形态副作用。

## 4. 使用实际源码测试运动函数

```powershell
py -3 tools\source_probe.py --source D:\src\th08 --out build\source_probe --generate-only
cl /std:c++17 /O2 /EHsc build\source_probe\source_motion_probe.cpp /Fe:build\source_probe\source_motion_probe.exe
build\source_probe\source_motion_probe.exe
```

它自动提取8个函数体，外部计时/三角函数/玩家/声音是明确stub。8192测试通过只验证这套不变量；不等于完整世界或原版二进制对照。MinGW/GCC可直接省略generate-only并指定compiler。

## 5. 优先利用dat自带的真实演示输入

```powershell
py -3 windows\export_demo_inputs.py
```

生成CSV与初始状态元数据到 `build\demo_inputs`。四个demo的校验和都已验证，difficulty字段为3，普通记录格式不是extended格式；**没有逐帧事件标志和RNG oracle**。

CSV的序号是序列化输入记录位置，不是墙钟帧。原版会在消息、暂停、stage-clear等状态下按自己的条件消费输入。用于首次验证时，优先使用原版自己的replay加载与消费路径，而不是用sleep(16ms)读CSV注入键盘。

需要从你自己的dat解出.rpy供游戏读取时，文件在本地private目录；包内不分发原始replay二进制。文件名、原始哈希和解码元数据可逐项核对。

## 6. 游戏侧接口：必须补足，不能以猜测地址代替

建议第一阶段只加观测，不控制键盘。对重构游戏使用类型明确的源码接口；对原版需要版本绑定的观测桥。不要将portable64结构偏移用到original32，也不要把一个成功ReadProcessMemory调用当作一致快照。

每次观测至少携带：

- run身份、原版exe/dat配置身份、frame和**逻辑阶段**；
- 原版已经采样的输入、实际消费输入，以及不可撤销的输入队列；
- 玩家位置、hurtbox、真实形态/过渡计数、生命状态与必要伤害/子机状态；
- ECL主/子上下文、PC、局部与secondary时钟、call栈、插值槽和逐帧callback；
- 弹丸slot与generation、状态/角度/速度/活动变换/计时/出生与消失VM/判定标志；
- Laser池、直接EX判定、敌人本体与拖尾；
- 全局RNG、rank/subrank、时间倍率/冻结、伤害与清弹事件。

这不是说每帧都必须通过IPC搬完整所有数组。初期为了对照可完整记录；后期按相关性分块、增量、共享不可变数据。先正确，再测成本和缩减。

**禁止仅用前后帧号相等来宣称一致：同一帧中各manager可能已经处在不同阶段。** 源码侧应在明确计算链边界采样；原版桥要证明其观测边界或返回UNKNOWN，而非伪造coherent=true。

## 7. 追踪协议与差分工具

本包实现 `TH08_TRACE_V1` JSONL读取和第一个差异定位，示例在 `examples\trace_ok.jsonl`。目前示例是测试夹具，不是原版日志。

```powershell
py -3 windows\trace_check.py examples\trace_ok.jsonl --reference examples\trace_ok.jsonl
py -3 windows\trace_check.py build\reconstructed.jsonl --reference build\original.jsonl
```

协议支持input_sample/player_pre/player_post/enemy_post/bullet_post/frame_end。实体数组按slot和generation排序。PC使用资源内偏移，不跨实现比较裸指针。生产者必须保证phase和coherent字段属实；本工具只能检查声明与结构，不能替观测桥证明原子性。

比较顺序宜先输入，再ECL/RNG/生成销毁，再运动，再几何与致死结果。浮点容差可用于定位，但离散分支、生成帧或碰撞结果改变后不能以“距离误差很小”判定通过。

追踪工具统计bomb事件bit0x1、死亡提交bit0x4和碰撞bit0x2。无敌时碰撞不一定是miss；局部trace没死亡也不等于全程通关。完整验收还需要run首尾、clear和不中断运行证据。

## 8. 正常输入链验收，不等同于replay验收

正常路径中，玩家更新使用的输入与设备采样之间存在交接；replay装入输入的链位置不同。第一次先测单方向脉冲、释放、对角、focus，记录采样和实际消费时刻。之后规划先推进已经不能撤销的输入前缀，再计算可修改后缀。

最终代理只输出合法键位。不修改坐标、碰撞、敌人、随机状态或速度，不在验证中暂停主游戏等规划器算完。离线可暂停/回退/分叉，但它们不能混入实时NMNB成绩。

deadline以最晚可提交时刻确定，不以“60Hz大约16ms”猜测。任何输入失约和预测失效都必须记录；过期输入方案不自动具备安全性。首次接管应选已通过差分验证的片段，并能立即人工退出，但不要用这些局部成功宣称全程完成。

## 9. 下一道实质工程门槛

本包没有完整游戏快照恢复／分叉，也没有原版进程输入桥。上线前需把参考执行器的世界状态闭合，或在原版oracle上做足够的状态转移对照；再把已验证预测内核原生化，并测完整观测→预测→搜索→核验→提交链。

当前工具能直接帮助识别第一个缺字段、第一处错误时序和第一类预算退化；不能替代这些尚未写完的集成工作。
