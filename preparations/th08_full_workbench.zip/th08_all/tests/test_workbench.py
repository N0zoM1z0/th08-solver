import json,sys,unittest,math,struct,tempfile
from pathlib import Path
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R))
from th08lab.emitter import Emitter,RNG,f32,normalize
from th08lab.ecl import parse
from th08lab.protocol import DIFFS
from th08lab.kinematics import World,templates,Bullet,UnsupportedWorld,within
from th08lab.special import LaserState,reisen_phase,warp
class Workbench(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.e={e['file']:e for e in json.loads((R/'reports/ecl.json').read_text())};cls.a=next(a for a in json.loads((R/'reports/anm.json').read_text())if a['file']=='etama.anm');cls.tpl=templates(cls.a)
 def event(self,flags=0,tf=None,mode=99,n=1):return dict(args=[0,0,n,1,1.,1.,0.,0.,flags],opcode=mode,transforms=tf or{},offset=[0.,0.])
 def test_all_ecl_structures(self):
  self.assertEqual(len(self.e),24);self.assertEqual(sum(len(e['subs'])for e in self.e.values()),1449)
  for e in self.e.values():
   for s in e['subs']:
    boundaries={i['pc']for i in s['instructions']}
    for i in s['instructions']:
     if'jump'in i:self.assertIn(i['jump'],boundaries)
     if i['opcode'] not in (-1,122):self.assertIsNotNone(i['args'],(e['file'],i['pc']))
 def test_truncated_ecl_rejected(self):
  for data in (b'',b'\0'*20,(R/'private/ecldata1.ecl').read_bytes()[:100]):
   with self.assertRaises((ValueError,AssertionError,struct.error,IndexError)):parse(data,'bad')
 def test_all_spells(self):
  spells=json.loads((R/'reports/spells.json').read_text());self.assertEqual(len(spells),431);self.assertEqual({s['id']for s in spells},set(range(222)))
  self.assertTrue(all(s['solution'] is None for s in spells))
 def test_extra_mask_is_not_bit16(self):
  self.assertEqual(DIFFS['extra_or_lastword'],15);self.assertNotEqual(DIFFS['extra_or_lastword'],16);self.assertEqual(0x3f&0x2f,0x2f);self.assertNotEqual(0x5f&0x2f,0x2f)
 def test_firefly_real_emitter(self):
  for sub in(40,41):
   v=Emitter(self.e['ecldata1.ecl'],sub,8).run(361);self.assertEqual(v['status'],'RETURNED_SLICE');self.assertEqual(v['nominal_requests'],840)
 def test_familiar_real_masks(self):
  h=Emitter(self.e['ecldata1.ecl'],42,0x28).run(120);y=Emitter(self.e['ecldata1.ecl'],42,0x48).run(120)
  self.assertEqual((h['nominal_requests'],y['nominal_requests']),(30,6))
 def test_unknown_is_not_noop(self):
  v=Emitter(self.e['ecldata1.ecl'],0,8).run(120);self.assertEqual(v['status'],'BLOCKED')
 def test_rng_float_casts(self):
  r=RNG(0);r.u32=lambda:0x1000001
  self.assertEqual(r.unit(),f32(16777216/4294967296))
  r.u32=lambda:0xffffffff;self.assertEqual(r.unit(),1.0)
 def test_normalize_source_iteration_guard(self):
  self.assertGreater(normalize(200.0),f32(math.pi))
 def test_positive_float_pi_not_wrapped(self):
  self.assertEqual(normalize(f32(math.pi)),f32(math.pi))
 def test_rng_full_cycle(self):
  r=RNG(0);seen=set()
  for _ in range(65536):seen.add(r.u16())
  self.assertEqual(len(seen),65536);self.assertEqual(r.seed,0)
 def test_layer_divisor_count(self):
  w=World(self.tpl);e=self.event();e['args'][2:6]=[1,2,1.4,.8];w.spawn_pattern(e)
  b=[b for b in w.pool if b is not None];self.assertAlmostEqual(b[0].speed,1.4,5);self.assertAlmostEqual(b[1].speed,1.1,5)
 def test_wait_does_not_stop_movement(self):
  w=World(self.tpl);e=self.event(131072,{0:[131072,0,2,0,0,0]});boxes=w.step([e]);self.assertAlmostEqual(boxes[0][0],193);self.assertTrue(w.pool[0].active&131072)
 def test_gated_transform_skipped(self):
  w=World(self.tpl);e=self.event(0,{0:[128,0,1,1,0,2]});w.step([e]);self.assertEqual(w.pool[0].idx,1)
 def test_unknown_target_fails(self):
  w=World(self.tpl)
  with self.assertRaises(UnsupportedWorld):w.step([self.event(mode=96)])
 def test_direction_interval_and_repeat0(self):
  w=World(self.tpl);e=self.event(256,{0:[256,0,0,0,math.pi/2,2]});w.step([e]);self.assertFalse(w.pool[0].active&256);self.assertAlmostEqual(w.pool[0].v[1],2,5)
 def test_vector_polar_concurrency(self):
  w=World(self.tpl);e=self.event(48,{0:[16,0,4,0,.1,0],1:[32,1,4,0,.2,.1]});w.step([e]);self.assertEqual(w.pool[0].active&48,48)
 def test_bounce_zero_limit(self):
  w=World(self.tpl,origin=(-6,128));e=self.event(1024,{0:[1024,0,0,0,1,0]});w.step([e]);b=w.pool[0];self.assertFalse(b.active&1024);self.assertLess(b.v[0],0)
 def test_wrap_equality_and_shared_timer(self):
  w=World(self.tpl,origin=(384,200));e=self.event(4194304,{0:[4194304,0,0,0,0,0]});e['args'][4]=0;w.step([e]);self.assertEqual(w.pool[0].p[0],384);self.assertFalse(w.pool[0].active&4194304)
 def test_spawn_lifecycle(self):
  w=World(self.tpl);e=self.event(2);self.assertEqual(w.step([e]),[])
  for _ in range(8):self.assertEqual(w.step([]),[])
  self.assertTrue(w.step([]));self.assertEqual(w.pool[0].state,'fired')
 def test_child_record_pair_and_cursor(self):
  w=World(self.tpl);packed=(3<<24)|3;tf={0:[16777216,0,packed,2,1,1],1:[0,0,1,0,0,0]};w.spawn_pattern(self.event(16777216,tf));self.assertEqual(w.spawned,3);self.assertEqual(w.cursor,1)
 def test_pool_cap_does_not_create_objects(self):
  w=World(self.tpl,capacity=3);w.step([self.event(n=8)]);self.assertEqual(w.spawned,3);self.assertEqual(w.dropped,5)
 def test_reisen_collision_not_visibility(self):
  t,d,_=reisen_phase(1,False);self.assertEqual((t,d),(0,True));t,d,_=reisen_phase(t,d);self.assertEqual((t,d),(2,True));t,d,_=reisen_phase(t,d);self.assertEqual((t,d),(1,False))
 def test_warp_cooldown(self):
  p,v,a,c=warp((123,208),(-2,0),0,0,'narrow');self.assertEqual(c,2);self.assertEqual(v,(2,0));p2,v2,a2,c2=warp(p,v,a,c,'narrow');self.assertEqual(p2,p);self.assertEqual(c2,1)
 def test_laser_fallthrough_calls(self):
  l=LaserState(start_time=1,duration=0,despawn_time=3,hitbox_start=0,hitbox_end=1,flags=1,timer=1)
  calls=l.step();self.assertEqual([x['state']for x in calls],[0,1,2])
 def test_laser_width_is_not_drawn_width(self):
  l=LaserState(hitbox_start=0);call=l.step()[0];self.assertAlmostEqual(call['full_size'][0],.6,6);self.assertEqual(call['full_size'][1],8)
 def test_sht_complete(self):
  s=json.loads((R/'reports/sht.json').read_text());self.assertEqual(sum(len(l['descriptors'])for x in s for l in x['power_levels']),227);self.assertTrue(all(x['unparsed_bytes']==0 for x in s))
if __name__=='__main__':unittest.main(verbosity=2)
