import json,unittest,sys,tempfile,copy
from pathlib import Path
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R))
from th08lab.trace import read,first_difference,audit
from th08lab.auxiliary import replay,stage,dialogue
class Auxiliary(unittest.TestCase):
 def test_replay_checksums(self):
  files=sorted((R/'private').glob('*.rpy'));self.assertEqual(len(files),4)
  self.assertTrue(all(replay(f)['checksum_valid']for f in files))
 def test_stages(self):
  self.assertEqual(sum(len(stage(p)['objects'])for p in (R/'private').glob('*.std')),68)
 def test_dialogues(self):
  self.assertEqual(sum(len(dialogue(p)['messages'])for p in(R/'private').glob('msg*.dat')),144)
 def test_trace_first_difference(self):
  a=read(R/'examples/trace_ok.jsonl');b=copy.deepcopy(a);b[1]['rng_seed']=43
  self.assertEqual(first_difference(a,b)['path'],'/rng_seed');self.assertIsNone(first_difference(a,a))
 def test_trace_invalid_coherence(self):
  a=read(R/'examples/trace_ok.jsonl');a[0]['coherent']=False
  with tempfile.TemporaryDirectory()as d:
   p=Path(d)/'x';p.write_text(json.dumps(a[0]))
   with self.assertRaises(ValueError):read(p)
 def test_nmnb_events(self):
  a=read(R/'examples/trace_ok.jsonl');a[0]['events']=2;a[1]['events']=1|4
  q=audit(a);self.assertEqual(q['collision_event_frames'],1);self.assertEqual(q['death_committed_frames'],1);self.assertEqual(q['bomb_event_frames'],1)
if __name__=='__main__':unittest.main()
