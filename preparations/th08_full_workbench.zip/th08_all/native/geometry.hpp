#pragma once
// Source-semantic geometric predicates; no game globals, RNG or state mutations.
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <stdexcept>
#include <vector>
namespace th08lab {
struct Vec { float x=0,y=0; };
struct Box { float x=0,y=0,hx=0,hy=0; };
struct Laser { Vec origin,center; float width=0,height=0,angle=0; };
inline bool bullet_hit(Vec p,Vec ph,Box b,float margin=0) {
 return !(p.x-ph.x-margin>b.x+b.hx || p.y-ph.y-margin>b.y+b.hy ||
          p.x+ph.x+margin<b.x-b.hx || p.y+ph.y+margin<b.y-b.hy);
}
inline bool laser_hit(Vec p,Vec ph,const Laser& l,float margin=0) {
 float dx=p.x-l.origin.x,dy=p.y-l.origin.y;
 float c=std::cos(l.angle),s=std::sin(l.angle);
 Vec q{dx*c+dy*s+l.origin.x,-dx*s+dy*c+l.origin.y};
 // Retail predicate keeps the player's half-size axis-aligned in this frame.
 return bullet_hit(q,ph,{l.center.x,l.center.y,l.width*.5f,l.height*.5f},margin);
}
struct Motion {float normal=4,focus=2,normal_diag=2.8284270763397217f,focus_diag=1.4142135381698608f;};
// action 0..8: stay,N,NE,E,SE,S,SW,W,NW. Opposing keys are not emitted.
inline Vec move(Vec p,int action,bool focus,const Motion&m){
 static constexpr int dx[9]={0,0,1,1,1,0,-1,-1,-1},dy[9]={0,-1,-1,0,1,1,1,0,-1};
 if(action<0||action>8)throw std::invalid_argument("action");
 float v=(dx[action]&&dy[action])?(focus?m.focus_diag:m.normal_diag):(focus?m.focus:m.normal);
 return {std::clamp(p.x+dx[action]*v,8.0f,376.0f),std::clamp(p.y+dy[action]*v,16.0f,432.0f)};
}
inline unsigned consume(unsigned &queue,unsigned request,int delay){
 if(delay<0||delay>4||request>8)throw std::invalid_argument("queue");
 if(!delay)return request;
 unsigned result=queue&15;queue=(queue>>4)|(request<<(4*(delay-1)));return result;
}
struct Form {bool focus=false,youkai=false;int held=0;int solo=-1;
 void step(bool f){held=f!=focus?0:held+1;focus=f;if(solo>=0)youkai=solo!=0;else if(held>=7)youkai=f;}
};
class FrameIndex {
 static constexpr int NX=24,NY=28;
 std::vector<std::vector<int>> buckets;
 Vec ph;float margin;
public:
 std::vector<Box> boxes;std::vector<Laser> lasers;
 FrameIndex():buckets(NX*NY),ph{1,1},margin(0){}
 void build(Vec half,float extra){ph=half;margin=extra;for(auto&b:buckets)b.clear();
  for(int i=0;i<int(boxes.size());++i){const auto&b=boxes[i];
   float x0=b.x-b.hx-ph.x-extra,x1=b.x+b.hx+ph.x+extra;
   float y0=b.y-b.hy-ph.y-extra,y1=b.y+b.hy+ph.y+extra;
   if(x1<0||y1<0||x0>=384||y0>=448)continue;
   int ix0=std::max(0,int(std::floor(x0/16))),ix1=std::min(NX-1,int(std::floor(x1/16)));
   int iy0=std::max(0,int(std::floor(y0/16))),iy1=std::min(NY-1,int(std::floor(y1/16)));
   for(int y=iy0;y<=iy1;++y)for(int x=ix0;x<=ix1;++x)buckets[y*NX+x].push_back(i);
  }
 }
 bool hit(Vec p)const{
  if(p.x<8||p.x>376||p.y<16||p.y>432)return true;
  const auto& ids=buckets[int(p.y/16)*NX+int(p.x/16)];
  for(int i:ids)if(bullet_hit(p,ph,boxes[i],margin))return true;
  for(const auto&l:lasers)if(laser_hit(p,ph,l,margin))return true;
  return false;
 }
 float clearance_cost(Vec p)const{
  // Heuristic only. Not a safety proof and not a full nearest-obstacle query.
  float result=16;
  for(int i:buckets[int(p.y/16)*NX+int(p.x/16)]){
   const auto& b=boxes[i];float d=std::max(std::abs(p.x-b.x)-b.hx-ph.x,std::abs(p.y-b.y)-b.hy-ph.y);
   result=std::min(result,d);
  }
  return std::max(result,0.0f);
 }
 bool brute_hit(Vec p)const{for(auto&b:boxes)if(bullet_hit(p,ph,b,margin))return true;for(auto&l:lasers)if(laser_hit(p,ph,l,margin))return true;return false;}
};
}
