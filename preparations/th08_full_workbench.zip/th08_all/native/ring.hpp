#pragma once
#include "geometry.hpp"
#include <numeric>
namespace th08lab {
// Conservative angular broad phase for an IDEAL ring with caller-provided
// position error bound. Exact per-bullet rectangles must still be checked.
inline std::vector<int> ring_candidates(Vec p,Vec c,double r,double phase,int n,double rho,double model_error){
 if(n<1||n>100000||r<0||rho<0||model_error<0||!std::isfinite(r)||!std::isfinite(rho)||!std::isfinite(model_error)||!std::isfinite(phase)||!std::isfinite(p.x)||!std::isfinite(p.y)||!std::isfinite(c.x)||!std::isfinite(c.y))throw std::invalid_argument("ring");
 constexpr double TAU=6.283185307179586476925286766559;
 double x=p.x-c.x,y=p.y-c.y,R=std::hypot(x,y),e=rho+model_error;
 if(std::abs(R-r)>e)return {};
 if(R==0||r==0||R+r<=e){std::vector<int> all(n);std::iota(all.begin(),all.end(),0);return all;}
 double phi=std::atan2(y,x),half=std::acos(std::clamp((R*R+r*r-e*e)/(2*R*r),-1.0,1.0));
 double center=std::remainder(phi-phase,TAU)*n/TAU,delta=half*n/TAU;
 int lo=int(std::ceil(center-delta))-1,hi=int(std::floor(center+delta))+1;
 if(hi-lo+1>=n){std::vector<int> all(n);std::iota(all.begin(),all.end(),0);return all;}
 std::vector<int> out;for(int j=lo;j<=hi;++j)out.push_back((j%n+n)%n);return out;
}
}
