#include "geometry.hpp"
#include "ring.hpp"
#include <iostream>
#include <random>
#include <stdexcept>
using namespace th08lab;
void require(bool v,const char*msg){if(!v)throw std::runtime_error(msg);}
int main(){try{
 require(bullet_hit({3,0},{1,1},{0,0,2,2}),"closed boundary");
 require(!bullet_hit({3.001f,0},{1,1},{0,0,2,2}),"outside");
 Laser l{{0,0},{10,0},20,4,1.5707963267948966f};
 require(laser_hit({0,10},{1,1},l),"rotated laser");require(!laser_hit({4,10},{1,1},l),"rotated outside");
 Form f;f.held=20;for(int i=0;i<7;++i){f.step(true);require(!f.youkai,"switch too early");}f.step(true);require(f.youkai,"switch eighth input");
 Form solo;solo.solo=0;for(int i=0;i<20;++i)solo.step(true);require(!solo.youkai,"solo mode");
 unsigned q=0;require(consume(q,3,2)==0,"delay first");require(consume(q,7,2)==0,"delay second");require(consume(q,0,2)==3,"delay third");
 Motion m;Vec p=move({375,431},4,false,m);require(p.x==376&&p.y==432,"clamp");
 p=move({192,352},2,true,m);require(p.x==192+m.focus_diag&&p.y==352-m.focus_diag,"diag from data");
 std::mt19937 rng(1729);std::uniform_real_distribution<float>x(-50,434),y(-50,498),sz(.1,40),px(8,376),py(16,432),angle(-3.14f,3.14f);
 int queries=0;
 for(int round=0;round<20;++round){FrameIndex idx;for(int i=0;i<1536;++i)idx.boxes.push_back({x(rng),y(rng),sz(rng),sz(rng)});
  for(int i=0;i<8;++i)idx.lasers.push_back({{192,100},{240,100},80,2,angle(rng)});
  idx.build({.825f,.825f},.2f);
  for(int i=0;i<5000;++i){Vec v{px(rng),py(rng)};require(idx.hit(v)==idx.brute_hit(v),"index false decision");++queries;}
 }
 int ring_queries=0;std::uint64_t brute_ring=0,candidate_ring=0;
 for(int n:{1,2,5,9,16,24,32,48,56,64,96,128,144,192,256,360}){
  for(int j=0;j<1000;++j){Vec c{192,208},p{px(rng),py(rng)};double r=sz(rng)*8,phase=angle(rng),rho=4;
   if(j%2==0){double phi=angle(rng),rad=r+(j%9-4);p={float(c.x+rad*std::cos(phi)),float(c.y+rad*std::sin(phi))};}
   auto candidates=ring_candidates(p,c,r,phase,n,rho,.0025);candidate_ring+=candidates.size();brute_ring+=n;
   for(int k=0;k<n;++k){double a=phase+6.283185307179586*k/n;Vec q{float(c.x+r*std::cos(a)),float(c.y+r*std::sin(a))};
    if(std::hypot(double(p.x-q.x),double(p.y-q.y))<=rho)require(std::find(candidates.begin(),candidates.end(),k)!=candidates.end(),"ring false negative");
   }++ring_queries;
  }
 }
 std::cout<<"{\"ring_queries\":"<<ring_queries<<",\"ring_full_scan_pairs\":"<<brute_ring<<",\"ring_candidates\":"<<candidate_ring<<",\"checks\":\"AABB, laser local frame, focus state, delay, clamp, diagonal, spatial index\",\"random_geometry_queries\":"<<queries<<",\"mismatches\":0,\"scope\":\"internal predicate equivalence; not original-game validation\"}\n";return 0;
 }catch(std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
