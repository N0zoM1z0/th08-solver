#include "geometry.hpp"
#include <chrono>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>
#include <unordered_set>
#include <limits>
using namespace th08lab;
struct Scene {int h,delay;bool focused;Vec initial,half;Motion motion;float margin;unsigned initial_queue;std::vector<FrameIndex> f;};
static Scene read_scene(const std::string&path){
 std::ifstream in(path);std::string tag;in>>tag;if(tag!="TH08LAB_FORECAST_V1")throw std::runtime_error("forecast signature");
 Scene s{};int independent,focused;in>>s.h>>s.delay>>focused>>independent>>s.initial.x>>s.initial.y>>s.half.x>>s.half.y>>s.margin;
 in>>s.motion.normal>>s.motion.focus>>s.motion.normal_diag>>s.motion.focus_diag>>s.initial_queue;
 if(!in||s.h<1||s.h>600||s.delay<0||s.delay>4||independent!=1||focused<0||focused>1||!std::isfinite(s.margin)||s.margin<0)throw std::runtime_error("unsupported scene contract");
 for(float v:{s.initial.x,s.initial.y,s.half.x,s.half.y,s.motion.normal,s.motion.focus,s.motion.normal_diag,s.motion.focus_diag})
  if(!std::isfinite(v))throw std::runtime_error("non-finite scene header");
 if(s.initial.x<8||s.initial.x>376||s.initial.y<16||s.initial.y>432||s.half.x<0||s.half.y<0||s.motion.normal<0||s.motion.focus<0||s.motion.normal_diag<0||s.motion.focus_diag<0)throw std::runtime_error("invalid scene header");
 unsigned qq=s.initial_queue;for(int i=0;i<s.delay;++i){if((qq&15)>8)throw std::runtime_error("invalid initial queue");qq>>=4;}
 if(qq)throw std::runtime_error("queue exceeds delay");
 s.focused=focused!=0;s.f.resize(s.h);
 for(int t=0;t<s.h;++t){int n,m;in>>n>>m;if(!in||n<0||n>20000||m<0||m>512)throw std::runtime_error("forecast object bound");
  s.f[t].boxes.resize(n);s.f[t].lasers.resize(m);
  for(auto&b:s.f[t].boxes){in>>b.x>>b.y>>b.hx>>b.hy;if(!in||!std::isfinite(b.x)||!std::isfinite(b.y)||!std::isfinite(b.hx)||!std::isfinite(b.hy)||b.hx<0||b.hy<0||std::abs(b.x)>1000000||std::abs(b.y)>1000000||b.hx>1000000||b.hy>1000000)throw std::runtime_error("invalid box");}
  for(auto&l:s.f[t].lasers){in>>l.origin.x>>l.origin.y>>l.center.x>>l.center.y>>l.width>>l.height>>l.angle;if(!in||!std::isfinite(l.origin.x)||!std::isfinite(l.origin.y)||!std::isfinite(l.center.x)||!std::isfinite(l.center.y)||!std::isfinite(l.angle)||!std::isfinite(l.width)||!std::isfinite(l.height)||l.width<0||l.height<0||std::abs(l.origin.x)>1000000||std::abs(l.origin.y)>1000000||std::abs(l.center.x)>1000000||std::abs(l.center.y)>1000000||l.width>1000000||l.height>1000000)throw std::runtime_error("invalid laser");}
  s.f[t].build(s.half,s.margin);
 }
 std::string extra;if(in>>extra)throw std::runtime_error("extra forecast tokens");return s;
}
struct Node{Vec p;unsigned q;float score;int parent,request;};
int main(int argc,char**argv){try{
 if(argc<2){std::cerr<<"Usage: th08lab_planner scene.txt [beam=128] [budget_ms=0] [method=beam|greedy|stay]\n";return 2;}
 int beam=argc>2?std::stoi(argv[2]):128;double budget=argc>3?std::stod(argv[3]):0;std::string method=argc>4?argv[4]:"beam";
 if(beam<1||beam>4096||budget<0||!std::isfinite(budget))throw std::runtime_error("planner options");
 if(method!="beam"&&method!="greedy"&&method!="stay")throw std::runtime_error("method");
 auto begin=std::chrono::steady_clock::now();auto s=read_scene(argv[1]);auto search_start=std::chrono::steady_clock::now();
 std::vector<std::vector<Node>> layers{{Node{s.initial,s.initial_queue,0,-1,0}}};std::uint64_t expansions=0;std::string status="FOUND_FIXTURE_PATH";
 for(int t=0;t<s.h;++t){
  std::vector<Node>next;next.reserve(layers.back().size()*9);bool expired=false;
  for(int p=0;p<int(layers.back().size());++p){auto base=layers.back()[p];
   for(unsigned a=0;a<unsigned(method=="stay"?1:9);++a){++expansions;unsigned q=base.q;unsigned applied=consume(q,a,s.delay);Vec v=move(base.p,applied,s.focused,s.motion);
    if(s.f[t].hit(v))continue;
    // Prefer slack and moderate repositioning. No whole-spell value-function claim.
    float score=base.score + s.f[t].clearance_cost(v)*.10f - std::abs(v.x-192)*.001f-std::abs(v.y-352)*.003f-(a!=0?.025f:0);
    if(method=="greedy"){
     // Delay-aware short-horizon baseline: score this request held for delay+8
     // additional updates, without assuming it is consumed immediately.
     Vec probe=v;unsigned pq=q;score=0;
     const int look=std::min(s.delay+8,s.h-1-t);
     for(int dt=1;dt<=look;++dt){unsigned pa=consume(pq,a,s.delay);probe=move(probe,pa,s.focused,s.motion);
      if(s.f[t+dt].hit(probe)){score-=1000.0f+100.0f*(look-dt);break;}
      score+=s.f[t+dt].clearance_cost(probe);
     }
     score-=std::abs(probe.y-304)*.01f+(a!=0?.02f:0);
    }
    next.push_back({v,q,score,p,int(a)});
   }
   if(budget>0&&(expansions&255)<9&&std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-search_start).count()>budget){expired=true;break;}
  }
  if(expired){status="BUDGET_EXHAUSTED_NO_FULL_HORIZON_PATH";break;}
  if(next.empty()){status="NO_PATH_FOUND_IN_RETAINED_BEAM";break;}
  std::sort(next.begin(),next.end(),[](const Node&a,const Node&b){return a.score>b.score;});
  std::unordered_set<std::uint64_t>seen;std::vector<Node>kept;int width=method=="beam"?beam:1;
  for(const auto&n:next){
   // Approximate 2-unit state merging can lose a solution; accepted paths are replayed exactly.
   std::uint64_t k=std::uint64_t(n.q)<<32 | std::uint64_t(int(n.p.y/2))<<16 | unsigned(int(n.p.x/2));
   if(seen.insert(k).second){kept.push_back(n);if(int(kept.size())>=width)break;}
  }
  layers.push_back(std::move(kept));
 }
 auto search_end=std::chrono::steady_clock::now();int depth=int(layers.size())-1;std::vector<int>actions(depth);std::vector<Vec>positions(depth);int index=0;
 for(int t=depth;t>0;--t){const auto&n=layers[t][index];actions[t-1]=n.request;positions[t-1]=n.p;index=n.parent;}
 Vec p=s.initial;unsigned q=s.initial_queue;bool checked=true;
 for(int t=0;t<depth;++t){auto a=consume(q,actions[t],s.delay);p=move(p,a,s.focused,s.motion);if(s.f[t].brute_hit(p)||p.x!=positions[t].x||p.y!=positions[t].y)checked=false;}
 if(!checked)throw std::runtime_error("planner/replay mismatch");
 auto end=std::chrono::steady_clock::now();auto ms=[](auto a,auto b){return std::chrono::duration<double,std::milli>(b-a).count();};
 std::cout<<std::setprecision(9)<<"{\"status\":\""<<status<<"\",\"scope\":\"finite-horizon autonomous conditional fixture; NOT a retail spell solution\",\"method\":\""<<method<<"\",\"horizon\":"<<s.h<<",\"depth\":"<<depth<<",\"delay\":"<<s.delay<<",\"beam\":"<<beam<<",\"expansions\":"<<expansions<<",\"exact_fixture_replay\":true,\"complete\":"<<(depth==s.h?"true":"false")<<",\"parse_index_ms\":"<<ms(begin,search_start)<<",\"search_ms\":"<<ms(search_start,search_end)<<",\"replay_ms\":"<<ms(search_end,end)<<",\"total_ms\":"<<ms(begin,end)<<",\"actions\":[";
 for(int i=0;i<depth;++i){if(i)std::cout<<',';std::cout<<actions[i];}std::cout<<"],\"positions\":[";
 for(int i=0;i<depth;++i){if(i)std::cout<<',';std::cout<<'['<<positions[i].x<<','<<positions[i].y<<']';}std::cout<<"]}\n";
 return 0;
 }catch(const std::exception&e){std::cerr<<"ERROR: "<<e.what()<<'\n';return 2;}}
