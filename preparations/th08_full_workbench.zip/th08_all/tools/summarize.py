#!/usr/bin/env python3
import json,statistics,math
from pathlib import Path
R=Path(__file__).resolve().parents[1]
p=R/'reports/kinematic_results.json'
if p.exists():
 v=[x for x in json.loads(p.read_text()).values()if 'planners'in x]
 def stat(a):
  a=sorted(a);return dict(median=statistics.median(a),p95=a[min(len(a)-1,math.ceil(.95*len(a))-1)],maximum=max(a))
 if v:
  o=dict(eligible=len(v),successes={m:sum(x['planners'][m]['complete']for x in v)for m in('stay','greedy','beam')},beam_search_ms=stat([x['planners']['beam']['search_ms']for x in v]),greedy_search_ms=stat([x['planners']['greedy']['search_ms']for x in v]),native_beam_total_ms=stat([x['planners']['beam']['total_ms']for x in v]),forecast_python_ms=stat([x['forecast_seconds']*1000 for x in v]),meaning='Across heterogeneous fixed-origin finite fixtures, one solve per fixture; NOT repeated real-time frame tail latency.')
  (R/'reports/performance_summary.json').write_text(json.dumps(o,indent=2));print(json.dumps(o,indent=2))
