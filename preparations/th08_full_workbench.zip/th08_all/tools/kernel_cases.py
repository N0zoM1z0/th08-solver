#!/usr/bin/env python3
"""Compile ALL successful emitter slices into unique conditional kinematic cases.
Equality here is descriptor-trace equality in the isolated fixture, NOT equality
of full game states/phase policies. Dynamic and unavailable paths remain listed.
"""
import sys,json,hashlib,collections,time
from pathlib import Path
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R))
from th08lab.emitter import Emitter
from th08lab.protocol import DIFFS,ALIGN
es=json.loads((R/'reports/ecl.json').read_text());cases={};links=[];t=time.perf_counter()
for e in es:
 for s in e['subs']:
  for diff,mask in DIFFS.items():
   for form,override in ALIGN.items():
    v=Emitter(e,s['id'],mask|override).run(240)
    if v['status']=='BLOCKED' or not v['nominal_requests']:continue
    first=min(x['tick']for x in v['events']);h=min(180,240-first)
    ev=[dict(tick=x['tick']-first,opcode=x['opcode'],args=x['args'],offset=x['offset'],transforms=x['transforms'])for x in v['events']if x['tick']<first+h]
    raw=json.dumps(dict(horizon=h,events=ev),sort_keys=True,separators=(',',':'));key=hashlib.sha256(raw.encode()).hexdigest()[:20]
    ref=dict(file=e['file'],sub=s['id'],difficulty=diff,override=form,first_emission_tick=first,emitter_status=v['status'])
    if key not in cases:cases[key]=dict(key=key,horizon=h,events=ev,origins=[],scope='isolated fixed-origin nominal emitter trace; no external game systems')
    cases[key]['origins'].append(ref);links.append(dict(case=key,**ref))
(R/'reports/kernel_cases.json').write_text(json.dumps(list(cases.values()),ensure_ascii=False,separators=(',',':')))
summary=dict(unique_fixture_traces=len(cases),linked_emitter_attempts=len(links),seconds=time.perf_counter()-t,qualification='Equality of emitted descriptors only. All full-game guards/state omitted by this explicit isolated fixture contract.')
(R/'reports/kernel_case_summary.json').write_text(json.dumps(summary,indent=2));print(summary)
