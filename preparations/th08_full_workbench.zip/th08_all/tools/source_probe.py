#!/usr/bin/env python3
"""Extract eight current-source function bodies into a small invariant harness.
Source bodies are unchanged. Surrounding types, trig, timers, sound and player
are STUBS; this is explicitly NOT an original-binary differential emulator.
"""
import argparse,hashlib,json,subprocess
from pathlib import Path
NAMES=['UpdateDeceleration','UpdateVectorAcceleration','UpdatePolarAcceleration','UpdateRelativeDirectionChange','UpdateAbsoluteDirectionChange','UpdateAimedDirectionChange','UpdateHorizontalWrap','UpdateVerticalWrap']
PREFIX=r'''#include <cmath>
#include <iostream>
#include <stdexcept>
using i32=int;using f32=float;using SoundIdx=int;
constexpr float ZUN_PI=3.1415927410125732f;
float AddNormalizeAngle(float a,float b){a+=b;while(a>ZUN_PI)a-=2*ZUN_PI;while(a<-ZUN_PI)a+=2*ZUN_PI;return a;}
float VectorAngle(float y,float x){return std::atan2(y,x);}
struct V{float x=0,y=0,z=0;void FromAngleMagnitude(float a,float m){x=std::cos(a)*m;y=std::sin(a)*m;}V operator*(float f)const{return{x*f,y*f,z*f};}V&operator+=(V b){x+=b.x;y+=b.y;z+=b.z;return *this;}};
struct S{float framerateMultiplier=1;}g_Supervisor;
struct Sound{void PlaySoundByIdx(int,int){}}g_SoundPlayer;
struct Player{float AngleToPoint(V*p){return std::atan2(352-p->y,192-p->x);}}g_Player;
enum{BULLET_TRANSFORM_STATE_DECELERATION,BULLET_TRANSFORM_STATE_VECTOR_ACCELERATION,BULLET_TRANSFORM_STATE_POLAR_ACCELERATION,BULLET_TRANSFORM_STATE_DIRECTION_CHANGE,BULLET_TRANSFORM_STATE_WRAP};
enum{BULLET_TRANSFORM_DECELERATE=1,BULLET_TRANSFORM_ACCELERATE_VECTOR=16,BULLET_TRANSFORM_ACCELERATE_POLAR=32,BULLET_TRANSFORM_CHANGE_DIRECTION_RELATIVE=64,BULLET_TRANSFORM_CHANGE_DIRECTION_AIMED=128,BULLET_TRANSFORM_CHANGE_DIRECTION_ABSOLUTE=256,BULLET_TRANSFORM_WRAP_X=4194304,BULLET_TRANSFORM_WRAP_Y=8388608};
struct X{int timer=0,durationFrames=16,directionChangeIntervalFrames=8,directionChangeRepeatCount=3,directionChangesCompleted=0;float angleDelta=.01f,speedDelta=.1f,directionChangeAngle=.7f,directionChangeSpeed=1.5f;V vector{.1f,.2f,0};};
struct Bullet{float angle=.3f,speed=2;V position{100,150,0},velocity;int activeTransformFlags=0,transformSound=-1;X exStates[5];void UpdateDeceleration();void UpdateVectorAcceleration();void UpdatePolarAcceleration();void UpdateRelativeDirectionChange();void UpdateAbsoluteDirectionChange();void UpdateAimedDirectionChange();void UpdateHorizontalWrap();void UpdateVerticalWrap();};
void ck(bool b){if(!b)throw std::runtime_error("invariant mismatch");}
bool near(float a,float b){return std::abs(a-b)<.00003f;}
'''
SUFFIX=r'''int main(){try{int checks=0;for(int n=0;n<1024;++n){for(int k=0;k<8;++k){Bullet b;b.angle=(n%61-30)*.1f;b.velocity.FromAngleMagnitude(b.angle,b.speed);int t=n%23;for(auto&x:b.exStates)x.timer=t;float angle=b.angle;V v=b.velocity;
if(k==0){b.activeTransformFlags=1;b.UpdateDeceleration();float m=t<=16?5-t*5.f/16+2:2;ck(near(std::hypot(b.velocity.x,b.velocity.y),m));ck(bool(b.activeTransformFlags&1)==(t<=16));}
if(k==1){b.activeTransformFlags=16;b.UpdateVectorAcceleration();ck(near(b.velocity.x,v.x+(t<16?.1f:0)));ck(near(b.velocity.y,v.y+(t<16?.2f:0)));ck(bool(b.activeTransformFlags&16)==(t<16));}
if(k==2){b.activeTransformFlags=32;b.UpdatePolarAcceleration();ck(near(b.speed,t<16?2.1f:2.f));ck(near(b.angle,t<16?AddNormalizeAngle(angle,.01f):angle));}
if(k>=3&&k<=5){int flag=k==3?64:k==4?256:128;b.activeTransformFlags=flag;if(k==3)b.UpdateRelativeDirectionChange();if(k==4)b.UpdateAbsoluteDirectionChange();if(k==5)b.UpdateAimedDirectionChange();float m=t>=8?1.5f:2-t*2.f/8;ck(near(std::hypot(b.velocity.x,b.velocity.y),m));ck(b.exStates[3].timer==(t>=8?1:t+1));if(t>=8){float a=k==3?angle+.7f:k==4?.7f:AddNormalizeAngle(g_Player.AngleToPoint(&b.position),.7f);ck(near(b.angle,a));}}
if(k==6||k==7){float q=(n%11-5)*100.f,span=k==6?384.f:448.f;if(k==6){b.activeTransformFlags=4194304;b.position.x=q;b.UpdateHorizontalWrap();ck(b.position.x==(q<0?q+span:q>span?q-span:q));}else{b.activeTransformFlags=8388608;b.position.y=q;b.UpdateVerticalWrap();ck(b.position.y==(q<0?q+span:q>span?q-span:q));}ck((b.activeTransformFlags!=0)==(t>0));}
++checks;}}std::cout<<"{\"source_functions\":8,\"cases\":"<<checks<<",\"mismatches\":0,\"scope\":\"unmodified reconstructed motion function bodies in unit-multiplier stub harness, NOT original executable\"}\n";}catch(std::exception&e){std::cerr<<e.what();return 1;}}
'''
def main():
 p=argparse.ArgumentParser();p.add_argument('--source',required=True,type=Path);p.add_argument('--out',type=Path,default=Path('build/source_probe'));p.add_argument('--compiler',default='g++');p.add_argument('--generate-only',action='store_true');a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
 path=a.source/'src/BulletManager.cpp';s=path.read_text();functions=[]
 for name in NAMES:
  start=s.index('void Bullet::'+name+'(');pos=s.index('{',start)+1;depth=1
  while depth and pos<len(s):depth+=(s[pos]=='{')-(s[pos]=='}');pos+=1
  if depth:raise ValueError('Unbalanced source function')
  functions.append(s[start:pos])
 cpp=a.out/'source_motion_probe.cpp';cpp.write_text(PREFIX+'\n'.join(functions)+SUFFIX)
 result=dict(source_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),function_body_sha256={n:hashlib.sha256(f.encode()).hexdigest()for n,f in zip(NAMES,functions)},scope='Explicit stub harness, not original executable')
 if not a.generate_only:
  exe=(a.out/'source_motion_probe').resolve();subprocess.run([a.compiler,'-std=c++17','-O2',str(cpp),'-o',str(exe)],check=True)
  run=subprocess.run([str(exe)],check=True,capture_output=True,text=True);result['result']=json.loads(run.stdout)
 (a.out/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
if __name__=='__main__':main()
