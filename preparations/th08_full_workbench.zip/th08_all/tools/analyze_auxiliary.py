#!/usr/bin/env python3
import sys,json,argparse
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from th08lab.auxiliary import stage,dialogue,replay
from th08lab.archive import Archive
ap=argparse.ArgumentParser();ap.add_argument('--dat',type=Path);a=ap.parse_args()
if a.dat:
 ar=Archive(a.dat)
 for e in ar.entries:
  if e['name'].endswith(('.rpy','.dat','.std')):(ROOT/'private'/e['name']).write_bytes(ar.read(e))
result={};errors=[]
for key,glob,fn in [('stage_geometry','*.std',stage),('dialogue','msg*.dat',dialogue),('embedded_replays','*.rpy',replay)]:
 rows=[]
 for p in sorted((ROOT/'private').glob(glob)):
  try:rows.append(fn(p))
  except Exception as e:errors.append(dict(file=p.name,error=str(e)))
 result[key]=rows;(ROOT/'reports'/f'{key}.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
summary=dict(std_files=len(result['stage_geometry']),std_quads=sum(len(o['quads'])for s in result['stage_geometry']for o in s['objects']),std_instructions=sum(len(s['instructions'])for s in result['stage_geometry']),message_files=len(result['dialogue']),messages=sum(len(m['messages'])for m in result['dialogue']),message_instructions=sum(len(s['instructions'])for m in result['dialogue']for s in m['messages']),replays=len(result['embedded_replays']),replay_input_records=sum(s['serialized_input_records']for r in result['embedded_replays']for s in r['stage_records']),errors=errors)
(ROOT/'reports/auxiliary_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(json.dumps(summary,ensure_ascii=False,indent=2))
for r in result['embedded_replays']:print(r['file'],'extended',r['extended'],'difficulty',r['difficulty'],[(s['stage_index'],s['serialized_input_records'],s['rng_seed'])for s in r['stage_records']])
