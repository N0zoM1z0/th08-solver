from pathlib import Path
import sys,json,collections,time
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from th08lab.emitter import Emitter
from th08lab.protocol import DIFFS,ALIGN
r=Path(__file__).resolve().parents[1];E=json.loads((r/'reports/ecl.json').read_text());results=[];eventsets=[];t=time.perf_counter()
for e in E:
 for s in e['subs']:
  for d,mask in DIFFS.items():
   for align,am in ALIGN.items():
    vm=Emitter(e,s['id'],mask|am);v=vm.run(240);ev=v.pop('events');v.update(difficulty=d,override=align)
    results.append(v)
    if ev and align=='unaligned' and d=='lunatic':eventsets.append(dict(**v,events=ev))
(r/'reports/emitter_exercises.json').write_text(json.dumps(results,ensure_ascii=False,separators=(',',':')))
(r/'reports/emitter_events.json').write_text(json.dumps(eventsets,ensure_ascii=False,separators=(',',':')))
summary=dict(attempts=len(results),statuses=dict(collections.Counter(v['status']for v in results)),blocked_reasons=dict(collections.Counter(v['reason']for v in results if v['reason'])),any_emission=sum(v['emission_commands']>0 for v in results),emitting_and_not_blocked=sum(v['emission_commands']>0 and v['status']!='BLOCKED' for v in results),seconds=time.perf_counter()-t,qualification='Fresh-context bounded emitter slicing, NOT all-spell execution or gameplay validation.')
(r/'reports/emitter_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(json.dumps(summary,ensure_ascii=False,indent=2))
