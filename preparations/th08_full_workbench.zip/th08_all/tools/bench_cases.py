#!/usr/bin/env python3
"""Run every unique, eligible descriptor trace, or an explicitly bounded shard.
Forecast+planner test of a conditional fixture, not a full spell/retail replay.
Unsupported dependence fails closed. Results include rejected cases, never omit.
"""
import sys,json,time,subprocess,argparse,collections,platform
from pathlib import Path
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R))
from th08lab.kinematics import World,templates,UnsupportedWorld
ap=argparse.ArgumentParser();ap.add_argument('--begin',type=int,default=0);ap.add_argument('--end',type=int);ap.add_argument('--beam',type=int,default=64);ap.add_argument('--planner',type=Path);ap.add_argument('--keep-scenes',action='store_true');a=ap.parse_args()
exe=a.planner or R/'build'/('th08lab_planner.exe'if sys.platform=='win32'else'th08lab_planner')
if not exe.exists()and sys.platform=='win32':exe=R/'build/Release/th08lab_planner.exe'
if not exe.exists():raise SystemExit('Build the native planner with CMake first.')
cases=json.loads((R/'reports/kernel_cases.json').read_text());anm=next(x for x in json.loads((R/'reports/anm.json').read_text())if x['file']=='etama.anm');tpl=templates(anm)
(R/'reports/bullet_templates.json').write_text(json.dumps(tpl,indent=2));sht=next(s for s in json.loads((R/'reports/sht.json').read_text())if s['file']=='ply00a.sht')
results_file=R/'reports/kinematic_results.json';results=json.loads(results_file.read_text())if results_file.exists()else{}
results={k:v for k,v in results.items()if k in {c['key']for c in cases}}
scene_dir=R/'build/scenes';scene_dir.mkdir(parents=True,exist_ok=True);total=time.perf_counter()
for index,c in enumerate(cases[a.begin:a.end],a.begin):
 key=c['key'];begin=time.perf_counter();res=dict(key=key,index=index,horizon=c['horizon'],origins=c['origins'],scope='fixed emitter at (192,128); starts at first emission; nominal pre-rank/pre-gates trace; no enemy, damage, EX, item/graze RNG or background hazards',source_binary_equivalence=False)
 w=World(tpl);by=collections.defaultdict(list)
 for e in c['events']:by[e['tick']].append(e)
 frames=[]
 try:
  for t in range(c['horizon']):frames.append(w.step(by[t]))
 except (UnsupportedWorld,IndexError,ValueError,OverflowError)as ex:
  res.update(status='REJECTED_DEPENDENT_OR_UNSUPPORTED',reason=str(ex),stop_tick=w.tick,forecast_seconds=time.perf_counter()-begin)
  results[key]=res;results_file.write_text(json.dumps(results,ensure_ascii=False,separators=(',',':')));continue
 res.update(status='FORECAST_FIXTURE_READY',forecast_seconds=time.perf_counter()-begin,requests=w.requests,spawned=w.spawned,dropped=w.dropped,max_live=w.max_live,max_lethal=max(map(len,frames),default=0))
 path=scene_dir/(key+'.txt');half=sht['hurtbox_full_width']/2
 header=f'TH08LAB_FORECAST_V1\n{c["horizon"]} 2 1 1 192 304 {half} {half} 0.25\n{sht["normal"]} {sht["focus"]} {sht["normal_diagonal"]} {sht["focus_diagonal"]} 0\n'
 with path.open('w')as f:
  f.write(header)
  for boxes in frames:
   f.write(f'{len(boxes)} 0\n')
   for b in boxes:f.write(' '.join(format(x,'.9g')for x in b)+'\n')
 res['planners']={}
 for method in ('stay','greedy','beam'):
  run=subprocess.run([str(exe),str(path),str(a.beam),'0',method],capture_output=True,text=True,timeout=20)
  if run.returncode:raise RuntimeError(f'{key}: {run.stderr}')
  v=json.loads(run.stdout);res['planners'][method]=v
 res['status']='FINITE_FIXTURE_PATH_FOUND'if res['planners']['beam']['complete']else'NO_FIXTURE_PATH_IN_BEAM'
 # Keep only demonstrations with actual baseline contact and a nonempty found path.
 if res['planners']['beam']['complete']and not res['planners']['stay']['complete']:
  d=R/'reports/demos';d.mkdir(exist_ok=True)
  if len(list(d.glob('*.json')))<8:
   (d/(key+'.json')).write_text(json.dumps(dict(key=key,origin=[192,128],initial=[192,304],half=half,frames=frames,results=res),ensure_ascii=False,separators=(',',':')))
 if not a.keep_scenes:path.unlink()
 results[key]=res;results_file.write_text(json.dumps(results,ensure_ascii=False,separators=(',',':')))
 print(index,key,res['status'],res['max_lethal'],{k:v['complete']for k,v in res['planners'].items()},round(res['planners']['beam']['search_ms'],3),flush=True)
summary=dict(cases_recorded=len(results),cases_total=len(cases),statuses=dict(collections.Counter(v['status']for v in results.values())),reasons=dict(collections.Counter(v.get('reason')for v in results.values()if v.get('reason'))),runtime_platform=platform.platform(),current_shard_seconds=time.perf_counter()-total)
(R/'reports/kinematic_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(json.dumps(summary,ensure_ascii=False,indent=2))
