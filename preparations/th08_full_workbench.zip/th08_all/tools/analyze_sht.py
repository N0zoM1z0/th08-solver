#!/usr/bin/env python3
"""All SHT descriptor lists, including callback indices. Not a damage simulator."""
import struct,json,sys
from pathlib import Path
R=Path(__file__).resolve().parents[1]
rows=json.loads((R/'reports/sht.json').read_text());total=0
for row in rows:
 b=(R/'private'/row['file']).read_bytes();n=row['levels'];levels=[];used=set(range(56+8*n))
 for i in range(n):
  off,power=struct.unpack_from('<Ii',b,56+8*i);p=off;des=[]
  while True:
   if p+4>len(b):raise ValueError('SHT terminator missing')
   if struct.unpack_from('<i',b,p)[0]==-1:used.update(range(p,p+4));p+=4;break
   if p+56>len(b):raise ValueError('SHT descriptor overrun')
   a=struct.unpack_from('<hh6f6h4I',b,p)
   des.append(dict(pc=p,fire_interval=a[0],fire_frame=a[1],offset=list(a[2:4]),hitbox_full_size=list(a[4:6]),angle=a[6],speed=a[7],damage=a[8],extreme_gauge_behavior=a[9],source_option_index=a[10],shot_type=a[11],animation_index=a[12],sound_index=a[13],spawn_callback=a[14],update_callback=a[15],draw_callback=a[16],collision_callback=a[17]))
   used.update(range(p,p+56));p+=56
  levels.append(dict(index=i,raw_minimum_power=power,pc=off,end=p,descriptors=des));total+=len(des)
 row['power_levels']=levels;row['status']='all movement/header and descriptor lists structurally parsed; callbacks/damage timing NOT simulated'
 row['unparsed_bytes']=len(b)-len(used)
 if row['unparsed_bytes']:raise ValueError('unparsed SHT bytes')
 row.update(graze_full_width=struct.unpack_from('<f',b,16)[0],item_autocollect_speed=struct.unpack_from('<f',b,20)[0],item_box_size=struct.unpack_from('<f',b,24)[0],point_value_line=struct.unpack_from('<f',b,28)[0],item_movement_speed=struct.unpack_from('<f',b,52)[0])
(R/'reports/sht.json').write_text(json.dumps(rows,ensure_ascii=False,separators=(',',':')))
print(json.dumps(dict(files=len(rows),power_levels=sum(len(r['power_levels'])for r in rows),descriptors=total,unparsed_bytes=sum(r['unparsed_bytes']for r in rows))))
