#!/usr/bin/env python3
"""Generate searchable offline HTML and all 222 concrete spell dossiers.
Dossiers are source/resource analysis plans; none are mislabeled solved policies.
"""
import json,sys,collections,html
from pathlib import Path
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R))
from th08lab.analysis import FEATURES
from th08lab.ecl import format_ins
from th08lab.protocol import EX,TRANSFORMS
load=lambda name:json.loads((R/'reports'/f'{name}.json').read_text())
ecls={e['file']:e for e in load('ecl')};sp=load('spells');subs=load('subroutines');groups=collections.defaultdict(list)
for s in sp:groups[s['id']].append(s)
kin=load('kinematic_results');causal=load('causal_results');kernels=load('kernel_cases');links=collections.defaultdict(set)
for case in kernels:
 for o in case['origins']:links[(o['file'],o['sub'])].add(case['key'])
out=R/'docs/spells';out.mkdir(parents=True,exist_ok=True);cards=[]
for sid,records in sorted(groups.items()):
 rows=[];allfeatures=set();tests=set();lines=[f'# 原始符卡 ID {sid:03d}：{records[0]["name"]}', '', '**状态：尚无完整符卡已验证通关策略。下列为实际资源的结构分析与实现／验收规格。**', '', '所有时间均为所属ECL上下文的局部时钟。调用／生成闭包是掩码下的语法闭包，不是动态可达性证明；同一ID的本篇与练习入口不能无条件共用状态。','']
 for rec in records:
  prefer=('extra_or_lastword/unaligned' if sid>=191 else 'lunatic/unaligned');key=prefer if prefer in rec['variants']else next(iter(rec['variants']),None)
  if key is None:continue
  v=rec['variants'][key];fs=v['features'];allfeatures.update(fs);es=ecls[rec['file']];root=es['subs'][rec['sub']]
  setup=[dict(pc=i['pc'],time=i['time'],text=format_ins(i))for i in root['instructions']if i['opcode']in(63,64,65,75,77,78,82,127,128,129,130,131,132,133,134,135,136,137,155,173,176,177)and i['mask']&v['required_mask']==v['required_mask']]
  shots=[];trans=[];direct=[]
  for subid in v['closure_subs']:
   tests.update(links[(rec['file'],subid)])
   for i in es['subs'][subid]['instructions']:
    if i['mask']&v['required_mask']!=v['required_mask']:continue
    row=dict(sub=subid,pc=i['pc'],time=i['time'],text=format_ins(i))
    if 96<=i['opcode']<=104 or i['opcode']in(114,115):shots.append(row)
    if i['opcode']==111:trans.append(row)
    if i['opcode']in(136,137):direct.append(row)
  rows.append(dict(file=rec['file'],sub=rec['sub'],pc=rec['pc'],mask=rec['mask'],view=key,diagnostic_views=list(rec['variants']),closure=v['closure_subs'],features=fs,setup=setup,shots=shots,transforms=trans,ex=direct,transitions=v['transition_edges'],unresolved=v['unresolved_targets']))
  lines.extend([f'## {rec["file"]} / sub {rec["sub"]} / {rec["pc"]:#x}',f'开符掩码 `{rec["mask"]:#x}`；下述展示 `{key}`。所有诊断视图：`'+', '.join(rec['variants'])+'`。','',f'本阶段语法闭包：`{v["closure_subs"]}`。',''])
  for title,data in [('阶段设置／回调',setup),('实际发射与激光站点',shots),('变换记录配置（还必须检查实际发射flags）',trans),('EX 调用与安装',direct)]:
   lines+=['### '+title,'','```text']+[f'sub {r.get("sub",rec["sub"])} {r["pc"]:#x} local_t={r["time"]} {r["text"]}'for r in data]+['```','']
  lines+=['### 进入与退出约束','', '进入必须恢复准确的玩家形态/过渡计数、输入队列、RNG、子上下文、伤害与前序存活实体；不能直接以全零状态当作实战入口。','', '退出需满足以下真实回调逻辑，或依赖参考执行器识别阶段结束：','```json',json.dumps(v['transition_edges'],ensure_ascii=False,indent=2),'```','', '未解析的动态目标：`'+json.dumps(v['unresolved_targets'],ensure_ascii=False)+'`。','']
 lines+=['## 解法组件与具体验收','']
 for f in sorted(allfeatures):
  name,design,accept=FEATURES[f];lines+=[f'### {name}',design+'。','验收：'+accept+'。','']
 trace_info=[]
 for t in sorted(tests):
  k=kin[t];p=k.get('planners',{});c=causal.get(t,{})
  trace_info.append(dict(key=t,scope='同闭包子程序的独立发射夹具，不是该符卡的执行',kinematic_status=k['status'],delayaware_greedy=p.get('greedy',{}).get('complete'),beam=p.get('beam',{}).get('complete'),conditional_status=c.get('status'),frozen_false_safe=c.get('frozen_plan_actual_safe')is False))
 lines+=['## 已运行的相关夹具','', '关联仅表明这些子程序的独立入口产生过描述符轨迹；不表示它们以该条件实际出现在这张符卡中。','```json',json.dumps(trace_info,ensure_ascii=False,indent=2),'```','', '## 完整 solution 的发布门槛','', '原版与参考执行器事件级一致；以合法输入完成整段并进入可接受出口；不同入口、随机种子及实际延迟下复测；记录 miss/bomb/超时/失配。当前这些门槛尚未全部通过，因此不附伪造的逐帧通关按键。','']
 (out/f'{sid:03d}.md').write_text('\n'.join(lines),encoding='utf-8')
 cards.append(dict(id=sid,name=records[0]['name'],owner=records[0]['owner'],scope='LastWord'if sid>=205 else'Extra'if sid>=191 else'Main',records=rows,features=sorted(allfeatures),modules=[dict(id=f,name=FEATURES[f][0],design=FEATURES[f][1],test=FEATURES[f][2])for f in sorted(allfeatures)],fixture_tests=trace_info,status='NO_FULL_SPELL_SOLUTION'))
(R/'reports/spell_dossiers.json').write_text(json.dumps(cards,ensure_ascii=False,separators=(',',':')))
# Human stage index includes every opening, including duplicated conditional sites.
lines=['# 全阶段／全符卡资源索引','','本篇Lunatic列表是开符掩码包含bit8的语法记录，包含不同路线、条件LastSpell与不可同时进入的变体；不是一局必须经历的顺序。ID为资源原始编号。','']
for fn in sorted(ecls):
 records=[s for s in sp if s['file']==fn];lines+=[f'## {fn}',f'{len(ecls[fn]["subs"])} 个子程序；{len(ecls[fn]["timelines"])} 条timeline。完整字节码见 `reports/disassembly/{fn}.txt`。','']
 for s in records:lines.append(f'- ID {s["id"]:03d} {s["name"]}；sub {s["sub"]} / {s["pc"]:#x} / mask {s["mask"]:#x}。')
 lines+=['']
(R/'docs/ALL_STAGES.md').write_text('\n'.join(lines))
# All EX mechanisms and referenced locations, not just the famous callbacks.
lines=['# 全部 32 个 EX 回调','', '站点是语法观察；本文件的验收规格尚不等于完整游戏实现。','']
for ex in load('ex'):
 lines +=[f'## EX {ex["id"]}: {ex["name"]}',f'资源站点 {len(ex["sites"])} 个。','']
 for f in ex['features']:lines +=[FEATURES[f][0]+'：'+FEATURES[f][1]+'。 验收：'+FEATURES[f][2]+'。','']
 lines+=['```text']+[f'{x["file"]} sub{x["sub"]} {x["pc"]:#x} mask={x["mask"]:#x} repeating={x["repeating"]}'for x in ex['sites']]+['```','']
(R/'docs/ALL_EX.md').write_text('\n'.join(lines))
# Append only already verified final results; no stale baseline demos.
demos=[]
for p in sorted((R/'reports/demos').glob('*.json')):
 d=json.loads(p.read_text());demos.append(dict(key=d['key'],scope='自主弹幕独立夹具；不是整张符卡',initial=d['initial'],half=d['half'],frames=d['frames'],positions=d['results']['planners']['greedy']['positions']))
for p in sorted((R/'reports/causal_demos').glob('*.json')):
 d=json.loads(p.read_text());demos.append(dict(key=d['key'],scope='条件预测独立夹具；不是整张符卡',initial=d['initial'],half=d['half'],frames=d['frames'],positions=d['positions']))
css='''body{font:16px/1.7 system-ui,sans-serif;margin:0;background:#f3f5f7;color:#17212d}header,main{max-width:1260px;margin:auto;padding:24px}header{background:#112b40;color:white;max-width:none}header>div{max-width:1260px;margin:auto}.note{background:#fff3db;border-left:5px solid #bb741c;padding:14px;margin:14px 0}input,select,button{font:inherit;padding:9px;border:1px solid #aaa;border-radius:5px}input{min-width:300px}.grid{display:grid;grid-template-columns:320px 1fr;gap:20px}#list{max-height:78vh;overflow:auto}button.card{display:block;background:white;width:100%;text-align:left;margin:6px 0;border-color:#d0d9e1}.pill{display:inline-block;border:1px solid #a4bbc9;background:#e8f0f5;border-radius:12px;padding:1px 8px;margin:2px;font-size:13px}section,article{background:white;padding:18px;border-radius:6px;margin:14px 0}pre{overflow:auto;background:#f0f3f6;padding:12px;font:13px/1.5 ui-monospace,monospace;white-space:pre-wrap}summary{cursor:pointer;font-weight:600}canvas{background:#101c2b;width:384px;max-width:100%;border:1px solid #8ba0b0}a{color:#075d94}header a{color:#baddf7}.stat{display:inline-block;margin-right:30px}h1,h2,h3{line-height:1.3}@media(max-width:800px){.grid{grid-template-columns:1fr}#list{max-height:300px}}'''
page='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>TH08 全资源分析工作台</title><style>CSS</style><header><div><h1>TH08 · 全资源分析与条件规划工作台</h1><p>317 个资源校验 · 222 个不同符卡 ID · 1,449 个 ECL 子程序 · 21,735 次受限执行</p><p><a href="README.md">运行入口</a>　<a href="docs/REPORT_ZH.md">主报告</a>　<a href="docs/ALL_STAGES.md">全部阶段</a>　<a href="docs/ALL_EX.md">全部 EX</a>　<a href="docs/WINDOWS.md">Windows 接入与验证</a></p></div></header><main><div class="note"><strong>范围声明：</strong>这是全资源目录、实际代码与局部实验，不是已完成的原版 autoplay。所有整张符卡的验证状态仍是 NO_FULL_SPELL_SOLUTION。自动生成的机制说明是实现与验收方案，不是手写通关路线。夹具动画不是原版运行。</div><section><h2>检索全部符卡</h2><input id="query" placeholder="名称、ID、文件、机制关键词"><select id="scope"><option value="">全部范围</option><option>Main</option><option>Extra</option><option>LastWord</option></select> <span id="count"></span></section><div class="grid"><nav id="list"></nav><article id="detail"></article></div><section><h2>实际限定夹具动画</h2><p>固定发射原点、SHT00a低速、2次更新输入延迟；未包含完整敌人、伤害、rank、EX和其他随机消费者。动画只展示最终所选合法输入的有限时域结果。</p><select id="demo"></select> <button id="pause">暂停</button> <input id="frame" type="range" min="0" value="0" style="min-width:200px"><span id="frameLabel"></span><p><canvas id="canvas" width="384" height="448"></canvas></p></section><section><h2>关键实验结果</h2><pre id="results"></pre></section></main><script>const DATA=DATA_JSON;const DEMOS=DEMOS_JSON;const PERF=PERF_JSON;const CAUSAL=CAUSAL_JSON;
const $=x=>document.getElementById(x),esc=x=>String(x).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
function code(rows){return '<pre>'+esc(rows.map(x=>'sub '+(x.sub??'root')+' 0x'+x.pc.toString(16)+' local_t='+x.time+' '+x.text).join('\\n'))+'</pre>'}
function show(c){let h='<h2>ID '+String(c.id).padStart(3,'0')+' · '+esc(c.name)+'</h2><p>'+esc(c.owner)+' · '+c.scope+'</p><p><strong>'+c.status+'</strong> · <a href="docs/spells/'+String(c.id).padStart(3,'0')+'.md">完整逐符卡档案</a></p><p>'+c.modules.map(m=>'<span class="pill">'+esc(m.name)+'</span>').join('')+'</p>';
for(const r of c.records){h+='<details><summary>'+esc(r.file)+' / sub '+r.sub+' / 0x'+r.pc.toString(16)+'</summary><p>展示视图 '+esc(r.view)+'；闭包子程序 '+esc(r.closure.join(', '))+'。覆盖位统一扫描仅作诊断，实际父子上下文的覆盖位不一定相同。</p><h4>阶段与回调</h4>'+code(r.setup)+'<h4>发射／激光</h4>'+code(r.shots)+'<h4>配置的变换（还需实际flags）</h4>'+code(r.transforms)+'<h4>EX</h4>'+code(r.ex)+'<h4>退出边与未解析目标</h4><pre>'+esc(JSON.stringify({transitions:r.transitions,unresolved:r.unresolved},null,2))+'</pre></details>'}
h+='<h3>算法组件与验收</h3>'+c.modules.map(m=>'<p><b>'+esc(m.name)+'</b>：'+esc(m.design)+'。<br>验收：'+esc(m.test)+'。</p>').join('');h+='<details><summary>相关子程序夹具结果（不等于这张符卡的结果）</summary><pre>'+esc(JSON.stringify(c.fixture_tests,null,2))+'</pre></details>';$('detail').innerHTML=h;location.hash='spell-'+c.id}
function filter(){let q=$('query').value.toLowerCase(),scope=$('scope').value;let cs=DATA.filter(c=>(!scope||c.scope===scope)&&JSON.stringify([c.id,c.name,c.owner,c.records.map(x=>x.file),c.modules]).toLowerCase().includes(q));$('count').textContent=cs.length+' / 222';$('list').replaceChildren();for(const c of cs){let b=document.createElement('button');b.className='card';b.textContent=String(c.id).padStart(3,'0')+' '+c.name;b.onclick=()=>show(c);$('list').append(b)}}$('query').oninput=filter;$('scope').onchange=filter;filter();show(DATA.find(c=>'#spell-'+c.id===location.hash)||DATA[0]);
$('results').textContent=JSON.stringify({autonomous:PERF,conditional:CAUSAL},null,2);
let index=0,tick=0,playing=true;for(let i=0;i<DEMOS.length;i++){let o=document.createElement('option');o.value=i;o.textContent=DEMOS[i].scope+' · '+DEMOS[i].key;$('demo').append(o)}
function draw(){let d=DEMOS[index];if(!d)return;let t=Math.min(tick,d.frames.length-1),ctx=$('canvas').getContext('2d');ctx.clearRect(0,0,384,448);ctx.fillStyle='#c6d5e4';for(const b of d.frames[t])ctx.fillRect(b[0]-b[2],b[1]-b[3],2*b[2],2*b[3]);ctx.strokeStyle='#4fbdab';ctx.beginPath();for(let j=0;j<=Math.min(t,d.positions.length-1);j++){let p=d.positions[j];if(j===0)ctx.moveTo(...p);else ctx.lineTo(...p)}ctx.stroke();let p=d.positions[Math.min(t,d.positions.length-1)]||d.initial;ctx.fillStyle='#ffe393';ctx.beginPath();ctx.arc(...p,3,0,Math.PI*2);ctx.fill();$('frame').max=d.frames.length-1;$('frame').value=t;$('frameLabel').textContent='夹具 tick '+t+' / '+d.frames.length}
$('demo').onchange=()=>{index=+$('demo').value;tick=0;draw()};$('pause').onclick=()=>{playing=!playing;$('pause').textContent=playing?'暂停':'播放'};$('frame').oninput=()=>{playing=false;tick=+$('frame').value;draw()};setInterval(()=>{if(playing&&DEMOS.length){tick=(tick+1)%DEMOS[index].frames.length;draw()}},50);draw();</script></html>'''
def packed(x):return json.dumps(x,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c')
page=page.replace('CSS',css).replace('DATA_JSON',packed(cards)).replace('DEMOS_JSON',packed(demos)).replace('PERF_JSON',packed(load('performance_summary'))).replace('CAUSAL_JSON',packed(load('causal_summary')))
(R/'index.html').write_text(page,encoding='utf-8')
print('dossiers',len(cards),'HTML bytes',len(page.encode()),'demos',len(demos))
