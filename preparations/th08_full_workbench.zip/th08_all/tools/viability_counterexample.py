#!/usr/bin/env python3
"""Exact delayed-input viability for an explicitly SYNTHETIC 1D closing gate.
Uses TH08 ply00a focused speed2 and x clamp[8,376], not a retail spell.
Every reachable position and the two-request queue are enumerated with bitsets.
"""
import json,time
from pathlib import Path
R=Path(__file__).resolve().parents[1]
N=185;H=120;ALL=(1<<N)-1;values=(-1,0,1)
def safe(t):return ALL if t<90 else(1<<29)-1 # x=8+2*i <=64

def pre(bits,d):
 if d==-1:return((bits<<1)|(bits&1))&ALL
 if d==1:return(bits>>1)|(bits&(1<<(N-1)))
 return bits

def solve(start_t,end_t):
 V=[[0]*9 for _ in range(end_t-start_t+1)];V[-1]=[ALL]*9
 for t in range(end_t-1,start_t-1,-1):
  for q in range(9):
   first,second=divmod(q,3)
   for request in range(3):V[t-start_t][q]|=pre(V[t-start_t+1][second*3+request]&safe(t),values[first])
 return V

def action(V,t,index,q,start_t=0):
 first,second=divmod(q,3);nidx=min(N-1,max(0,index+values[first]))
 for request in(1,0,2):
  nq=second*3+request
  if (safe(t)>>nidx)&1 and(V[t-start_t+1][nq]>>nidx)&1:return request,nidx,nq
 return None

def run(full):
 index=(192-8)//2;q=4;trace=[];V=solve(0,H)if full else None
 for t in range(H):
  vv=V if full else solve(t,min(H,t+10));r=action(vv,t,index,q,0 if full else t)
  if r is None:return dict(complete=False,failed_decision_tick=t,trace=trace)
  request,index,q=r;trace.append(dict(t=t,requested=values[request],x=8+2*index,queue=q))
 return dict(complete=True,trace=trace)
start=time.perf_counter();full=run(True);short=run(False)
assert full['complete']and not short['complete'];first=next(x['t']for x in full['trace']if x['requested'])
result=dict(scope='Exact finite-grid SYNTHETIC closing gate, not retail ECL',positions=N,queue_states=9,horizon=H,gate_closes_at_tick=90,terminal_gate_x_max=64,delay=2,first_nonzero_request_tick=first,full=full,short_horizon10=short,elapsed_ms=(time.perf_counter()-start)*1000)
(R/'reports/viability_counterexample.json').write_text(json.dumps(result,indent=2))
print({k:v for k,v in result.items()if k not in('full','short_horizon10')});print('full',full['complete'],'short',short['complete'],short.get('failed_decision_tick'))
