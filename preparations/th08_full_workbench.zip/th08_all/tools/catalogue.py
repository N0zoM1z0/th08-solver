from pathlib import Path
import sys,json,collections,time
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from th08lab.ecl import parse,disassemble
from th08lab.analysis import catalogue
root=Path(__file__).resolve().parents[1];E=[parse(p.read_bytes(),p.name) for p in sorted((root/'private').glob('*.ecl'))]
for e in E:(root/'reports/disassembly'/f"{e['file']}.txt").write_text(disassemble(e),encoding='utf-8')
A=json.loads((root/'reports/anm.json').read_text());C=catalogue(E,A)
(root/'reports/ecl.json').write_text(json.dumps(E,ensure_ascii=False,separators=(',',':')))
for k,v in C.items():(root/'reports'/f'{k}.json').write_text(json.dumps(v,ensure_ascii=False,separators=(',',':')))
print(json.dumps(dict(spell_records=len(C['spells']),unique_spell_ids=len(set(s['id']for s in C['spells'])),spell_variants=sum(len(s['variants'])for s in C['spells']),subroutines=len(C['subroutines']),opcode_observed=sum(x['sites']>0 for x in C['opcodes']),schema_gaps=sum(len(x['schema_gaps'])for x in C['subroutines']),ex_observed=sum(len(x['sites'])>0 for x in C['ex']),transform_kinds=len(C['transforms']),anm_scripts=len(C['anm_scripts'])),indent=2))
