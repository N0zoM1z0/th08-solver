#!/usr/bin/env python3
"""Context-aware whole-resource semantic audits; static facts, not policy claims."""
import sys,json,collections,struct
from pathlib import Path
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R))
from th08lab.ecl import format_ins
from th08lab.protocol import EX,TRANSFORMS
es=json.loads((R/'reports/ecl.json').read_text());paired=[];lasers=[];unknown=[];loops=[]
for e in es:
 for s in e['subs']:
  recent={}
  for i in s['instructions']:
   if 'transform'in i:
    t=i['transform'];idx=t['index'];prev=recent.get(idx-1)
    if t['kind']==0x2000000:
     row=dict(file=e['file'],sub=s['id'],pc=i['pc'],index=idx,secondary=t,primary_pc=prev['pc']if prev else None,primary=prev['transform']if prev else None,context_verified=bool(prev and prev['transform']['kind']==0x1000000))
     paired.append(row)
     if not row['context_verified']:unknown.append(row)
     else:
      packed=prev['transform']['int0']&0xffffffff
      row.update(child_mode=(packed>>24)&0x7f,child_type=(packed>>16)&255,child_color=(packed>>8)&255,next_transform=packed&255,parent_fades=bool(packed&0x80000000),count1=prev['transform']['int1'],count2=t['int0'],flags=hex(t['int1']))
    recent[idx]=i
   if i['opcode']in(114,115):lasers.append(dict(file=e['file'],sub=s['id'],pc=i['pc'],local_time=i['time'],text=format_ins(i),selectors=i['selectors'],args=i['args'],status='REQUIRES_BOUND_RUNTIME_CONTEXT'))
   if 'jump'in i and i['jump']<=i['pc']:loops.append(dict(file=e['file'],sub=s['id'],pc=i['pc'],target=i['jump'],mask=i['mask'],opcode=i['opcode']))
assert len(paired)==12 and not unknown
records=json.loads((R/'reports/transforms.json').read_text())
for t in records:
 if t['kind']==0x2000000:t['name']='CHILD_SECONDARY_PAYLOAD_TAG';t['status']='All 12 occurrences follow configured primary child record at index-1. Not a standalone execution opcode; the previous operation consumes this payload regardless of its kind.'
(R/'reports/transforms.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
obj=dict(child_secondary_sites=paired,child_secondary_count=len(paired),laser_sites=lasers,laser_site_count=len(lasers),laser_sites_with_selectors=sum(bool(x['selectors'])for x in lasers),backward_jump_sites=loops,backward_jumps=len(loops),qualification='Syntactic configuration association, not universal reachable-state proof. Dynamic writes, masks and inherited transform tables still matter at runtime.')
(R/'reports/deep_inventory.json').write_text(json.dumps(obj,ensure_ascii=False,indent=2))
print('paired',len(paired),'lasers',len(lasers),'dynamic',obj['laser_sites_with_selectors'],'backward-jumps',len(loops))
