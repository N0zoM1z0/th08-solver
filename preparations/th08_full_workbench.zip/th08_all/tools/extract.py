from pathlib import Path
import sys,json,time,collections
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from th08lab.archive import Archive
from th08lab.ecl import parse,disassemble
from th08lab.anm import parse as parse_anm,parse_sht
root=Path(__file__).resolve().parents[1];(root/'private').mkdir(parents=True,exist_ok=True);(root/'reports/disassembly').mkdir(parents=True,exist_ok=True)
a=Archive(sys.argv[1]);ecls=[];anms=[];sht=[];errors=[];t=time.perf_counter()
for e in a.entries:
    try:
        b=a.read(e);name=e['name'];suf=Path(name).suffix.lower()
        if suf in ('.ecl','.anm','.sht','.std','.ver','.msg','.dat','.rpy'):(root/'private'/name).write_bytes(b)
        if suf=='.ecl':
            obj=parse(b,name);ecls.append(obj);(root/'reports/disassembly'/f'{name}.txt').write_text(disassemble(obj),encoding='utf-8')
        elif suf=='.anm':anms.append(parse_anm(b,name))
        elif suf=='.sht':sht.append(parse_sht(b,name))
    except Exception as ex:errors.append(dict(file=e['name'],error=repr(ex)))
for n,o in [('archive',dict(meta=a.meta,entries=a.entries,errors=errors)),('ecl',ecls),('anm',anms),('sht',sht)]:
    (root/'reports'/f'{n}.json').write_text(json.dumps(o,ensure_ascii=False,allow_nan=False,separators=(',',':')),encoding='utf-8')
print(json.dumps(dict(archive=a.meta,counts=dict(collections.Counter(Path(e['name']).suffix for e in a.entries)),ecl=len(ecls),anm=len(anms),sht=len(sht),errors=errors,seconds=time.perf_counter()-t),ensure_ascii=False,indent=2))
