#!/usr/bin/env python3
"""Test ALL dependent cases rejected by the shared-forecast path.
Fixed-origin, no-other-system fixture; explicit RNG seed/order. A frozen-future
plan is replayed against candidate-dependent targeting. Then a bounded library
of legal-input macros is evaluated in its own conditional future. Not NMNB.
"""
import sys,json,time,subprocess,collections,argparse,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R))
from th08lab.kinematics import World,templates,UnsupportedWorld
from th08lab.emitter import f32
ap=argparse.ArgumentParser();ap.add_argument('--begin',type=int,default=0);ap.add_argument('--end',type=int);a=ap.parse_args()
exe=R/'build'/('th08lab_planner.exe'if sys.platform=='win32'else'th08lab_planner')
if not exe.exists():exe=R/'build/Release/th08lab_planner.exe'
ks=json.loads((R/'reports/kernel_cases.json').read_text());prior=json.loads((R/'reports/kinematic_results.json').read_text());cases=[c for c in ks if prior[c['key']]['status']=='REJECTED_DEPENDENT_OR_UNSUPPORTED']
A=next(x for x in json.loads((R/'reports/anm.json').read_text())if x['file']=='etama.anm');tpl=templates(A);half=f32(1.649999976158142/2);extra=.25
D=[(0,0),(0,-1),(1,-1),(1,0),(1,1),(0,1),(-1,1),(-1,0),(-1,-1)]
def move(p,act):
 dx,dy=D[act];v=f32(1.4142135381698608)if dx and dy else 2.;return[f32(min(376,max(8,f32(p[0]+dx*v)))),f32(min(432,max(16,f32(p[1]+dy*v))))]
def hit(p,b):return abs(p[0]-b[0])<=half+b[2]+extra and abs(p[1]-b[1])<=half+b[3]+extra

def simulate(c,policy,frozen=False,capture=False):
 p=[192.,304.];queue=[0,0];actions=[];positions=[];frames=[];w=World(tpl,target=lambda t:[192.,304.]if frozen else p,seed=0)
 by=collections.defaultdict(list)
 for e in c['events']:by[e['tick']].append(e)
 for t in range(c['horizon']):
  act=policy(t,p,actions);actions.append(act);queue.append(act);p=move(p,queue.pop(0));positions.append(p.copy());boxes=w.step(by[t])
  if capture:frames.append(boxes)
  if any(hit(p,b)for b in boxes):return dict(complete=False,hit_tick=t,actions=actions,positions=positions,frames=frames,spawned=w.spawned)
 return dict(complete=True,hit_tick=None,actions=actions,positions=positions,frames=frames,spawned=w.spawned)

def macros():
 result=[('stay',lambda t,p,h:0)]
 for d in(3,7,2,8,1):
  for wait in(0,12,24):result.append((f'wait{wait}_dir{d}',lambda t,p,h,d=d,w=wait:0 if t<w else d))
 for initial in(3,7):
  for wait in(0,16):
   def sweep(t,p,h,initial=initial,wait=wait):
    if t<wait:return 0
    last=h[-1]if h and h[-1]in(3,7)else initial
    return 3 if p[0]<=32 else 7 if p[0]>=352 else last
   result.append((f'sweep{initial}_wait{wait}',sweep))
 return result
outpath=R/'reports/causal_results.json';out=json.loads(outpath.read_text())if outpath.exists()else{}
out={k:v for k,v in out.items()if k in {c['key']for c in cases}}
scenedir=R/'build/scenes';scenedir.mkdir(parents=True,exist_ok=True)
for j,c in enumerate(cases[a.begin:a.end],a.begin):
 begin=time.perf_counter();res=dict(key=c['key'],origins=c['origins'],horizon=c['horizon'],qualification='Isolated fixed-origin nominal descriptor fixture, RNG seed0 high16-first U32; NOT full-game or original-binary evidence.')
 try:
  # Build the WRONG fixed-player future explicitly as a negative control.
  w=World(tpl,target=lambda t:[192.,304.],seed=0);by=collections.defaultdict(list);frames=[]
  for e in c['events']:by[e['tick']].append(e)
  for t in range(c['horizon']):frames.append(w.step(by[t]))
  path=scenedir/(c['key']+'_frozen.txt')
  with path.open('w')as f:
   f.write(f'TH08LAB_FORECAST_V1\n{c["horizon"]} 2 1 1 192 304 {half} {half} {extra}\n4 2 2.8284270763397217 1.4142135381698608 0\n')
   for boxes in frames:
    f.write(f'{len(boxes)} 0\n')
    for b in boxes:f.write(' '.join(format(x,'.9g')for x in b)+'\n')
  run=subprocess.run([str(exe),str(path),'64','0','greedy'],capture_output=True,text=True,timeout=20);path.unlink()
  if run.returncode:raise RuntimeError(run.stderr)
  plan=json.loads(run.stdout);res['frozen_plan_found']=plan['complete']
  if plan['complete']:
   seq=plan['actions'];actual=simulate(c,lambda t,p,h:seq[t]);res['frozen_plan_actual_safe']=actual['complete'];res['frozen_plan_actual_hit_tick']=actual['hit_tick']
  else:res['frozen_plan_actual_safe']=None
  evaluated=[];selected=None
  for name,policy in macros():
   v=simulate(c,policy);evaluated.append(dict(policy=name,complete=v['complete'],hit_tick=v['hit_tick']))
   if v['complete']:
    selected=dict(policy=name,actions=v['actions'],positions=v['positions']);break
  res.update(status='CONDITIONAL_FIXTURE_POLICY_FOUND'if selected else'NO_POLICY_IN_FINITE_LIBRARY',selected=selected,evaluations=evaluated)
  if selected and res.get('frozen_plan_actual_safe')is False:
   dd=R/'reports/causal_demos';dd.mkdir(exist_ok=True)
   if len(list(dd.glob('*.json')))<4:
    _,fn=next(x for x in macros()if x[0]==selected['policy']);v=simulate(c,fn,capture=True)
    (dd/(c['key']+'.json')).write_text(json.dumps(dict(key=c['key'],scope=res['qualification'],initial=[192,304],half=half,frames=v['frames'],positions=v['positions'],actions=v['actions'],frozen_plan=plan),separators=(',',':')))
 except(UnsupportedWorld,ValueError,IndexError,OverflowError)as ex:res.update(status='BLOCKED',reason=str(ex))
 res['elapsed_seconds']=time.perf_counter()-begin;out[c['key']]=res;outpath.write_text(json.dumps(out,ensure_ascii=False,separators=(',',':')))
 print(j,res['status'],res.get('frozen_plan_found'),res.get('frozen_plan_actual_safe'),res.get('selected',{}).get('policy')if res.get('selected')else None,flush=True)
summary=dict(cases=len(out),total=len(cases),statuses=dict(collections.Counter(v['status']for v in out.values())),frozen_plans_found=sum(v.get('frozen_plan_found',False)for v in out.values()),frozen_false_safe=sum(v.get('frozen_plan_actual_safe')is False for v in out.values()),rescued_false_safe=sum(v.get('frozen_plan_actual_safe')is False and v.get('selected')is not None for v in out.values()))
(R/'reports/causal_summary.json').write_text(json.dumps(summary,indent=2));print(summary)
