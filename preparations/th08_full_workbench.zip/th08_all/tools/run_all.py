#!/usr/bin/env python3
"""Reproduce the offline workbench. Does not start or control TH08.
All commands are invoked with explicit argv (no shell). Logs and return codes
are retained; the pipeline stops at the first failed stage.
"""
import argparse,subprocess,sys,json,time,hashlib,platform,datetime
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--dat',type=Path,required=True);ap.add_argument('--mode',choices=['quick','all'],default='quick');ap.add_argument('--resume',action='store_true');ap.add_argument('--stop-after',help='Optional bounded-CI stage name');a=ap.parse_args()
 for d in('private','reports','build','reports/run_logs'):(R/d).mkdir(parents=True,exist_ok=True)
 start=time.perf_counter();receipt=dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),mode=a.mode,platform=platform.platform(),python=sys.version,dat=str(a.dat.resolve()),game_started=False,original_game_validated=False,benchmarks_rerun=a.mode=='all',steps=[])
 if a.resume and (R/'reports/run_receipt.json').exists():
  old=json.loads((R/'reports/run_receipt.json').read_text())
  if old.get('dat')!=str(a.dat.resolve()) or old.get('mode')!=a.mode:raise ValueError('Resume identity/mode mismatch')
  receipt=old;receipt['resumed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 done={s['label'] for s in receipt['steps'] if s['exit_code']==0}
 def run(label,cmd):
  if label in done:
   print(label+' [already passed]',flush=True)
   return
  path=R/'reports/run_logs'/f'{label}.log';begin=time.perf_counter();print(label,flush=True)
  with path.open('w',encoding='utf-8')as f:p=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT,text=True)
  receipt['steps'].append(dict(label=label,argv=[str(x)for x in cmd],exit_code=p.returncode,seconds=time.perf_counter()-begin,log=str(path.relative_to(R))))
  (R/'reports/run_receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2))
  if p.returncode:raise RuntimeError(f'{label} failed ({p.returncode}); see {path}')
  if a.stop_after==label:
   receipt['stopped_after']=label;(R/'reports/run_receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2));print('Stopped at requested bounded stage. Resume explicitly with --resume.');raise SystemExit(0)
 def py(label,script,*args):run(label,[sys.executable,script,*map(str,args)])
 py('identity','windows/preflight.py','--dat',a.dat.resolve())
 py('extract','tools/extract.py',a.dat.resolve());py('catalogue','tools/catalogue.py');py('sht','tools/analyze_sht.py');py('auxiliary','tools/analyze_auxiliary.py');py('deep_inventory','tools/deep_inventory.py')
 run('python_tests',[sys.executable,'-m','unittest','discover','-s','tests','-v'])
 run('cmake_configure',['cmake','-S','.','-B','build','-DCMAKE_BUILD_TYPE=Release']);run('cmake_build',['cmake','--build','build','--config','Release','--parallel','2']);run('ctest',['ctest','--test-dir','build','-C','Release','--output-on-failure'])
 exe=R/'build'/('th08lab_geometry_tests.exe'if sys.platform=='win32'else'th08lab_geometry_tests')
 if not exe.exists():exe=R/'build/Release/th08lab_geometry_tests.exe'
 run('native_geometry',[str(exe)])
 (R/'reports/native_geometry_tests.json').write_text((R/'reports/run_logs/native_geometry.log').read_text())
 if a.mode=='all':
  py('emitter_matrix','tools/exercise_emitters.py');py('kernel_cases','tools/kernel_cases.py')
  for d,label in(('demos','kinematic'),('causal_demos','conditional')):
   if label not in done:
    for p in(R/'reports'/d).glob('*.json'):p.unlink()
  py('kinematic','tools/bench_cases.py');py('conditional','tools/causal_cases.py');py('viability','tools/viability_counterexample.py');py('summary','tools/summarize.py')
 py('demo_inputs','windows/export_demo_inputs.py');py('trace_selfcheck','windows/trace_check.py','examples/trace_ok.jsonl','--reference','examples/trace_ok.jsonl');py('html','tools/build_catalogue.py')
 receipt.pop('stopped_after',None)
 receipt.update(completed=True,recorded_stage_seconds=sum(s['seconds'] for s in receipt['steps']),last_segment_seconds=time.perf_counter()-start,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),qualification='Offline tools only. Quick mode preserves bundled benchmark results; all mode reruns them. Neither executes the retail game.')
 (R/'reports/run_receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2));print('Completed. Open index.html. No retail-game or NMNB claim.')
if __name__=='__main__':
 try:main()
 except (OSError,RuntimeError,subprocess.SubprocessError)as e:print('ERROR:',e,file=sys.stderr);sys.exit(1)
