# TH08 全资源分析与条件规划工作台

**入口：打开 `index.html`。主报告：`docs/REPORT_ZH.md`。Windows：`docs/WINDOWS.md`。**

覆盖用户提供的整份dat：317项，24 ECL／1449子程序／36661条非终止指令，222个不同符卡ID／431开符记录，32 EX，113 ANM／1151脚本，8 SHT／227射击描述符，18 STD，33对话文件，4份内置Lunatic演示replay。

有实际可运行的解析器、受限ECL解释器、弹丸运动模型、C++几何、带输入延迟的控制器、批量场景实验、全部符卡档案、源函数探针和Windows身份/追踪检查工具。**没有已经接上原版的实时autoplay，没有声称任何整张符卡或全程NMNB已由本包验证通过。** 各级证据分开列在报告中。

## 可直接运行

需要Python 3.10+（标准库，不需pip依赖）。C++部分需要CMake与C++17编译器。

Windows开发者命令提示符：

```powershell
py -3 tools\run_all.py --dat D:\Games\th08\th08.dat --mode all
```

Linux / macOS：

```sh
python tools/run_all.py --dat /path/to/th08.dat --mode all
```

仅重建资源分析和基础测试，可用 `--mode quick`。此时不重跑性能/控制实验，附带结果仍为交付时测量，不是本机成绩。收据在 `reports/run_receipt.json`。

原生单独构建：

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release --parallel 2
ctest --test-dir build -C Release --output-on-failure
```

全量模式会在本地private目录解包用户自己的资源。ZIP不包含dat、exe、音画资源、字体或Windows预编译代理。只有分析产物、派生参数、代码、测试和文档。

## 核心结果，不隐藏负面实验

自主限定夹具126组：不动50组成功，正确延迟与短预判的贪心126组，当前beam64搜索86组。束搜索失败不是无解证明。不能用这些不含伤害/进度约束的短场景评价整个游戏。

候选相关限定夹具88组：冻结未来的路线15组实际不安全；每个候选重算自己的未来后，有限宏库在全部88组找到短期策略。它们不是完整ECL场景或原版成绩。

当前Python预测路径不能满足16ms；C++搜索几毫秒也不包括完整世界、数据采集和输入。详见性能范围和所有原始结果。

## 文件结构

- `index.html`：离线可搜索的222符卡目录和12段明确标注范围的夹具动画。
- `docs/spells/000.md`…`221.md`：每个ID的实际文件／sub／PC、参数、调用与阶段边、机制、候选解法组件和验收。
- `docs/ALL_STAGES.md`、`ALL_EX.md`：全部阶段与全部32个EX。
- `th08lab/`：PBGZ/ECL/ANM/SHT/STD/MSG/replay解析、受限发射与运动模型、特殊几何、trace。
- `native/`：真实矩形判定、环形预筛选、空间索引、输入队列、focus状态和有限时域控制器。
- `tools/`：复现、全矩阵测试、条件场景、动态目录、源码探针。
- `windows/`：只读哈希/PE身份检查、demo输入导出、phase-qualified trace对照；不是进程注入器。
- `reports/`：完整机器可读证据、阻塞点、实验结果、源码身份、原始反汇编。
- `examples/`：trace格式示例，不是原版日志。

## 状态词的准确含义

`STRUCTURAL_ONLY / ANALYZED_NOT_EXECUTED`：已解码／有语法依赖分析，不是完整执行。

`RETURNED_SLICE / HORIZON_ONLY`：受限入口的计算结束或到达时域，外部副作用受契约限制。

`FOUND_FIXTURE_PATH / CONDITIONAL_FIXTURE_POLICY_FOUND`：该明确设定的有限场景找到合法方向序列；非原版符卡。

`BLOCKED / UNSUPPORTED`：模型不掌握必要语义或状态，停止而不猜测。

`NO_PATH_FOUND_IN_RETAINED_BEAM`：当前近似搜索没找到，不是全局无解。

`NO_FULL_SPELL_SOLUTION`：本包所有完整符卡的当前状态。提升此状态需要原版身份、完整状态、真实输入链、完整阶段/通关日志和延迟验证。

## 上机前必须知道

源码提交固定a45e99fb1942714e6edded20847e32a654d56f97、portable64分支。原版32位内存布局不能套用64位结构。正常设备输入与replay的消费顺序不同。不要把逐帧sleep或“连续两次frameId相同”当作输入时序和快照一致性保证。

还需实现原版观测/输入桥和完整可核对的世界执行器，然后逐项关闭档案中的阻塞。本包没有用空函数、错误默认值或猜测地址伪装这部分工作已完成。
