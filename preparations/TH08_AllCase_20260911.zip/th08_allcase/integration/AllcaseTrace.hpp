#pragma once
// Read-only OFFLINE diagnostic recorder for the native modern source build.
// No memory-address hooks, no input injection, no gameplay writes.
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <mutex>
namespace th08alltrace {
inline unsigned bits(float f){unsigned u;static_assert(sizeof(u)==sizeof(f),"float32 required");std::memcpy(&u,&f,4);return u;}
struct Recorder {
    std::mutex lock; FILE* file=nullptr; unsigned long long tick=0,seq=0,rows=0,dropped=0;
    unsigned long long limit=2000000; // Explicit end marker makes truncation detectable.
    Recorder(){const char* p=std::getenv("TH08_ALLCASE_TRACE");if(!p||!*p)return;
        file=std::fopen(p,"wb");if(!file){std::perror("TH08_ALLCASE_TRACE");return;}
        std::setvbuf(file,nullptr,_IOFBF,1<<20);
        std::fprintf(file,"{\"kind\":\"header\",\"schema\":1,\"scope\":\"readonly_calls_not_world_snapshot\",\"float_format\":\"uint32_bits\",\"record_limit\":%llu}\n",limit);
    }
    ~Recorder(){if(file){std::fprintf(file,"{\"kind\":\"end\",\"rows\":%llu,\"dropped\":%llu}\n",rows,dropped);std::fclose(file);}}
    bool allow(){if(!file)return false;if(rows>=limit){++dropped;return false;}++rows;return true;}
};
inline Recorder& get(){static Recorder r;return r;}
inline void begin(){Recorder&r=get();std::lock_guard<std::mutex> guard(r.lock);++r.tick;r.seq=0;if(r.allow())std::fprintf(r.file,"{\"kind\":\"frame\",\"tick\":%llu,\"seq\":%llu}\n",r.tick,r.seq++);}
inline void input(unsigned keys,float x,float y,int state,int frozen){Recorder&r=get();std::lock_guard<std::mutex> guard(r.lock);if(r.allow())std::fprintf(r.file,"{\"kind\":\"player_entry\",\"tick\":%llu,\"seq\":%llu,\"keys\":%u,\"p\":[%u,%u],\"state\":%d,\"frozen\":%d}\n",r.tick,r.seq++,keys,bits(x),bits(y),state,frozen);}
inline void geometry(const char* kind,float px,float py,float hx,float hy,float cx,float cy,float sx,float sy,float ox,float oy,float angle,int state,int graze){Recorder&r=get();std::lock_guard<std::mutex> guard(r.lock);if(r.allow())std::fprintf(r.file,"{\"kind\":\"%s\",\"tick\":%llu,\"seq\":%llu,\"p\":[%u,%u],\"h\":[%u,%u],\"c\":[%u,%u],\"size\":[%u,%u],\"origin\":[%u,%u],\"angle\":%u,\"state\":%d,\"graze\":%d}\n",kind,r.tick,r.seq++,bits(px),bits(py),bits(hx),bits(hy),bits(cx),bits(cy),bits(sx),bits(sy),bits(ox),bits(oy),bits(angle),state,graze);}
inline void ecl(int sub,int slot,int clock,unsigned opcode,unsigned mask,unsigned long long pc){Recorder&r=get();std::lock_guard<std::mutex> guard(r.lock);if(r.allow())std::fprintf(r.file,"{\"kind\":\"ecl\",\"tick\":%llu,\"seq\":%llu,\"sub\":%d,\"slot\":%d,\"clock\":%d,\"opcode\":%u,\"mask\":%u,\"pc\":%llu}\n",r.tick,r.seq++,sub,slot,clock,opcode,mask,pc);}
}
