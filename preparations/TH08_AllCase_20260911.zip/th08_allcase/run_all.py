#!/usr/bin/env python3
"""Reproduce this DAT-specific audit and bounded native tests. No game launching."""
from pathlib import Path
import argparse,subprocess,sys,hashlib,json,shutil
ROOT=Path(__file__).resolve().parent
DAT_HASH='9d7edf43b8ddd347cbb641836f6b5050745dd936f688daebbf9382ca557043bb'
def run(cmd,name):
 print('RUN',name,flush=True)
 with (ROOT/'results'/name).open('w',encoding='utf8') as f:
  p=subprocess.run([str(x) for x in cmd],cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,text=True)
 if p.returncode:raise RuntimeError(f'{name}: exit {p.returncode}; inspect results/{name}')
def binary(name):
 suffix='.exe' if sys.platform=='win32' else ''
 for p in [ROOT/'build'/('Release')/(name+suffix),ROOT/'build'/(name+suffix)]:
  if p.exists():return p
 raise FileNotFoundError('build executable missing: '+name)
def main():
 p=argparse.ArgumentParser();p.add_argument('--dat',type=Path,required=True);p.add_argument('--no-build',action='store_true');p.add_argument('--reuse-extraction',action='store_true');a=p.parse_args()
 if hashlib.sha256(a.dat.read_bytes()).hexdigest()!=DAT_HASH:raise ValueError('DAT differs from the audited resource. This package intentionally does not certify another version.')
 (ROOT/'results').mkdir(exist_ok=True)
 if not a.no_build:
  run(['cmake','-S',ROOT,'-B',ROOT/'build','-DCMAKE_BUILD_TYPE=Release'],'cmake_configure.txt')
  run(['cmake','--build',ROOT/'build','--config','Release','--parallel','2'],'build.log')
 if not a.reuse_extraction:run([sys.executable,'tools/extract_all.py',a.dat.resolve()],'extraction.txt')
 elif not (ROOT/'private_resources/ecldata1.ecl').exists():raise FileNotFoundError('no extracted resources')
 for name in ['analyze_ecl','analyze_timeline','audit_corpus','resource_tables','atlas','dossiers','run_emitter_slices','scan_slices','check_causal_slices']:
  run([sys.executable,'tools/'+name+'.py'],name+'.txt')
 run([sys.executable,'-m','unittest','discover','-s','tests','-v'],'python_tests.txt')
 run(['ctest','--test-dir',ROOT/'build','-C','Release','--output-on-failure'],'ctest.txt')
 for name in ['kernel_tests','mechanism_tests','pressure_suite','bench_real_emitter']:
  run([binary(name)],'native_emitter_benchmark.json' if name=='bench_real_emitter' else name+'.json')
 run([binary('causal_tests'),ROOT/'results/causal_paths.csv'],'causal_tests.json')
 cov=json.loads((ROOT/'reports/allcase_coverage.json').read_text())
 print(json.dumps({'pipeline':'completed','scope':'resource audit and bounded model tests ONLY','full_spell_solutions_verified':0,'coverage':cov},ensure_ascii=False,indent=2))
if __name__=='__main__':
 try:main()
 except Exception as e:print('FAILED:',e,file=sys.stderr);raise SystemExit(1)
