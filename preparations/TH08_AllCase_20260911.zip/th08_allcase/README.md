# TH08 全资源审计与条件规划实验包

## 先看什么

**完整结论与设计：[`docs/REPORT.zh-CN.md`](docs/REPORT.zh-CN.md)。**

**全部222个原始符卡ID：[`ALL_222_SPELLS.html`](ALL_222_SPELLS.html)。** HTML可直接本地打开并搜索，不需要服务器或网络。

**逐个来源的实际参数：[`docs/PHASE_DOSSIERS.md`](docs/PHASE_DOSSIERS.md)。** 431个开符来源分别记录，不合并本篇/练习文件；包含9,539行展开后的发射、变换、EX和阶段参数。共享子程序在不同符卡来源下会重复，所以这个数不是独立指令数。

本包不是“一键原版NMNB机器人”。已可运行的是：全资源解析、全量结构审计、严格受限的标量发射片段执行、C++碰撞/空间索引、部分特殊机制内核、有限时域条件规划实验、源码只读记录补丁生成器和事件比较器。**完整ECL/ANM/伤害/生命周期世界适配器、原版正常输入驱动和222张完整成功路线尚未实现/验证。** `reports/allcase_coverage.json`明确保存`full_spell_solutions_verified: 0`，不能删去这个字段后把静态覆盖当作成功覆盖。

## 输入身份

本包针对上传的这一份`th08.dat`：46,838,025字节，SHA-256：

```
9d7edf43b8ddd347cbb641836f6b5050745dd936f688daebbf9382ca557043bb
```

源码分析使用`port/portable-64bit`分支检查点：

```
a45e99fb1942714e6edded20847e32a654d56f97
```

上一轮是`af72ca98d044104d396b501072f4d1570c374235`附近的**有未提交变动**工作区，不应视为相同源码。当前native64布局不能使用旧32位对象偏移。

原版DAT/EXE、贴图、音乐和字体均不随本包分发。`private_resources/`由用户自己提供的DAT生成。

## 最小复现

需要Python 3.10或更新、CMake 3.16或更新、支持C++17的编译器。核心分析脚本仅依赖Python标准库。已在无构建产物/无解包资源的干净副本从DAT完成一键复现，见`results/clean_reproduction.txt`。实际测试平台是Linux x86-64、GCC14.2；CMake包含MSVC配置，但这里没有实测Windows编译/运行。

```sh
python run_all.py --dat "/absolute/path/to/th08.dat"
```

Windows的资源分析与原生实验包命令形式：

```powershell
python run_all.py --dat "D:\Touhou\th08.dat"
```

这个命令编译本包、解包用户自己的资源、重做全量分析、运行Python/CTest及原生测试，将输出写入`reports/`与`results/`。遇到未知/不支持的执行语义，受限扫描记录阻塞位置，不把它当作NOP。

仅编译与测试，不重新分析资源：

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release --parallel 2
ctest --test-dir build -C Release --output-on-failure
python -m unittest discover -s tests -v
```

原生程序在Linux为`build/<name>`；Visual Studio多配置构建一般为`build/Release/<name>.exe`。

## 直接运行一个路线实验

```sh
./build/trace_plan examples/gate_fixture.csv 64 192 352 0.825 0.825 2 1.414213538 228 352 fixture results/gate_path.csv
./build/causal_tests results/causal_paths.csv
./build/pressure_suite
```

`gate_fixture.csv`是合成碰撞恢复窗口。`causal_tests`是合成的真正玩家取样事件。两者只生成合法九方向移动原语，不向游戏发送输入；不是铃仙或其他符卡的原版录像。

`trace_plan`参数顺序：

```
trace.csv horizon start_x start_y half_x half_y axis_speed diagonal_speed goal_x goal_y assurance output.csv
```

CSV列为：

```
tick,kind,x,y,width,height,origin_x,origin_y,angle,id,generation
```

`kind=B`是普通轴对齐判定，`L`是按原版公式处理的激光。`tick`是约定的碰撞检查阶段，不是屏幕刷新或墙钟毫秒。宽/高是**满尺寸**，玩家参数是**半尺寸**。不能把一次实际游戏录下的未来直接标为`candidate_independent`：改变玩家路线可能改变未来弹幕。`recorded_path`会被规划器拒绝。

## 源码对应验证与接入

详见[`docs/INTEGRATION.md`](docs/INTEGRATION.md)。下面两个脚本不改源仓库：

```sh
python tools/source_geometry_oracle.py --repo /path/to/th08 --out results/source_oracle
python tools/instrument_repo.py --repo /path/to/th08 --out /tmp/th08-allcase-trace
```

第二个命令输出经过源文件哈希守卫的源码副本及`trace.patch`。Linux仓库已有native构建时，可以编译检查副本：

```sh
python tools/instrument_repo.py --repo /path/to/th08 --out /tmp/th08-allcase-trace --compile-build /path/to/th08/build/portable-linux-x86_64
```

本次实际已对Player.cpp、Global.cpp、EclRun.cpp的记录版副本编译成功，并通过`git apply --check --ignore-whitespace`。只编译，没有把完整游戏运行冒充已完成。原仓库保持干净。

## 文件地图

| 文件/目录 | 内容与证据等级 |
|---|---|
| `reports/archive_manifest.json` | 317项资源的内容哈希及解包一致性结果 |
| `reports/allcase_coverage.json` | 全量覆盖总账；静态与动态分开 |
| `reports/opcode_contracts.json` | 0–184编号槽、负载布局、出现次数；不是全VM实现 |
| `reports/subprogram_atlas.json` | 全部1,449个sub的读写/依赖/跳转/调用摘要 |
| `reports/spell_atlas.json` | 431开符来源、222 ID、难度兼容切片与机制标签 |
| `reports/phase_contracts.json` | 每个开符来源的具体控制点、发射与EX参数 |
| `reports/all_masks_disassembly/` | 24 ECL全部掩码的反汇编 |
| `reports/all_masks_timeline/` | 全部timeline指令，不只Lunatic |
| `reports/anm_all.json` | 113 ANM的脚本与sprite结构，不含贴图 |
| `reports/sht_complete.json` | 8 SHT的全部50档记录、227个射击描述符出现项 |
| `reports/std_complete.json` | 18 STD的场景几何/实例/指令结构 |
| `reports/bullet_and_anm_contracts.json` | 21个初始弹型碰撞尺寸、33个ANM随机指令站点 |
| `reports/slice_coverage.json` | 21,735次严格受限片段尝试，失败/缺上下文均保留 |
| `reports/compiled_slice_schedules.json` | 受限执行得到的发射请求序列；不是实际弹池推进 |
| `native/geometry.hpp` | 原版式AABB/激光/消弹判定、网格、规则环宽阶段 |
| `native/mechanisms.hpp` | 三种结界、两种铃仙局部状态机、缩时局部算子、U16 RNG递推 |
| `native/planner.hpp` | 固定/已证独立危险下的有限beam路线规划 |
| `native/causal.hpp` | 明确标为fixture的候选相关取样与共享条件批次 |
| `integration/AllcaseTrace.hpp` | 原生源码只读记录器；非全世界快照、非原版DLL |
| `tools/trace_compare.py` | 第一差异字段、缺尾/丢记录/长度错误拒绝通过 |
| `results/` | 实际执行结果；来源和测试范围见每份JSON |
| `figures/` | 本次合成实验轨迹图，不含游戏截图 |

`legacy_mask8_*`与`reports/disassembly/`继承自上一轮的mask8视图；全量权威入口是`spell_atlas.json`、`allcase_coverage.json`和`all_masks_*`目录。不要以旧mask8清单统计全部符卡。

## 必须保留的限制

静态掩码兼容不等于动态可达；发射请求数不等于实际成功生成数；几何内核对照不等于Windows原版位级等价；模型里找到路线不等于全符卡成功；重复测试没有证明硬实时上界。失败状态不得转换成“安全地停住”，搜索穷尽不得转换成“数学无解”。
