#include "causal.hpp"
#include <iostream>
#include <fstream>
#include <iomanip>
using namespace th08plan;
int collision_tick(const std::vector<V>& pts,const std::vector<AimedEvent>& events,V half){
 std::vector<std::unique_ptr<DeltaBatch>> batches;for(unsigned t=0;t<pts.size();++t){for(auto&e:events)if(e.tick==t)batches.push_back(std::make_unique<DeltaBatch>(e,pts[t],half));for(auto&b:batches){uint64_t q=0;if(b->query(t,pts[t],q))return int(t);}}return -1;
}
int main(int argc,char**argv){try {
 Trace tr;tr.assurance="fixture";tr.frames.resize(96);V p{192,352},half{.825f,.825f};Speeds s{2,1.414213538f};
 AimedEvent e;e.tick=32;e.emitters.push_back({{192,128},{4,4},4,0,0,1,false});std::vector<AimedEvent> ev{e};
 std::vector<V> naive(96);for(int t=0;t<96;++t){p=move(p,{t<30?1:0,0},s);naive[t]=p;}
 int bad=collision_tick(naive,ev,half);if(bad<0)throw std::runtime_error("counterexample did not fail");
 Options o;o.beam=32;o.budget_ms=1000;o.expansion_limit=200000;o.terminal={{252,352},{24,24}};o.require_terminal=true;
 auto r=causal_plan(tr,ev,{192,352},half,s,{},o);if(r.actions.empty()||collision_tick(r.points,ev,half)>=0)throw std::runtime_error("causal path missing or colliding");
 if(argc>1){std::ofstream f(argv[1]);f<<"tick,naive_x,naive_y,causal_x,causal_y,dx,dy\n"<<std::setprecision(9);for(unsigned t=0;t<96;++t)f<<t<<','<<naive[t].x<<','<<naive[t].y<<','<<r.points[t].x<<','<<r.points[t].y<<','<<r.actions[t].dx<<','<<r.actions[t].dy<<'\n';}
 std::cout<<"{\"scenario\":\"synthetic_aimed_event_mechanism\",\"horizon\":96,\"naive_route_true_collision_tick\":"<<bad<<",\"causal_status\":\""<<r.status<<"\",\"causal_collision_tick\":-1,\"elapsed_ms\":"<<r.elapsed_ms<<",\"expansions\":"<<r.expansions<<",\"conditional_batches\":"<<r.conditional_batches<<",\"delta_bullets_created\":"<<r.delta_bullets_created<<",\"delta_checks\":"<<r.delta_checks<<",\"pressure_tests\":[";
 int example=0;
 for(int n:{32,300})for(unsigned samples:{0,8,4,2}){Trace v;v.assurance="fixture";v.frames.resize(96);AimedEvent a;a.tick=32;for(int j=0;j<n;++j)a.emitters.push_back({{float((j*37)%384),float(16+(j*17)%160)},{4,4},2.5f,0,0,1,false});Options b=o;b.budget_ms=8;if(samples==2)b.beam=16;auto x=causal_plan(v,{a},{192,352},half,s,{},b,samples);
 std::cout<<(example++?",":"")<<"{\"simultaneous_origins\":"<<n<<",\"event_sample_cap\":"<<samples<<",\"beam\":"<<b.beam<<",\"budget_ms\":8,\"status\":\""<<x.status<<"\",\"elapsed_ms\":"<<x.elapsed_ms<<",\"expansions\":"<<x.expansions<<",\"delta_bullets_created\":"<<x.delta_bullets_created<<"}";}
 std::cout<<"]}\n";return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
