#pragma once
#include "geometry.hpp"
#include <stdexcept>
namespace th08plan {
constexpr float pi=3.1415927410125732f,tau=6.2831854820251465f;
inline float zun_angle(float a,float b){int i=0;a+=b;while(a>pi){a-=tau;if(i++>16)break;}while(a< -pi){a+=tau;if(i++>16)break;}return a;}
struct WarpBullet {V p,v;float angle=0;int cooldown=0;bool live=true;};
enum class Barrier {Narrow,Medium,Wide};
inline int zone(V p,Barrier type,bool previous){
    float xl,xr,yt,yb,oxl,oxr,oyt,oyb;
    if(type==Barrier::Narrow){xl=124.11774444580078f;xr=259.88226318359375f;yt=140.11773681640625f;yb=275.88226318359375f;oxl=56.23548889160156f;oxr=327.7645263671875f;oyt=72.23548889160156f;oyb=343.7645263671875f;}
    else if(type==Barrier::Medium){xl=112.80403137207031f;xr=271.1959533691406f;yt=128.8040313720703f;yb=287.1959533691406f;oxl=33.608070373535156f;oxr=350.3919372558594f;oyt=49.608070373535156f;oyb=366.3919372558594f;}
    else{xl=56.23548889160156f;xr=327.7645263671875f;yt=88.23548889160156f;yb=359.7645263671875f;oxl=previous?-31.100006103515625f:-32.0f;oxr=416;oyt=0;oyb=448;}
    if(p.x>xl&&p.x<xr&&p.y>yt&&p.y<yb)return 0;
    if(p.x>oxl&&p.x<oxr&&p.y>oyt&&p.y<oyb)return 1;return 2;
}
// Invoked at the real EX callback phase, NOT automatically every bullet tick.
inline bool warp(WarpBullet& b,Barrier t){
    if(!b.live)return false;if(b.cooldown){--b.cooldown;return false;}
    int current=zone(b.p,t,false),previous=zone({b.p.x-b.v.x,b.p.y-b.v.y},t,true);
    if(current==previous)return false;b.cooldown=2;b.v.x*=-1.0f;b.v.y*=-1.0f;
    float inner=t==Barrier::Narrow?67.88225555419922f:t==Barrier::Medium?79.19596862792969f:135.76451110839844f;
    float outer=t==Barrier::Narrow?135.76451110839844f:t==Barrier::Medium?158.39193725585938f:224.0f;
    float a=(current==0||previous==0)?outer:inner,d=(current==0||previous==0)?inner:outer;
    float cy=t==Barrier::Wide?224.0f:208.0f;
    b.p.x=(b.p.x-192.0f)*a/d+192.0f;b.p.y=(b.p.y-cy)*a/d+cy;b.angle=zun_angle(b.angle,pi);return true;
}
struct PhaseBullet {V v;float angle=0,speed=0;uint32_t flags=0;int type=1,sprite=0,baseSprite=0,alpha=255,alphaInterpolation=0;bool live=true,disabled=false,additive=false;};
inline V polar(float a,float m){return {std::cos(a)*m,std::sin(a)*m};}
// Bullet-local effects only: the EX12 attached-child pause/background effects
// MUST also be handled by the world adapter. They are deliberately not elided.
inline void reisen_two_state(PhaseBullet& b,uint32_t marker,float driftAngle,float driftSpeed,float mult){
    if(!b.live||!(b.flags&marker))return;
    if(b.type==1){b.type=0;b.additive=true;b.sprite+=16;b.disabled=true;b.v=polar(driftAngle,mult*driftSpeed);}
    else{b.type=1;b.additive=false;b.sprite-=16;b.disabled=false;b.v=polar(b.angle,mult*b.speed);}
}
inline void reisen_three_state(PhaseBullet& b,uint32_t marker,float driftSpeed,float mult){
    if(!b.live||!(b.flags&marker))return;
    if(b.type==1){b.type=0;b.additive=true;b.alpha=0;b.sprite+=16;b.disabled=true;b.v=polar(b.angle,mult*driftSpeed);}
    else if(b.type==0){b.type=2;b.alpha=0;b.alphaInterpolation=15;}
    else{b.type=1;b.additive=false;b.sprite-=16;b.disabled=false;b.v=polar(b.angle,mult*b.speed);}
}
inline void enter_scaled_time(std::vector<PhaseBullet>& bs,int divisor,float& mult){
    if(divisor<=0)throw std::invalid_argument("time divisor");mult=1.0f/float(divisor);
    for(auto&b:bs)if(b.live){b.v.x*=mult;b.v.y*=mult;b.baseSprite=b.sprite;if(b.sprite>=96&&b.sprite<=111)b.sprite=111;}
}
inline void exit_scaled_time(std::vector<PhaseBullet>& bs,int divisor,float& mult,uint32_t& flags){
    if(divisor<=0||!std::isfinite(mult)||mult<=0)throw std::invalid_argument("time scale");float scale=1.0f/mult;
    for(auto&b:bs)if(b.live){b.v.x*=scale;b.v.y*=scale;if(b.sprite>=96&&b.sprite<=111)b.sprite=b.baseSprite;}
    mult=1.0f/float(divisor);if(mult<1.0f)flags|=0x20U;mult=1.0f; // Source explicitly overwrites it.
}
struct Rng16 {uint16_t seed=0;uint32_t generations=0;uint16_t next(){uint16_t t=uint16_t((seed^0x9630)-0x6553);seed=uint16_t(((t&0xc000)>>14)+unsigned(t)*4);++generations;return seed;}};
// Only the U16 transition is specified here. Original GetRandomU32 expression
// order and all RNG consumers must be matched before integrating a full world.
}
