// Bounded decoder for user-owned TH08 archive data; no game assets included.
#include <cstddef>
#include <cstdint>
#include <array>
#ifdef _WIN32
#define EXPORT extern "C" __declspec(dllexport)
#else
#define EXPORT extern "C"
#endif
EXPORT int th08_lzss(const uint8_t* data, size_t n, uint8_t* out, size_t expected) {
    std::array<uint8_t,8192> dict{}, initialized{};
    size_t bit=0, used=0, wp=1; bool bad=false;
    auto take=[&](unsigned count) -> uint32_t {
        if(bit+count > n*8+16 || (bit+count > n*8 && used != expected)) {bad=true;return 0;}
        uint32_t value=0;
        while(count--) {value=(value<<1)|(bit<n*8 ? ((data[bit>>3]>>(7-(bit&7)))&1):0);++bit;}
        return value;
    };
    while(!bad) {
        auto literal=take(1); if(bad)return -1;
        if(literal) {
            uint8_t v=static_cast<uint8_t>(take(8)); if(bad || used>=expected)return -2;
            out[used++]=v;dict[wp]=v;initialized[wp]=1;wp=(wp+1)&8191;
        } else {
            auto off=take(13);if(bad)return -3;
            if(off==0) return used==expected?0:-4;
            auto count=take(4)+3;if(bad || used+count>expected)return -5;
            for(unsigned i=0;i<count;++i) {
                auto at=(off+i)&8191; if(!initialized[at])return -6;
                uint8_t v=dict[at];out[used++]=v;dict[wp]=v;initialized[wp]=1;wp=(wp+1)&8191;
            }
        }
    }
    return -7;
}
