#pragma once
#include "planner.hpp"
#include <memory>
#include <map>
#include <tuple>
namespace th08plan {
// A separate, bounded candidate-dependent model. These are already-FIRED,
// constant-velocity event deltas. Spawn ANM, ECL, RNG, damage and pool effects
// are NOT silently approximated here: they must be resolved by an adapter.
struct AimedEmitter { V origin,full_size{4,4}; float speed=4,offset=0,step=0; int count=1; bool circle=false; };
struct AimedEvent { unsigned tick=0; std::vector<AimedEmitter> emitters; bool advance_on_birth=true; };
struct DeltaBatch {
    std::vector<Hazard> hazards; std::vector<V> velocity;
    std::unique_ptr<Grid> grid; int latest_tick=-1; V half;
    explicit DeltaBatch(const AimedEvent&e,V p,V h): latest_tick(int(e.tick)-(e.advance_on_birth?1:0)),half(h) {
        for(const auto& em:e.emitters) {
            if(em.count<1||em.count>1536||!finite(em.origin)||!finite(em.full_size))throw std::invalid_argument("invalid event");
            float aim=std::atan2(p.y-em.origin.y,p.x-em.origin.x);
            for(int j=0;j<em.count;++j) {
                float a=0;
                if(em.circle) {a=aim;a+=float(j)*6.2831854820251465f/float(em.count);a+=em.offset;}
                else {a=(em.count&1)?float((j+1)/2)*em.step:float(j/2)*em.step+em.step*.5f;if(j&1)a*=-1;a+=aim;a+=em.offset;}
                Hazard b;b.box={em.origin,em.full_size};hazards.push_back(b);velocity.push_back({std::cos(a)*em.speed,std::sin(a)*em.speed});
            }
        }
    }
    bool query(unsigned t,V p,uint64_t& checks) {
        if(int(t)<latest_tick)throw std::logic_error("delta cache queried backwards");
        bool changed=false;
        while(latest_tick<int(t)) {for(size_t j=0;j<hazards.size();++j){hazards[j].box.center.x+=velocity[j].x;hazards[j].box.center.y+=velocity[j].y;}++latest_tick;changed=true;}
        if(!grid||changed)grid=std::make_unique<Grid>(hazards,half);
        return grid->query(p,&checks);
    }
};
struct DeltaWorld { std::shared_ptr<DeltaWorld> parent; std::shared_ptr<DeltaBatch> batch; uint64_t id=0; };
struct CNode {V p;int parent=-1;Action action;float score=0;std::shared_ptr<DeltaWorld> world;};
struct CausalResult:Plan {uint64_t conditional_batches=0,delta_bullets_created=0,delta_checks=0;};
inline CausalResult causal_plan_inner(const Trace& shared,const std::vector<AimedEvent>& events,V start,V half,Speeds speeds,const std::vector<Action>& committed,const Options&o,unsigned max_event_samples=0) {
    CausalResult r;auto t0=std::chrono::steady_clock::now();
    auto elapsed=[&](){return std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-t0).count();};
    auto finish=[&](std::string s){r.status=std::move(s);r.elapsed_ms=elapsed();if(r.status!="FIXTURE_CAUSAL_MODEL_PATH"){r.actions.clear();r.points.clear();}return r;};
    if(shared.assurance!="fixture")return finish("REQUIRES_VERIFIED_CAUSAL_ADAPTER");
    if(shared.dependency_epoch!=o.expected_epoch)return finish("INVALIDATED_MODEL");
    if(shared.frames.empty()||shared.frames.size()>4096||o.beam==0||o.beam>4096||o.pruning_cell<0.0001f||!std::isfinite(o.pruning_cell)||!finite(start)||!finite(half)||half.x<0||half.y<0||!std::isfinite(speeds.axis)||!std::isfinite(speeds.diag)||speeds.axis<=0||speeds.diag<=0||!finite(o.terminal.center)||!finite(o.terminal.size)||o.terminal.size.x<0||o.terminal.size.y<0||!std::isfinite(o.budget_ms)||o.budget_ms<0)return finish("INVALID_ARGUMENT");
    for(auto a:committed)if(a.dx< -1||a.dx>1||a.dy< -1||a.dy>1)return finish("INVALID_ARGUMENT");
    std::map<unsigned,std::vector<const AimedEvent*>> calendar;
    for(auto&e:events){if(e.tick>=shared.frames.size())return finish("EVENT_OUTSIDE_HORIZON");unsigned count=0;for(auto& em:e.emitters){if(em.count<1||em.count>1536||!finite(em.origin)||!finite(em.full_size)||em.full_size.x<0||em.full_size.y<0||!std::isfinite(em.speed)||!std::isfinite(em.offset)||!std::isfinite(em.step))return finish("INVALID_EVENT");count+=unsigned(em.count);if(count>1536)return finish("EVENT_WORKLOAD_OUTSIDE_MODEL");}if(count>1536)return finish("EVENT_WORKLOAD_OUTSIDE_MODEL");calendar[e.tick].push_back(&e);}
    std::vector<Grid> grids;grids.reserve(shared.frames.size());for(auto&f:shared.frames){grids.emplace_back(f,half);if(elapsed()>o.budget_ms)return finish("DEADLINE_NO_PLAN");}
    std::vector<std::vector<CNode>> layers(1);layers[0].push_back({start});
    for(unsigned t=0;t<shared.frames.size();++t) {
        std::vector<CNode> next;next.reserve(layers.back().size()*9);
        for(int k=0;k<int(layers.back().size());++k)for(int dy=-1;dy<=1;++dy)for(int dx=-1;dx<=1;++dx) {
            if(t<committed.size()&&(dx!=committed[t].dx||dy!=committed[t].dy))continue;
            if(r.expansions>=o.expansion_limit)return finish("EXPANSION_LIMIT_NO_PLAN");
            if(elapsed()>o.budget_ms)return finish("DEADLINE_NO_PLAN");
            ++r.expansions;V p=move(layers.back()[k].p,{dx,dy},speeds);
            if(grids[t].query(p,&r.collision_checks))continue;
            auto world=layers.back()[k].world;
            bool dead=false;for(auto w=world;w;w=w->parent)if(w->batch->query(t,p,r.delta_checks)){dead=true;break;}
            if(dead)continue;
            float x=p.x-o.terminal.center.x,y=p.y-o.terminal.center.y;
            next.push_back({p,k,{dx,dy},x*x+y*y+.03f*(dx*dx+dy*dy),world});
        }
        std::sort(next.begin(),next.end(),[](const CNode&a,const CNode&b){if(a.score!=b.score)return a.score<b.score;if(a.p.x!=b.p.x)return a.p.x<b.p.x;if(a.p.y!=b.p.y)return a.p.y<b.p.y;return a.parent<b.parent;});
        if(calendar.count(t)) {
            // Choose realizable event waypoints BEFORE allocating new worlds.
            // No angle/position quantization: every representative is an exact
            // candidate reached by its stored legal input prefix.
            if(max_event_samples && next.size()>max_event_samples) {
                std::vector<CNode> selected;std::vector<bool> used(next.size());
                selected.push_back(next.front());used[0]=true;
                while(selected.size()<max_event_samples) {
                    double farthest=-1;size_t best=0;
                    for(size_t j=0;j<next.size();++j)if(!used[j]) {
                        double nearest=1e100;
                        for(auto&v:selected) {
                            double dx=next[j].p.x-v.p.x,dy=next[j].p.y-v.p.y;
                            double d=dx*dx+dy*dy;
                            if(next[j].world!=v.world)d+=1e6; // preserve distinct incoming worlds first.
                            nearest=std::min(nearest,d);
                        }
                        if(nearest>farthest){farthest=nearest;best=j;}
                    }
                    used[best]=true;selected.push_back(next[best]);
                }
                next=std::move(selected);
            }
            std::vector<CNode> conditioned;
            for(auto n:next) {
                if(elapsed()>o.budget_ms)return finish("DEADLINE_NO_PLAN");
                for(auto*e:calendar[t]) {
                    auto batch=std::make_shared<DeltaBatch>(*e,n.p,half);r.delta_bullets_created+=batch->hazards.size();
                    if(r.delta_bullets_created>2000000)return finish("DELTA_MEMORY_WORK_LIMIT");
                    n.world=std::make_shared<DeltaWorld>(DeltaWorld{n.world,batch,++r.conditional_batches});
                }
                bool dead=false;for(auto w=n.world;w;w=w->parent)if(w->batch->query(t,n.p,r.delta_checks)){dead=true;break;}
                if(!dead)conditioned.push_back(n);
            }
            next=std::move(conditioned);
            std::sort(next.begin(),next.end(),[](const CNode&a,const CNode&b){return a.score<b.score;});
        }
        std::vector<CNode> kept;std::map<std::tuple<uint64_t,int,int>,bool> seen;
        for(auto&n:next){auto key=std::make_tuple(n.world?n.world->id:0,int(std::floor(n.p.x/o.pruning_cell)),int(std::floor(n.p.y/o.pruning_cell)));if(seen.emplace(key,true).second){kept.push_back(n);if(kept.size()>=o.beam)break;}}
        if(kept.empty())return finish("SEARCH_EXHAUSTED_NOT_PROOF_OF_UNSAT");
        // Past layers only need positions/parents/actions for backtracking.
        for(auto&n:layers.back())n.world.reset();layers.push_back(std::move(kept));r.reached_frames=t+1;
    }
    int k=-1;for(int j=0;j<int(layers.back().size());++j)if(!o.require_terminal||bullet_hit(layers.back()[j].p,{0,0},o.terminal)){k=j;break;}
    if(k<0)return finish("NO_TERMINAL_WITNESS");
    r.points.resize(shared.frames.size());r.actions.resize(shared.frames.size());
    for(size_t t=shared.frames.size();t>0;--t){auto&n=layers[t][k];r.points[t-1]=n.p;r.actions[t-1]=n.action;k=n.parent;}
    // Independent path replay rebuilds conditional batches at the selected samples.
    std::vector<std::unique_ptr<DeltaBatch>> truth;V p=start;
    for(unsigned t=0;t<shared.frames.size();++t){if(elapsed()>o.budget_ms)return finish("DEADLINE_NO_PLAN");p=move(p,r.actions[t],speeds);if(grids[t].scan(p))return finish("INTERNAL_RECHECK_FAILED");
        for(auto*e:calendar[t])truth.push_back(std::make_unique<DeltaBatch>(*e,p,half));
        for(auto&b:truth){uint64_t dummy=0;if(b->query(t,p,dummy))return finish("INTERNAL_CAUSAL_RECHECK_FAILED");}}
    if(elapsed()>o.budget_ms)return finish("DEADLINE_NO_PLAN");
    return finish("FIXTURE_CAUSAL_MODEL_PATH");
}
inline CausalResult causal_plan(const Trace& tr,const std::vector<AimedEvent>& events,V start,V half,Speeds speeds,const std::vector<Action>& committed,const Options& o,unsigned cap=0){
    auto t=std::chrono::steady_clock::now();CausalResult r=causal_plan_inner(tr,events,start,half,speeds,committed,o,cap);
    r.elapsed_ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-t).count();
    if(r.elapsed_ms>o.budget_ms&&r.status=="FIXTURE_CAUSAL_MODEL_PATH"){r.status="DEADLINE_NO_PLAN_AFTER_CLEANUP";r.actions.clear();r.points.clear();}
    return r;
}

}
