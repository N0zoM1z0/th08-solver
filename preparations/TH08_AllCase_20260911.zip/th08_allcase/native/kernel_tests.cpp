#include "planner.hpp"
#include <iostream>
#include <random>
#include <iomanip>
#include <numeric>
using namespace th08plan;
static void check(bool ok,const char*s) {if(!ok)throw std::runtime_error(s);}
static double pct(std::vector<double> x,double p){std::sort(x.begin(),x.end());return x[size_t(std::ceil(p*x.size()))-1];}
int main(){try {
    std::mt19937 rng(20260911);auto uni=[&](float a,float b){return std::uniform_real_distribution<float>(a,b)(rng);};
    check(bullet_hit({0,0},{1,1},{{2,0},{2,2}}),"inclusive AABB boundary");
    check(!bullet_hit({0,0},{1,1},{{2.001f,0},{2,2}}),"AABB gap");
    check(!cancel_hit({10,0},{{0,0},{0,0},10,0,true}),"circle strict edge");
    check(cancel_hit({9.999f,0},{{0,0},{0,0},10,0,true}),"circle interior");
    check(cancel_hit({10,0},{{0,0},{20,4},0,0,true}),"rectangle inclusive edge");
    Laser l{{100,0},{200,2},{0,0},0.7853981852531433f};V q=rotate({100,2.2f},l.angle);
    check(!laser_hit(q,{1,1},l),"laser must not substitute physical SAT");
    check(2.2f<1.0f+std::sqrt(2.0f),"physical SAT counterexample sanity");
    uint64_t grid_queries=0,grid_disagreement=0,ring_queries=0,ring_misses=0;
    for(int trial=0;trial<40;++trial){
        std::vector<Hazard> h;
        for(int k=0;k<256;++k) {Hazard b;b.box={{uni(-100,484),uni(-100,548)},{uni(1,40),uni(1,40)}};h.push_back(b);}
        for(int k=0;k<16;++k) {Hazard b;b.kind=Hazard::Kind::Laser;b.laser={{uni(0,400),uni(0,448)},{uni(1,590),uni(1,288)},{uni(-50,450),uni(-50,500)},uni(-3.142f,3.142f)};h.push_back(b);}
        V half{uni(0.5f,2),uni(0.5f,2)};Grid g(h,half);
        for(int k=0;k<10000;++k) {V p{uni(-20,404),uni(-20,468)};++grid_queries;if(g.query(p)!=g.scan(p))++grid_disagreement;}
    }
    for(int z=0;z<10000;++z) {
        int n=1+rng()%1536;V c{uni(0,384),uni(0,448)},p{uni(0,384),uni(0,448)},half{uni(1,9),uni(1,9)};
        float radius=uni(0,500),a=uni(-3.14f,3.14f);auto ids=ring_candidates(p,c,radius,a,n,half,0.002f);
        std::vector<bool> included(n);for(auto j:ids)included[j]=true;
        for(int j=0;j<n;++j){float theta=a+6.283185307179586f*j/n;V b{c.x+radius*std::cos(theta),c.y+radius*std::sin(theta)};
            if(bullet_hit(p,{0,0},{b,{half.x*2,half.y*2}})&&!included[j])++ring_misses;}
        ++ring_queries;
    }
    check(grid_disagreement==0,"grid false negative or mismatch");check(ring_misses==0,"ring misses");
    Trace gate;gate.assurance="fixture";gate.frames.resize(64);
    for(int t=36;t<64;++t){Hazard h;h.box={{192,224},{8,448}};gate.frames[t].push_back(h);}
    Options op;op.require_terminal=true;op.terminal={{228,352},{8,8}};op.budget_ms=1000;op.beam=64;
    Plan gp=plan(gate,{192,352},{0.825f,0.825f},{2,1.414213538f},{},op);
    check(gp.status=="FIXTURE_MODEL_PATH","gate path missing");
    check(gp.points[36].x>196.825f,"gate recovery violated");
    Plan stale;Trace mismatch=gate;mismatch.dependency_epoch=1;stale=plan(mismatch,{192,352},{1,1},{2,1.4142f},{},op);
    check(stale.status=="INVALIDATED_MODEL","stale prediction accepted");
    Trace observed=gate;observed.assurance="recorded_path";
    check(plan(observed,{192,352},{1,1},{2,1.4142f},{},op).status=="UNSUPPORTED_DEPENDENCY","recorded future treated as counterfactual");
    Options cap=op;cap.expansion_limit=10;
    check(plan(gate,{192,352},{1,1},{2,1.4142f},{},cap).status=="EXPANSION_LIMIT_NO_PLAN","cap ignored");
    cap=op;cap.budget_ms=0;
    check(plan(gate,{192,352},{1,1},{2,1.4142f},{},cap).status=="DEADLINE_NO_PLAN","deadline ignored");
    std::vector<Action> committed(3,{0,0});Plan cp=plan(gate,{192,352},{1,1},{2,1.4142f},committed,op);
    check(cp.status=="FIXTURE_MODEL_PATH"&&cp.actions[0].dx==0&&cp.actions[2].dx==0,"committed input rewritten");
    std::vector<std::vector<Hazard>> frames(96);
    for(int t=0;t<96;++t)for(int j=0;j<1536;++j){Hazard h;float x=std::fmod(float(j*37)+t*0.7f,448.0f)-32;float y=std::fmod(float(j*53)+t*1.1f,512.0f)-32;h.box={{x,y},{4,4}};frames[t].push_back(h);}
    std::vector<std::vector<V>> pts(96,std::vector<V>(256));for(auto&f:pts)for(auto&p:f)p={uni(8,376),uni(16,432)};
    std::vector<double> scan_ms,index_ms;uint64_t scan_count=0,index_count=0,checks0=0,checks1=0;
    for(int rep=0;rep<25;++rep){
        auto start=std::chrono::steady_clock::now();uint64_t c0=0;
        for(int t=0;t<96;++t)for(V p:pts[t]){for(auto&h:frames[t]){++checks0;if(hit(p,{0.825f,0.825f},h)){++c0;break;}}}
        auto mid=std::chrono::steady_clock::now();uint64_t c1=0;
        std::vector<Grid> grids;grids.reserve(96);for(const auto&f:frames)grids.emplace_back(f,V{0.825f,0.825f});
        for(int t=0;t<96;++t)for(V p:pts[t])if(grids[t].query(p,&checks1))++c1;
        auto end=std::chrono::steady_clock::now();check(c0==c1,"benchmark mismatch");scan_count=c0;index_count=c1;
        if(rep){scan_ms.push_back(std::chrono::duration<double,std::milli>(mid-start).count());index_ms.push_back(std::chrono::duration<double,std::milli>(end-mid).count());}
    }
    std::cout<<std::setprecision(9)<<"{\n\"grid_differential_queries\":"<<grid_queries<<",\"grid_disagreements\":"<<grid_disagreement
    <<",\"ring_queries\":"<<ring_queries<<",\"ring_false_negatives\":"<<ring_misses
    <<",\"contract_checks_passed\":true,\"gate_status\":\""<<gp.status<<"\",\"gate_planner_ms\":"<<gp.elapsed_ms
    <<",\"gate_expansions\":"<<gp.expansions<<",\"benchmark\":{\"kind\":\"synthetic_geometry_only\",\"repeats_after_warmup\":24,\"bullets\":1536,\"horizon\":96,\"queries_per_tick\":256,\"scan_ms_p50\":"<<pct(scan_ms,.5)
    <<",\"scan_ms_p95\":"<<pct(scan_ms,.95)<<",\"index_build_and_query_ms_p50\":"<<pct(index_ms,.5)<<",\"index_build_and_query_ms_p95\":"<<pct(index_ms,.95)
    <<",\"scan_ms_max\":"<<*std::max_element(scan_ms.begin(),scan_ms.end())<<",\"index_ms_max\":"<<*std::max_element(index_ms.begin(),index_ms.end())
    <<",\"collision_queries_hit\":"<<scan_count<<",\"collision_results_equal\":"<<(scan_count==index_count?"true":"false")<<"}}\n";
    return 0;
}catch(const std::exception&e){std::cerr<<"FAILED: "<<e.what()<<'\n';return 1;}}
