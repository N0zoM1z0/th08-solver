#pragma once
// Source-informed geometric predicates. Side effects, lifetime and collision gates
// are intentionally owned by the caller. Not an x87/original-exe equivalence claim.
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <limits>
#include <stdexcept>
#include <vector>
namespace th08plan {
struct V { float x=0, y=0; };
struct Box { V center, size; }; // FULL widths, not radii.
struct Laser { V position, size, origin; float angle=0; };
inline bool finite(V p) { return std::isfinite(p.x)&&std::isfinite(p.y); }
inline bool overlap_bounds(V amin,V amax,V bmin,V bmax) {
    return !(amin.x>bmax.x || amin.y>bmax.y || amax.x<bmin.x || amax.y<bmin.y);
}
inline bool bullet_hit(V p,V half,const Box& b) {
    const V pmin{p.x-half.x,p.y-half.y},pmax{p.x+half.x,p.y+half.y};
    const V bmin{b.center.x-b.size.x/2.0f,b.center.y-b.size.y/2.0f};
    const V bmax{b.size.x/2.0f+b.center.x,b.size.y/2.0f+b.center.y};
    return overlap_bounds(pmin,pmax,bmin,bmax);
}
inline V rotate(V p,float a) { const float s=std::sin(a),c=std::cos(a); return {c*p.x-s*p.y,c*p.y+s*p.x}; }
inline bool laser_hit(V p,V half,const Laser& l) {
    V q=rotate({p.x-l.origin.x,p.y-l.origin.y},-l.angle);
    q={q.x+l.origin.x,q.y+l.origin.y};
    // CalcLaserHitbox rotates ONLY the player center. The half-size is unchanged.
    return bullet_hit(q,half,{l.position,l.size});
}
struct Cancel { V center,size; float radius=0,angle=0; bool active=true; };
inline bool cancel_hit(V bullet_center,const Cancel& c) {
    if(!c.active) return false;
    float dx=bullet_center.x-c.center.x,dy=bullet_center.y-c.center.y;
    if(c.radius!=0.0f) return dx*dx+dy*dy<c.radius*c.radius; // STRICT circle boundary.
    if(c.angle!=0.0f) {
        V q=rotate({dx,dy},-c.angle);
        return -c.size.x/2.0f<=q.x && q.x<=c.size.x/2.0f && -c.size.y/2.0f<=q.y && q.y<=c.size.y/2.0f;
    }
    return bullet_hit(bullet_center,{0,0},{c.center,c.size});
}
struct Hazard {
    enum class Kind: uint8_t { Bullet, Laser } kind=Kind::Bullet;
    Box box{}; Laser laser{}; uint64_t entity=0; uint32_t generation=0;
    // One instance means the engine really performs this lethal test at this phase.
    // Spawning/disabled/invulnerable effects must be resolved BEFORE export.
};
inline bool hit(V p,V half,const Hazard& h) { return h.kind==Hazard::Kind::Bullet?bullet_hit(p,half,h.box):laser_hit(p,half,h.laser); }
struct Bounds { V lo,hi; };
inline Bounds expanded_bounds(const Hazard& h,V half) {
    // Broad-phase roundoff allowance grows with coordinate magnitude; NOT an
    // inflation of the source lethal predicate. Unknown/nonfinite state is rejected.
    float scale=1+std::abs(half.x)+std::abs(half.y);
    if(h.kind==Hazard::Kind::Bullet)scale+=std::abs(h.box.center.x)+std::abs(h.box.center.y)+h.box.size.x+h.box.size.y;
    else scale+=std::abs(h.laser.position.x)+std::abs(h.laser.position.y)+std::abs(h.laser.origin.x)+std::abs(h.laser.origin.y)+h.laser.size.x+h.laser.size.y;
    const float pad=0.002f+16*std::numeric_limits<float>::epsilon()*scale;
    if(h.kind==Hazard::Kind::Bullet) {
        V r{h.box.size.x/2+half.x+pad,h.box.size.y/2+half.y+pad};
        return {{h.box.center.x-r.x,h.box.center.y-r.y},{h.box.center.x+r.x,h.box.center.y+r.y}};
    }
    V r{h.laser.size.x/2+half.x+pad,h.laser.size.y/2+half.y+pad};
    V ctr=rotate({h.laser.position.x-h.laser.origin.x,h.laser.position.y-h.laser.origin.y},h.laser.angle);
    ctr={ctr.x+h.laser.origin.x,ctr.y+h.laser.origin.y};
    float s=std::abs(std::sin(h.laser.angle)),c=std::abs(std::cos(h.laser.angle));
    V a{c*r.x+s*r.y,s*r.x+c*r.y}; return {{ctr.x-a.x-pad,ctr.y-a.y-pad},{ctr.x+a.x+pad,ctr.y+a.y+pad}};
}
class Grid {
    static constexpr int W=24,H=28; // 16-unit cells, covers [0,384]x[0,448].
    std::vector<std::vector<uint32_t>> buckets{W*H};
    std::vector<uint32_t> large;
    const std::vector<Hazard>* objects=nullptr;
    V half{};
public:
    uint64_t build_references=0;
    explicit Grid(const std::vector<Hazard>& h,V ph): objects(&h),half(ph) {
        for(uint32_t i=0;i<h.size();++i) {
            const Hazard& obj=h[i];
            if(!finite(half)||half.x<0||half.y<0)throw std::invalid_argument("invalid player half-size");
            V c=obj.kind==Hazard::Kind::Bullet?obj.box.center:obj.laser.position;
            V size=obj.kind==Hazard::Kind::Bullet?obj.box.size:obj.laser.size;
            if(!finite(c)||!finite(size)||size.x<0||size.y<0)throw std::invalid_argument("invalid hazard geometry");
            if(obj.kind==Hazard::Kind::Laser&&(!finite(obj.laser.origin)||!std::isfinite(obj.laser.angle)))throw std::invalid_argument("invalid laser geometry");
            Bounds b=expanded_bounds(h[i],half);
            if(!finite(b.lo)||!finite(b.hi)||std::abs(b.lo.x)>1e7f||std::abs(b.lo.y)>1e7f||std::abs(b.hi.x)>1e7f||std::abs(b.hi.y)>1e7f){large.push_back(i);continue;}
            if(b.hi.x<0||b.hi.y<0||b.lo.x>384||b.lo.y>448) continue;
            int x0=std::clamp(int(std::floor(b.lo.x/16)),0,W-1),x1=std::clamp(int(std::floor(b.hi.x/16)),0,W-1);
            int y0=std::clamp(int(std::floor(b.lo.y/16)),0,H-1),y1=std::clamp(int(std::floor(b.hi.y/16)),0,H-1);
            // Avoid inserting large lasers/walls into hundreds of buckets.
            if((x1-x0+1)*(y1-y0+1)>64) { large.push_back(i); ++build_references; continue; }
            for(int y=y0;y<=y1;++y) for(int x=x0;x<=x1;++x) { buckets[y*W+x].push_back(i); ++build_references; }
        }
    }
    bool scan(V p,uint64_t* checks=nullptr) const {
        for(const auto& h:*objects) { if(checks) ++*checks; if(hit(p,half,h)) return true; } return false;
    }
    bool query(V p,uint64_t* checks=nullptr) const {
        if(p.x<0||p.x>384||p.y<0||p.y>448) return scan(p,checks);
        int x=std::min(W-1,int(p.x/16)),y=std::min(H-1,int(p.y/16));
        const auto& ids=buckets[y*W+x];
        // Dense, nonselective bucket: fall back to contiguous scan, not long indirection.
        if(ids.size()+large.size()>objects->size()*3/4) return scan(p,checks);
        for(auto i:large) { if(checks) ++*checks; if(hit(p,half,(*objects)[i])) return true; }
        for(auto i:ids) { if(checks) ++*checks; if(hit(p,half,(*objects)[i])) return true; }
        return false;
    }
};
// Broad-phase enumeration for a still-regular circle. 'error' MUST bound the
// difference between supplied actual positions and ideal positions. No bound=>scan.
inline std::vector<int> ring_candidates(V p,V center,float radius,float angle,int n,V combined_half,float error) {
    if(n<0 || n>1536 || !std::isfinite(error) || error<0) throw std::invalid_argument("invalid ring contract");
    std::vector<int> ids; if(n==0) return ids;
    double dx=double(p.x)-center.x,dy=double(p.y)-center.y,R=std::hypot(dx,dy);
    double rho=std::hypot(double(combined_half.x),double(combined_half.y))+error+0.003;
    if(std::abs(R-radius)>rho) return ids;
    if(radius<=0 || R<=0 || rho>=R+radius) { for(int j=0;j<n;++j) ids.push_back(j); return ids; }
    double q=(R*R+double(radius)*radius-rho*rho)/(2*R*radius);
    double a=std::acos(std::clamp(q,-1.0,1.0)),phi=std::atan2(dy,dx),tau=6.2831853071795864769;
    long lo=long(std::ceil((phi-a-angle)*n/tau))-1,hi=long(std::floor((phi+a-angle)*n/tau))+1;
    if(hi-lo+1>=n) { for(int j=0;j<n;++j) ids.push_back(j); return ids; }
    for(long j=lo;j<=hi;++j) ids.push_back(int((j%n+n)%n)); return ids;
}
}
