// CSV trace CLI. Format tick,kind,x,y,width,height,origin_x,origin_y,angle,id,generation
// kind is B or L. Ticks are indexed COLLISION-CHECK phases, not wall-clock milliseconds.
#include "planner.hpp"
#include <fstream>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <map>
using namespace th08plan;
int main(int argc,char**argv) {
 try {
    if(argc!=13) {std::cerr<<"usage: trace_plan trace.csv horizon start_x start_y half_x half_y axis diagonal goal_x goal_y assurance output.csv\n";return 2;}
    size_t horizon=std::stoul(argv[2]);
    if(horizon==0||horizon>4096)throw std::runtime_error("horizon out of range");
    Trace tr;tr.frames.resize(horizon);tr.assurance=argv[11];
    if(tr.frames.empty()||tr.frames.size()>4096)throw std::runtime_error("horizon out of range");
    std::ifstream in(argv[1]);if(!in)throw std::runtime_error("cannot open trace");std::string line;
    while(std::getline(in,line)) {
      if(line.empty()||line[0]=='#'||line.rfind("tick,",0)==0)continue;
      std::istringstream ss(line);std::vector<std::string> a;std::string v;while(std::getline(ss,v,','))a.push_back(v);
      if(a.size()!=11)throw std::runtime_error("expected 11 CSV columns");
      size_t t=std::stoul(a[0]);if(t>=tr.frames.size())throw std::runtime_error("trace tick outside horizon");
      Hazard h;float x=std::stof(a[2]),y=std::stof(a[3]),w=std::stof(a[4]),height=std::stof(a[5]);
      if(!finite({x,y})||!finite({w,height})||w<0||height<0)throw std::runtime_error("invalid geometry");
      if(a[1]=="B")h.box={{x,y},{w,height}};
      else if(a[1]=="L") {h.kind=Hazard::Kind::Laser;h.laser={{x,y},{w,height},{std::stof(a[6]),std::stof(a[7])},std::stof(a[8])};if(!finite(h.laser.origin)||!std::isfinite(h.laser.angle))throw std::runtime_error("invalid laser");}
      else throw std::runtime_error("unknown hazard kind");
      h.entity=std::stoull(a[9]);h.generation=std::stoul(a[10]);tr.frames[t].push_back(h);
    }
    V p{std::stof(argv[3]),std::stof(argv[4])},half{std::stof(argv[5]),std::stof(argv[6])};
    Speeds speeds{std::stof(argv[7]),std::stof(argv[8])};Options o;o.budget_ms=1000;o.expansion_limit=5000000;
    o.terminal={{std::stof(argv[9]),std::stof(argv[10])},{32,32}};o.require_terminal=true;
    Plan r=plan(tr,p,half,speeds,{},o);std::cout<<"{\"status\":\""<<r.status<<"\",\"elapsed_ms\":"<<r.elapsed_ms<<",\"expansions\":"<<r.expansions<<",\"checks\":"<<r.collision_checks<<"}\n";
    if(r.actions.empty())return 3;
    std::ofstream out(argv[12]);if(!out)throw std::runtime_error("cannot write result");out<<"tick,dx,dy,x,y\n"<<std::setprecision(9);
    for(size_t t=0;t<r.actions.size();++t)out<<t<<','<<r.actions[t].dx<<','<<r.actions[t].dy<<','<<r.points[t].x<<','<<r.points[t].y<<'\n';
    return 0;
 } catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 2;}
}
