#include "causal.hpp"
#include <iostream>
#include <iomanip>
#include <algorithm>
#include <map>
using namespace th08plan;
double pct(std::vector<double> v,double p){std::sort(v.begin(),v.end());return v[size_t(std::ceil(v.size()*p))-1];}
int main(){try{
 std::cout<<std::setprecision(8)<<"{\"scope\":\"synthetic candidate-dependent models; includes inner search cleanup, no game/input adapter\",\"seed_fixtures\":4,\"repeats_per_seed\":6,\"configurations\":[";int ci=0;
 for(int n:{32,300})for(unsigned cap:{0,8,2}){
  std::vector<double> times;std::map<std::string,int> counts;std::vector<std::vector<double>> perseed(4);
  for(int seed=0;seed<4;++seed)for(int rep=0;rep<6;++rep){
   Trace tr;tr.assurance="fixture";tr.frames.resize(96);AimedEvent a;a.tick=32;
   for(int j=0;j<n;++j)a.emitters.push_back({{float((j*37+seed*13)%384),float(16+(j*17+seed*7)%160)},{4,4},2.5f,0,0,1,false});
   Options o;o.budget_ms=8;o.beam=cap==2?16:32;o.require_terminal=true;o.terminal={{252,352},{24,24}};
   auto r=causal_plan(tr,{a},{192,352},{.825f,.825f},{2,1.414213538f},{},o,cap);
   times.push_back(r.elapsed_ms);perseed[seed].push_back(r.elapsed_ms);++counts[r.status];
   if(r.status!="FIXTURE_CAUSAL_MODEL_PATH"&&!r.actions.empty())throw std::runtime_error("failed plan retained actions");
  }
  std::cout<<(ci++?",":"")<<"{\"origins\":"<<n<<",\"event_samples\":"<<cap<<",\"beam\":"<<(cap==2?16:32)<<",\"budget_ms\":8,\"calls\":"<<times.size()<<",\"p50_ms\":"<<pct(times,.5)<<",\"p95_ms\":"<<pct(times,.95)<<",\"max_ms\":"<<*std::max_element(times.begin(),times.end())<<",\"statuses\":{";int k=0;for(auto&x:counts)std::cout<<(k++?",":"")<<'"'<<x.first<<"\":"<<x.second;
  std::cout<<"},\"samples_ms\":[";for(unsigned i=0;i<times.size();++i)std::cout<<(i?",":"")<<times[i];std::cout<<"]}";
 }
 std::cout<<"]}\n";return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
