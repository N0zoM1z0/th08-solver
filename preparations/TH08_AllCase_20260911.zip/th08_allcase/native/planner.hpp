#pragma once
#include "geometry.hpp"
#include <array>
#include <chrono>
#include <string>
#include <unordered_set>
namespace th08plan {
struct Speeds { float axis=2.0f,diag=1.414213538f; }; // Load the exact SHT selected by caller.
struct Action { int dx=0,dy=0; }; // Focus is FIXED for this trace model; no instantaneous youkai assumption.
inline V move(V p,Action a,Speeds s) {
    float v=(a.dx && a.dy)?s.diag:s.axis;
    return {std::clamp(p.x+float(a.dx)*v,8.0f,376.0f),std::clamp(p.y+float(a.dy)*v,16.0f,432.0f)};
}
struct Trace {
    std::vector<std::vector<Hazard>> frames;
    std::string assurance; // fixture | candidate_independent; recorded_path MUST NOT be replanned.
    uint64_t dependency_epoch=0;
    uint64_t branch=0;
};
struct Options {
    unsigned beam=96; uint64_t expansion_limit=200000; double budget_ms=8;
    float pruning_cell=1; // HEURISTIC pruning only; not a world-state equivalence proof.
    Box terminal{{192,352},{368,416}};
    bool require_terminal=false;
    uint64_t expected_epoch=0;
    bool indexed=true;
};
struct Plan {
    std::string status="NO_MODEL_PATH"; std::vector<V> points; std::vector<Action> actions;
    uint64_t expansions=0,collision_checks=0; unsigned reached_frames=0; double elapsed_ms=0;
};
struct Node { V p; int parent=-1; Action action; float score=0; };
inline Plan plan_inner(const Trace& tr,V start,V half,Speeds speeds,const std::vector<Action>& committed,const Options& op) {
    Plan out; auto t0=std::chrono::steady_clock::now();
    auto elapsed=[&](){return std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-t0).count();};
    auto finish=[&](std::string status){out.status=std::move(status);out.elapsed_ms=elapsed();
        if(out.status!="FIXTURE_MODEL_PATH"&&out.status!="CONDITIONAL_MODEL_PATH"){out.actions.clear();out.points.clear();}return out;};
    if(tr.assurance!="fixture"&&tr.assurance!="candidate_independent") return finish("UNSUPPORTED_DEPENDENCY");
    if(tr.dependency_epoch!=op.expected_epoch) return finish("INVALIDATED_MODEL");
    if(tr.frames.empty()||tr.frames.size()>4096||op.beam==0||op.beam>4096||op.pruning_cell<0.0001f || !std::isfinite(op.pruning_cell) || !finite(start) || !finite(half) || half.x<0 || half.y<0 || !std::isfinite(speeds.axis) || !std::isfinite(speeds.diag) || speeds.axis<=0 || speeds.diag<=0 || !finite(op.terminal.center) || !finite(op.terminal.size) || op.terminal.size.x<0 || op.terminal.size.y<0 || !std::isfinite(op.budget_ms) || op.budget_ms<0) return finish("INVALID_ARGUMENT");
    for(auto a:committed) if(a.dx< -1||a.dx>1||a.dy< -1||a.dy>1)return finish("INVALID_ARGUMENT");
    std::vector<Grid> grids; grids.reserve(tr.frames.size());
    for(const auto& f:tr.frames) { grids.emplace_back(f,half); if(elapsed()>op.budget_ms) return finish("DEADLINE_NO_PLAN"); }
    std::vector<std::vector<Node>> layers; layers.push_back({Node{start}});
    for(size_t t=0;t<tr.frames.size();++t) {
        std::vector<Node> next; next.reserve(layers.back().size()*9);
        for(int k=0;k<int(layers.back().size());++k) for(int dy=-1;dy<=1;++dy) for(int dx=-1;dx<=1;++dx) {
            if(t<committed.size() && (dx!=committed[t].dx||dy!=committed[t].dy)) continue;
            if(out.expansions>=op.expansion_limit) return finish("EXPANSION_LIMIT_NO_PLAN");
            if((out.expansions&63)==0 && elapsed()>op.budget_ms) return finish("DEADLINE_NO_PLAN");
            ++out.expansions; V p=move(layers.back()[k].p,{dx,dy},speeds);
            bool dead=op.indexed?grids[t].query(p,&out.collision_checks):grids[t].scan(p,&out.collision_checks);
            if(dead) continue;
            float ex=p.x-op.terminal.center.x,ey=p.y-op.terminal.center.y;
            // Goal-biased beam proposes routes; it is neither optimal nor complete.
            next.push_back({p,k,{dx,dy},ex*ex+ey*ey+0.03f*float(dx*dx+dy*dy)});
        }
        std::sort(next.begin(),next.end(),[](const Node&a,const Node&b){
            if(a.score!=b.score)return a.score<b.score;if(a.p.x!=b.p.x)return a.p.x<b.p.x;
            if(a.p.y!=b.p.y)return a.p.y<b.p.y;if(a.parent!=b.parent)return a.parent<b.parent;
            if(a.action.dx!=b.action.dx)return a.action.dx<b.action.dx;return a.action.dy<b.action.dy;
        });
        std::vector<Node> kept; std::unordered_set<uint64_t> seen;
        for(auto &n:next) {
            uint64_t qx=uint32_t(std::floor(n.p.x/op.pruning_cell)),qy=uint32_t(std::floor(n.p.y/op.pruning_cell));
            uint64_t key=(qx<<32)|qy;
            if(seen.insert(key).second) { kept.push_back(n);if(kept.size()>=op.beam)break; }
        }
        if(kept.empty()) return finish("SEARCH_EXHAUSTED_NOT_PROOF_OF_UNSAT");
        layers.push_back(std::move(kept)); out.reached_frames=unsigned(t+1);
    }
    int k=-1;
    for(int j=0;j<int(layers.back().size());++j) if(!op.require_terminal || bullet_hit(layers.back()[j].p,{0,0},op.terminal)) {k=j;break;}
    if(k<0) return finish("NO_TERMINAL_WITNESS");
    out.actions.resize(tr.frames.size());out.points.resize(tr.frames.size());
    for(size_t t=tr.frames.size();t>0;--t) { auto&n=layers[t][k];out.actions[t-1]=n.action;out.points[t-1]=n.p;k=n.parent; }
    // Replay selected path without spatial index/pruning: guards implementation errors.
    V p=start;
    for(size_t t=0;t<tr.frames.size();++t) {if(elapsed()>op.budget_ms)return finish("DEADLINE_NO_PLAN");p=move(p,out.actions[t],speeds);if(grids[t].scan(p))return finish("INTERNAL_RECHECK_FAILED");}
    if(elapsed()>op.budget_ms)return finish("DEADLINE_NO_PLAN");
    return finish(tr.assurance=="fixture"?"FIXTURE_MODEL_PATH":"CONDITIONAL_MODEL_PATH");
}
// Outer timer includes destruction of the inner search's grids/world layers.
// This is a polled budget, not an OS hard-real-time scheduling guarantee.
inline Plan plan(const Trace& tr,V start,V half,Speeds speeds,const std::vector<Action>& committed,const Options& op) {
    auto t=std::chrono::steady_clock::now();Plan r=plan_inner(tr,start,half,speeds,committed,op);
    r.elapsed_ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-t).count();
    if(r.elapsed_ms>op.budget_ms&&(r.status=="FIXTURE_MODEL_PATH"||r.status=="CONDITIONAL_MODEL_PATH")) {r.status="DEADLINE_NO_PLAN_AFTER_CLEANUP";r.actions.clear();r.points.clear();}
    return r;
}

}
