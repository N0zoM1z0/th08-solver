#include "mechanisms.hpp"
#include <iostream>
#include <vector>
#include <stdexcept>
using namespace th08plan;
void require(bool b,const char*s){if(!b)throw std::runtime_error(s);}
int main(){try{
 for(Barrier type:{Barrier::Narrow,Barrier::Medium,Barrier::Wide}){
  WarpBullet b{{192,200},{0,0},0,0,true};require(!warp(b,type),"stationary interior");
  b={{100,200},{100,0},0,0,true}; // A valid test trajectory crossing at least one zone.
  bool expected=zone(b.p,type,false)!=zone({b.p.x-b.v.x,b.p.y-b.v.y},type,true);require(warp(b,type)==expected,"zone event");
  if(expected){V p=b.p;require(!warp(b,type)&&b.cooldown==1&&b.p.x==p.x,"cooldown1");require(!warp(b,type)&&b.cooldown==0,"cooldown2");}
 }
 require(zone({-31.5f,200},Barrier::Wide,false)==1&&zone({-31.5f,200},Barrier::Wide,true)==2,"asymmetric wide boundary");
 PhaseBullet b;b.flags=0x100000;b.sprite=270;b.angle=.25f;b.speed=1.4f;
 reisen_three_state(b,0x100000,.3f,1);require(b.type==0&&b.disabled&&b.sprite==286,"phase140");
 reisen_three_state(b,0x100000,.3f,1);require(b.type==2&&b.disabled&&b.alphaInterpolation==15,"phase220");
 reisen_three_state(b,0x100000,.3f,1);require(b.type==1&&!b.disabled&&b.sprite==270,"phase240");
 reisen_two_state(b,0x100000,0,.5f,1);require(b.type==0&&b.disabled&&b.v.x==.5f,"EX12off");reisen_two_state(b,0x100000,0,.5f,1);require(b.type==1&&!b.disabled,"EX12on");
 std::vector<PhaseBullet> bs(1);bs[0].sprite=100;bs[0].v={3,6};float m=1;uint32_t flags=0;
 enter_scaled_time(bs,3,m);require(bs[0].v.x==1&&bs[0].v.y==2&&bs[0].sprite==111,"EX28");
 exit_scaled_time(bs,3,m,flags);require(bs[0].v.x==3&&bs[0].v.y==6&&bs[0].sprite==100&&m==1&&(flags&32),"EX29finaloverwrite");
 std::vector<unsigned> indegree(65536);for(unsigned s=0;s<65536;++s){Rng16 r{uint16_t(s),0};++indegree[r.next()];require(r.generations==1,"generation count");}
 for(auto n:indegree)require(n==1,"RNG transition not permutation");
 std::vector<bool> seen(65536);std::vector<unsigned> cycles;for(unsigned s=0;s<65536;++s)if(!seen[s]){Rng16 r{uint16_t(s),0};unsigned n=0;do{seen[r.seed]=true;r.next();++n;}while(!seen[r.seed]);cycles.push_back(n);}
 std::cout<<"{\"source_semantic_unit_tests\":\"passed\",\"warp_variants\":3,\"phase_variants\":2,\"time_scale_operations\":2,\"rng_states_examined\":65536,\"rng_cycle_lengths\":[";for(unsigned i=0;i<cycles.size();++i)std::cout<<(i?",":"")<<cycles[i];std::cout<<"],\"full_world\":false}\n";
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
