#!/usr/bin/env python3
"""Structural checks and conservative static census, never dynamic reachability."""
import json,struct,collections
from pathlib import Path
from analyze_ecl import read_ecl,SCHEMA,VARS
from analyze_anm import read_anm
ROOT=Path(__file__).resolve().parent.parent
MAIN=['ecldata1.ecl','ecldata2.ecl','ecldata3.ecl','ecldata4a.ecl','ecldata4b.ecl','ecldata5.ecl','ecldata6.ecl','ecldata7.ecl']
def main():
 es=[read_ecl(p) for p in sorted((ROOT/'private_resources').glob('*.ecl'))];checks=[];rows=[];edges=[];bad=[]
 for e in es:
  ins=[i for s in e['subs'] for i in s['instructions'] if i['opcode']!=-1];by={i['offset']:i for i in ins};jumps=0
  for s in e['subs']:
   bounds={i['offset'] for i in s['instructions']}
   for i in s['instructions']:
    op=i['opcode'];p=bytes.fromhex(i['payload'])
    if op in (4,5) or 40<=op<=51:
     target=i['offset']+struct.unpack_from('<i',p,12 if 40<=op<=51 else 4)[0];jumps+=1
     if target not in bounds:bad.append([e['file'],s['id'],i['offset'],target])
    # Only direct, known sub-id operand positions. No call-slot/remote inference.
    if op in (52,90,91,92,93,94):idx=0
    elif op in (133,):idx=2
    elif op in (134,135):idx=1
    else:continue
    val=struct.unpack_from('<i',p,idx*4)[0]
    if not(i['flags']&(1<<idx)) and 0<=val<e['sub_count']:
     edges.append(dict(file=e['file'],source=s['id'],target=val,op=op,pc=hex(i['offset']),mask=hex(i['mask'])))
  checks.append(dict(file=e['file'],sub_count=e['sub_count'],instructions=len(ins),sentinels=e['sub_count'],jump_sites_checked=jumps))
  if e['file'] not in MAIN:continue
  si=[i for i in ins if i['mask']&8]
  tr=collections.Counter(i['transform']['kind'] for i in si if'transform'in i)
  ex=collections.Counter(i['ex_id'] for i in si if'ex_id'in i)
  refs=collections.Counter();decoded=0
  for i in si:
   schema=SCHEMA.get(i['opcode']);p=bytes.fromhex(i['payload'])
   if schema is None or struct.calcsize('<'+schema)!=len(p):continue
   decoded+=1
   for idx,(typ,val) in enumerate(zip(schema,struct.unpack('<'+schema,p))):
    if i['flags']&(1<<idx) and int(val) in VARS:refs[VARS[int(val)]]+=1
  rows.append(dict(file=e['file'],sub_count=e['sub_count'],mask8_instructions=len(si),shoot_sites=sum(96<=i['opcode']<=104 for i in si),aimed_shoot_sites=sum(i['opcode'] in(96,98,100) for i in si),random_shoot_sites=sum(i['opcode'] in(102,103,104) for i in si),laser_create_sites=sum(i['opcode'] in(114,115) for i in si),ex_handler_ids=dict(ex),transform_kinds={hex(k):v for k,v in sorted(tr.items())},scalar_schema_sites_decoded=decoded,flagged_selector_occurrences=dict(refs)))
 assert not bad,bad
 a=read_anm(ROOT/'private_resources/etama.anm');bt=[]
 for typ,sid in enumerate(list(range(10))+[25]+list(range(106,116))):
  s=a['scripts'][sid];first=next(i for i in s['instructions'] if i['opcode']==3);spr=struct.unpack('<i',bytes.fromhex(first['payload']))[0];sp=a['sprites'][spr];h=sp['height'];size=24
  if h<=8:size=4
  elif h<=16:size=4 if sid in(2,111,112,4,6,5,106,107,108) else 6
  elif h<=32:size=5 if sid in(8,113,114,115) else(8 if sid in(9,109,110) else 10)
  init=next((struct.unpack('<i',bytes.fromhex(i['payload']))[0] for i in s['instructions'] if i['opcode']==25 and i['time']==0),None)
  bt.append(dict(type=typ,script_index=sid,script_offset=hex(s['offset']),sprite_index=spr,sprite_width=sp['width'],sprite_height=h,collision_full_width=size,initial_type_instruction=init))
 obj=dict(qualification='Mask inclusion only; all graph edges are syntactic direct references, not proof of runtime reachability. Selector census includes writes and excludes unknown schemas. No dynamic frequencies inferred.',structural_checks=checks,main_static_census=rows,direct_edges=edges,bullet_templates=bt)
 (ROOT/'reports/corpus_audit.json').write_text(json.dumps(obj,ensure_ascii=False,indent=2))
 print('all actual ECL instructions',sum(x['instructions'] for x in checks),'subroutines',sum(x['sub_count'] for x in checks),'jumps validated',sum(x['jump_sites_checked'] for x in checks))
 for x in rows:print({k:v for k,v in x.items() if k in('file','sub_count','mask8_instructions','shoot_sites','aimed_shoot_sites','random_shoot_sites','laser_create_sites')})
 print('bullet templates',bt)
if __name__=='__main__':main()
