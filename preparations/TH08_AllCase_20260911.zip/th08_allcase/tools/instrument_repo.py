#!/usr/bin/env python3
"""Generate instrumented source COPIES; never edits the supplied repository.
Compile the copies with --compile-build to verify against its real native flags.
Apply emitted trace.patch only in a disposable worktree for offline trace runs.
"""
import argparse, pathlib, hashlib, json, difflib, subprocess, shlex, os
ROOT=pathlib.Path(__file__).resolve().parent.parent
EXPECTED={'Player.cpp':'80c6829a41a30fcce47837edaa8da90bb11779130b5c443db842c7623745242c', 'Global.cpp':'328aba8255f04769fe0e0f401668abd8a258232de434ec2bb5e491d6e603f980', 'EclRun.cpp':'010049211263e47d8245c7335f56b17a8502ca0f84595c8b035926a495d90b57'}
def after_brace(src,signature,code):
    if src.count(signature)!=1:raise ValueError('ambiguous/missing signature: '+signature)
    k=src.index('{',src.index(signature))+1
    return src[:k]+'\n    '+code+'\n'+src[k:]
def transformed(name,src):
    src=src.replace('#include "th_pch.h"','#include "th_pch.h"\n#include "AllcaseTrace.hpp"',1) if '#include "th_pch.h"' in src else '#include "AllcaseTrace.hpp"\n'+src
    if name=='Global.cpp': return after_brace(src,'int Chain::RunCalcChain()', 'th08alltrace::begin();')
    if name=='EclRun.cpp':
        s='switch (instruction->opcode)'
        if src.count(s)!=1:raise ValueError('ECL switch ambiguity')
        return src.replace(s,'th08alltrace::ecl(enemy->activeEclContext->subId, enemy->activeEclContext->childContextSlot, (int)enemy->activeEclContext->time, instruction->opcode, instruction->difficultyMask, (unsigned long long)((uintptr_t)instruction - (uintptr_t)g_EclManager.eclFile));\n            '+s,1)
    src=after_brace(src,'ChainCallbackResult Player::OnUpdate(Player *player)', 'th08alltrace::input(g_GuiMessageInputCurrent, player->position.x, player->position.y, player->playerState, g_GameManager.scriptedUpdateFreeze);')
    for name,kind in [('CheckBulletCollision','bullet'),('CheckLethalCollision','enemy'),('CheckGrazeCollision','graze')]:
        src=after_brace(src,'i32 Player::'+name+'(',f'th08alltrace::geometry("{kind}", this->position.x, this->position.y, this->hurtboxHalfSize.x, this->hurtboxHalfSize.y, position->x, position->y, size->x, size->y, 0, 0, 0, this->playerState, 0);')
    src=after_brace(src,'u32 Player::CalcLaserHitbox(', 'th08alltrace::geometry("laser", this->position.x, this->position.y, this->hurtboxHalfSize.x, this->hurtboxHalfSize.y, position->x, position->y, size->x, size->y, origin->x, origin->y, angle, this->playerState, graze);')
    return src

def run(repo,out,compile_build=None):
    repo=repo.resolve();out=out.resolve();out.mkdir(parents=True,exist_ok=True);(out/'src').mkdir(exist_ok=True)
    diff=[]; hashes={}; sources=[]
    for name,expected in EXPECTED.items():
        path=repo/'src'/name;raw=path.read_bytes();h=hashlib.sha256(raw).hexdigest()
        if h!=expected:raise ValueError(f'{path}: source hash changed; review hook locations before porting')
        src=raw.decode().replace('\r\n','\n');new=transformed(name,src)
        (out/'src'/name).write_text(new,encoding='utf8');sources.append(name);hashes[name]=h
        diff.extend(difflib.unified_diff(src.splitlines(True),new.splitlines(True),fromfile='a/src/'+name,tofile='b/src/'+name))
    header=(ROOT/'integration/AllcaseTrace.hpp').read_text()
    (out/'src/AllcaseTrace.hpp').write_text(header)
    diff.extend(difflib.unified_diff([],header.splitlines(True),fromfile='/dev/null',tofile='b/src/AllcaseTrace.hpp'))
    (out/'trace.patch').write_text(''.join(diff))
    result={'source_hashes':hashes,'modified_repository':False,'runtime_executed':False,'compiled':[]}
    if compile_build:
        b=pathlib.Path(compile_build).resolve()
        text=subprocess.check_output(['ninja','-C',str(b),'-t','commands'],text=True)
        for name in sources:
            line=next(x for x in text.splitlines() if ' -c ' in x and '/src/'+name in x)
            cmd=shlex.split(line);clean=[];k=0
            while k<len(cmd):
                if cmd[k] in ('-o','-MF','-MT','-MQ'): k+=2;continue
                if cmd[k] in ('-MD','-MMD','-MP'): k+=1;continue
                if cmd[k]=='-c':clean+=['-c',str(out/'src'/name)];k+=2;continue
                clean.append(cmd[k]);k+=1
            clean+=['-o',str(out/(name+'.o'))]
            proc=subprocess.run(clean,cwd=b,capture_output=True,text=True)
            (out/(name+'.compile.log')).write_text(proc.stdout+proc.stderr)
            result['compiled'].append({'source':name,'exit_code':proc.returncode})
            if proc.returncode:raise RuntimeError(name+' compile failed; inspect log')
    (out/'instrumentation_result.json').write_text(json.dumps(result,indent=2));return result
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--repo',type=pathlib.Path,required=True);a.add_argument('--out',type=pathlib.Path,required=True);a.add_argument('--compile-build',type=pathlib.Path);x=a.parse_args();print(json.dumps(run(x.repo,x.out,x.compile_build),indent=2))
