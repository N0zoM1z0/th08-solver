#!/usr/bin/env python3
"""Decode TH08 stage timeline bytecode. Script time is NOT wall-clock time."""
from pathlib import Path
import struct,json,collections
from analyze_ecl import read_ecl
ROOT=Path(__file__).resolve().parent.parent
NAMES=['SPAWN','SPAWN_MIRROR','SPAWN_RANDOM_X_RANGE','SPAWN_RANDOM_PLAYFIELD_X','SPAWN_RANDOM_X_RANGE_MIRROR','SPAWN_RANDOM_PLAYFIELD_X_MIRROR','MESSAGE','WAIT_MESSAGE','BOSS_SUB','POWER','WAIT_BOSS','SPAWN_DROPS','SPAWN_DROPS_MIRROR','WAIT_EVENT','PUBLISH_EVENT','SPAWN_UNCONDITIONAL','RETRY']
SC={0:'iffiii',1:'iffiii',2:'ifffiii',3:'ifiii',4:'ifffiii',5:'ifiii',6:'i',7:'',8:'ii',9:'i',10:'i',11:'iffiiii',12:'iffiiii',13:'i',14:'i',15:'iffiii',16:''}
def main():
 out=[]; (ROOT/'reports/all_masks_timeline').mkdir(exist_ok=True)
 for p in sorted((ROOT/'private_resources').glob('*.ecl')):
  b=p.read_bytes();e=read_ecl(p);timelines=[];lines=[]
  for tid,start in enumerate(e['timeline_offsets']):
   pos=start;inst=[]
   while True:
    t,op,size,mask=struct.unpack_from('<ihBB',b,pos)
    if t<0:break
    assert 0<=op<=16 and size>=8 and pos+size<=len(b),(p,tid,pos,t,op,size)
    payload=b[pos+8:pos+size];schema=SC.get(op)
    if schema is not None and struct.calcsize('<'+schema)==len(payload):vals=struct.unpack('<'+schema,payload)
    else:vals=['hex:'+payload.hex()]
    row=dict(pc=hex(pos),time=t,opcode=op,name=NAMES[op],mask=hex(mask),args=vals);inst.append(row)
    lines.append(f'timeline{tid} {pos:#x} t={t} mask={mask:#x} {NAMES[op]} {vals}')
    pos+=size
   timelines.append(dict(id=tid,start=hex(start),end=hex(pos),instructions=inst))
  o=dict(file=p.name,timelines=timelines);out.append(o);(ROOT/'reports/all_masks_timeline'/(p.stem+'.timeline.txt')).write_text('\n'.join(lines)+'\n')
 (ROOT/'reports/timeline_parsed.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
 for e in out:
  if e['file'].endswith('sp.ecl') or '_' in e['file']:continue
  ins=[i for t in e['timelines'] for i in t['instructions'] if int(i['mask'],16)&8]
  print(e['file'],'timelines',len(e['timelines']),'mask8 rows',len(ins),'gates',collections.Counter(i['name'] for i in ins if i['opcode'] in(7,10,13)))
if __name__=='__main__':main()
