#!/usr/bin/env python3
"""All-resource structural atlas. Conservative syntactic slices, NOT a game solver.
Recomputes from the supplied DAT extraction. Every entry carries provenance,
raw masks, explicit unresolved edges and a distinct semantic-validation status.
"""
from pathlib import Path
import collections as C,struct,json,hashlib,html,math,csv
from analyze_ecl import read_ecl,SCHEMA as OLD_SCHEMA,VARS,OPS,EX,operands
ROOT=Path(__file__).resolve().parent.parent
SCHEMA=dict(OLD_SCHEMA)
# Verified against a45e99f EclRunLow/High and InstallInterpolationSlot.
SCHEMA.update({0:'',36:'fiiiffff',72:'iffffff',87:'ffi',88:'ii',89:'ii',95:'',176:'i',182:'i'})
TRANSFORMS={0x10:'vector_acceleration',0x20:'polar_acceleration',0x40:'relative_direction_change',0x80:'aimed_direction_change',0x100:'absolute_direction_change',0x400:'bounce_all_edges',0x800:'bounce_except_bottom',0x2000:'set_cull_delay',0x4000:'set_sprite',0x20000:'wait',0x40000:'despawn',0x80000:'play_sound',0x400000:'wrap_x',0x800000:'wrap_y',0x1000000:'spawn_child_pattern_primary',0x2000000:'child_pattern_secondary_record_not_standalone_opcode'}
METHODS={
'shared':'共享已确定弹丸的逐帧演化；使用批次或空间索引，精确窄阶段复核',
'aim':'在实际玩家取样时刻条件化发射方向，不能缓存为与路线无关的未来',
'reaim':'按弹丸的真实再瞄准更新时间分桶；前缀共享、事件后按候选计算',
'feedback':'保留玩家读取影响的连续状态；仅在证明依赖压缩后提取低维递推',
'form':'保留实际人/妖状态、过渡计数及使魔存活，不用Shift键值替代实际形态',
'rng':'保留共享RNG及取数次序；动作改变抑制/生成/动画消费时使相关预测失效',
'warp':'离散映射前后分别构建危险位置；不能以连线或当前距离裁剪映射后的弹',
'phase_gate':'按碰撞开启/关闭状态机规划恢复时的出口，不以透明度替代判定',
'laser':'使用原版旋转玩家中心判定；同时覆盖激光池和EX直接调用',
'pool':'保留槽位分配、生成顺序、继承上下文、出生立即执行及生命周期',
'world':'使用带RNG/控制器/时间尺度的参考状态；只在预算内展开相关子世界',
'clock':'分开全局更新、ECL主/子/栈局部时间、ZunTimer、倍率、冻结与输入消费阶段',
'remote':'保留远端Boss/链表对象的身份和状态；对象相同坐标不等于同一未来',
'phase_transition':'把死亡/生命/计时回调作为真实阶段边，不把击破时刻作为自由输入',
}
EX_ROLES={0:['visual'],1:['visual'],2:['shared'],3:['warp'],4:['warp'],5:['warp'],6:['warp'],7:['warp'],8:['pool','remote'],9:['laser'],10:['visual'],11:['laser'],12:['phase_gate','pool','clock'],13:['visual'],14:['phase_gate'],15:['visual'],16:['pool','remote'],17:['visual'],18:['clock'],19:['world'],20:['warp'],21:['warp'],22:['visual'],23:['visual'],24:['world'],25:['laser'],26:['clock','world'],27:['pool','world'],28:['clock','world'],29:['clock','world'],30:['visual'],31:['pool','rng']}
MAIN={'ecldata1.ecl','ecldata2.ecl','ecldata3.ecl','ecldata4a.ecl','ecldata4b.ecl','ecldata5.ecl','ecldata6.ecl','ecldata7.ecl'}

def group(file):
 return '本篇' if file in MAIN else 'Extra' if file=='ecldata8.ecl' else '练习/含Last Word' if file.endswith('sp.ecl') else '独立Last Word'
def decode(i):
 p=bytes.fromhex(i['payload']);op=i['opcode']
 if op in(-1,122):return [],None
 if op==3 and len(p) in(0,4):return list(struct.unpack('<i',p)) if p else [],None
 sc=SCHEMA.get(op)
 if sc is None or struct.calcsize('<'+sc)!=len(p):return [],'unknown_payload_schema'
 vals=list(struct.unpack('<'+sc,p));return list(zip(sc,vals)),None

def operands_info(i):
 vals,err=decode(i)
 if i['opcode']==3:return [],err
 out=[];op=i['opcode'];flags=i['flags']
 write0=op in(6,7,8,9,30,31,32,33,34,35,36,37,39,86,87) or 10<=op<=29
 for n,(typ,v) in enumerate(vals):
  flag=bool(flags&(1<<n));key=int(v) if isinstance(v,(int,float)) and math.isfinite(v) else None
  # START_SPELL and packed fields use special handlers; raw values preserved.
  role='read'
  if write0 and n==0:role='read_write' if op in tuple(range(10,20))+(30,31,37) else 'write'
  if op==5 and n==2:role='read_write'
  if op in (38,166) and n<2:role='write'
  if op in (4,5) and n<2:role='raw_control'
  if 40<=op<=51 and n>=2:role='raw_control'
  if op in (52,) and n==0:role='raw_control'
  if op==88 and n==1:role='raw_control'
  if op==130:role='raw_control'
  if op==176:role='unused_payload'
  if op in(136,137) and n==0:role='raw_control'
  out.append({'index':n,'type':typ,'value':v,'flagged':flag,'selector':VARS.get(key) if flag else None,'role':role})
 return out,err

def direct_info(i):
 op=i['opcode'];oi,err=operands_info(i);dep=set();roles=set();writes=set();sel=[]
 for a in oi:
  if a['selector']:
   sel.append(a)
   if a['role'] in('write','read_write'):writes.add(a['selector'])
   if a['role'] not in('read','read_write'):continue
   n=a['selector']
   if n in('PLAYER_X','PLAYER_Y','PLAYER_Z','ANGLE_TO_PLAYER','DISTANCE_TO_PLAYER'):dep.add('player_position')
   elif n=='PLAYER_IS_YOUKAI':dep.add('player_form')
   elif n.startswith('RAND_'):dep.add('rng')
   elif n in('RANK','TIME_ORB_STATE','SCORE'):dep.add('rank_score_gauge')
   elif n in('LIFE','LAST_DAMAGE','SPELL_CAPTURE_STATE','SPELL_TIMER_FRAMES'):dep.add('combat')
   elif n.startswith(('CALL_','SHARED_CALL_','EXTRA_','EI','EF')):dep.add('caller_or_inherited_state')
   elif n not in {**{f'I{k}':0 for k in range(8)},**{f'F{k}':0 for k in range(8)}}:dep.add('controller_state')
 if 96<=op<=104:
  roles.add('shared')
  if op in(96,98,100):roles.add('aim');dep.add('player_position')
  if op in(102,103,104):dep.add('rng')
  # Shot min-distance, rank, pool and deferred dispatch are implicit dependencies.
  dep.update(('shot_gate','rank','bullet_pool','deferred_dispatch'))
 if op in(68,69,118,115):dep.add('player_position');roles.add('aim')
 if op in(67,169,178,8,9):dep.add('rng')
 if op in(114,115,116,117,118,119,120,121,154,167,170,171,172):roles.add('laser')
 if 90<=op<=95:roles.add('pool')
 if op in(86,87,88,89):roles.add('remote');dep.add('remote_entity')
 if op in(130,133,134):roles.add('phase_transition');dep.add('combat')
 if op in(122,123,131,132,153,155,157,159,160,177,183,184):dep.add('combat')
 if op in(173,175,176,179,180,181):roles.add('clock')
 if op in(54,55,56,57,58,59,60,61,62,128,138,139,140,145,147,149,150,165,174,182):dep.add('anm_or_effect')
 if 'transform' in i:
  kind=i['transform']['kind']
  if kind==128:roles.add('reaim');dep.add('future_player_position')
  if kind in(0x1000000,0x2000000):roles.add('pool');dep.add('child_pattern')
  if kind in(0x400000,0x800000):roles.add('warp')
 if 'ex_id' in i and i['ex_id']>=0:
  roles.update(EX_ROLES.get(i['ex_id'],['unknown_ex']))
  dep.add('ex_callback')
 if i['mask']&0x60 in(0x20,0x40):roles.add('form');dep.add('player_form')
 if 'player_position'in dep:roles.add('feedback')
 if 'rng'in dep:roles.add('rng')
 if 'combat'in dep:roles.add('phase_transition')
 if err:roles.add('unknown_schema')
 return dep,roles,writes,sel,err

def edges_for(i,sid,n):
 op=i['opcode'];p=bytes.fromhex(i['payload']);spec={52:(0,'call'),88:(1,'remote_call'),90:(0,'familiar'),91:(0,'familiar'),92:(0,'familiar'),93:(0,'spawn'),94:(0,'spawn'),130:(0,'death_callback'),133:(2,'life_callback'),134:(1,'timer_callback'),135:(1,'child_ecl'),126:(0,'slot_assignment')}
 if op not in spec:return []
 ix,kind=spec[op]
 if len(p)<(ix+1)*4:return [{'source':sid,'target':None,'kind':kind,'pc':hex(i['offset']),'reason':'short_payload','mask':i['mask']}]
 target=struct.unpack_from('<i',p,ix*4)[0]
 raw=op in(52,88,130)
 if not raw and i['flags']&(1<<ix):target=None;reason='computed_target'
 elif target<0:return []
 elif target>=n:reason='out_of_sub_range';target=None
 else:reason=None
 return [{'source':sid,'target':target,'kind':kind,'pc':hex(i['offset']),'mask':i['mask'],'reason':reason}]

def closure(root,edges,bit,include_transitions=False):
 by=C.defaultdict(list)
 for e in edges:
  if bit and e['mask']&bit!=bit:continue
  if not include_transitions and e['kind'] in('death_callback','life_callback','timer_callback'):continue
  if e['kind']=='slot_assignment':continue # not a call by itself
  by[e['source']].append(e)
 seen=set();stack=[root];unresolved=[]
 while stack:
  x=stack.pop()
  if x in seen:continue
  seen.add(x)
  for e in by[x]:
   if e['target'] is None:unresolved.append(e)
   else:stack.append(e['target'])
 return sorted(seen),unresolved

def run():
 report=ROOT/'reports';report.mkdir(exist_ok=True)
 es=[read_ecl(p) for p in sorted((ROOT/'private_resources').glob('*.ecl'))]
 subs=[];spells=[];all_edges=[];op_hist=C.Counter();exsites=C.defaultdict(list);transites=C.defaultdict(list);schema_errors=[];jumps=0;calls_bad=[]
 for e in es:
  edges=[x for s in e['subs'] for i in s['instructions'] for x in edges_for(i,s['id'],len(e['subs']))]
  # EX27 obtains its sub target from active EXTRA_I2. Do not omit this edge.
  jump_targets=set()
  for sub in e['subs']:
   for ins in sub['instructions']:
    if ins['opcode'] in (4,5) or 40<=ins['opcode']<=51:
     jump_targets.add(ins['offset']+struct.unpack_from('<i',bytes.fromhex(ins['payload']),12 if 40<=ins['opcode']<=51 else 4)[0])
  for sub in e['subs']:
   for k,ins in enumerate(sub['instructions']):
    if ins.get('ex_id')!=27:continue
    target=None;why='computed_EXTRA_I2_target'
    if k and ins['offset'] not in jump_targets:
     prev=sub['instructions'][k-1]
     if prev['opcode']==6 and len(bytes.fromhex(prev['payload']))==8:
      dest,value=struct.unpack('<ii',bytes.fromhex(prev['payload']))
      if dest==10038 and prev['flags']&1 and not prev['flags']&2 and 0<=value<len(e['subs']) and prev['time']==ins['time'] and prev['mask']==ins['mask']:
       target=value;why='immediate_literal_EXTRA_I2_assignment_no_jump_to_use'
    edges.append({'source':sub['id'],'target':target,'kind':'ex27_marked_bullet_spawn','pc':hex(ins['offset']),'mask':ins['mask'],'reason':why})
  all_edges.extend(dict(file=e['file'],**x) for x in edges)
  for s in e['subs']:
   ids={i['offset'] for i in s['instructions']};dep=set();roles=set();writes=set();selectors=[];back=[];sop=C.Counter();terms=[]
   for i in s['instructions']:
    if i['opcode']==-1:continue
    op_hist[i['opcode']]+=1;sop[i['opcode']]+=1
    d,r,w,se,err=direct_info(i);dep|=d;roles|=r;writes|=w
    selectors.extend({'pc':hex(i['offset']),'op':i['opcode'],**a} for a in se)
    if err:schema_errors.append({'file':e['file'],'sub':s['id'],'pc':hex(i['offset']),'op':i['opcode'],'payload':i['payload']})
    if i['opcode'] in(4,5) or 40<=i['opcode']<=51:
     offset=12 if 40<=i['opcode']<=51 else 4
     target=i['offset']+struct.unpack_from('<i',bytes.fromhex(i['payload']),offset)[0]
     if target not in ids:raise ValueError(('bad jump',e['file'],s['id'],i['offset'],target))
     jumps+=1
     if target<=i['offset']:back.append({'pc':hex(i['offset']),'target':hex(target),'mask':hex(i['mask'])})
    if 'ex_id'in i:exsites[i['ex_id']].append({'file':e['file'],'sub':s['id'],'pc':hex(i['offset']),'local_time':i['time'],'mask':hex(i['mask']),'op':i['opcode'],'payload':i['payload']})
    if 'transform'in i:transites[i['transform']['kind']].append({'file':e['file'],'sub':s['id'],'pc':hex(i['offset']),'mask':hex(i['mask']),**i['transform']})
   subs.append({'file':e['file'],'group':group(e['file']),'sub':s['id'],'start':hex(s['offset']),'end':hex(s['end']),'instruction_count':sum(sop.values()),'direct_dependencies':sorted(dep),'mechanism_tags':sorted(roles),'writes':sorted(writes),'selector_sites':selectors,'back_edges':back,'opcodes':dict(sorted(sop.items())),'outgoing_edges':[x for x in edges if x['source']==s['id']],'equivalence_status':'NOT_PROVED','runtime_status':'NOT_FULL_ENGINE_EXECUTED'})
   for spell in [i for i in s['instructions'] if 'spell'in i]:
    mask=spell['mask'];bits=[b for b in(1,2,4,8,15) if mask&b==b]
    # Mask 0xff is NOT proof that this spell is reachable on every difficulty.
    slices=[]
    for bit in bits:
     reach,unknown=closure(s['id'],edges,bit)
     instr=[i for t in reach for i in e['subs'][t]['instructions'] if i['opcode']!=-1 and i['mask']&bit==bit]
     ds=set();rs=set();exs=set();trs=set()
     for i in instr:
      d,r,_,_,_=direct_info(i);ds|=d;rs|=r
      if i.get('ex_id',-1)>=0:exs.add(i['ex_id'])
      if 'transform'in i:trs.add(i['transform']['kind'])
     slices.append({'difficulty_mask':bit,'difficulty_label':{1:'Easy',2:'Normal',4:'Hard',8:'Lunatic',15:'Extra'}[bit],'sub_ids':reach,'instruction_sites':len(instr),'dependencies':sorted(ds),'mechanism_tags':sorted(rs),'ex_ids':sorted(exs),'transform_kinds':[hex(x) for x in sorted(trs)],'shoot_sites':sum(96<=i['opcode']<=104 for i in instr),'unresolved_edges':unknown})
    full,_=closure(s['id'],edges,0,True)
    combined=set(t for sl in slices for t in sl['mechanism_tags'])
    spells.append({'file':e['file'],'group':group(e['file']),'sub':s['id'],'pc':hex(spell['offset']),'mask':hex(mask),'local_time':spell['time'],**spell['spell'],'difficulty_slices':slices,'full_syntactic_closure':full,'proposed_methods':[METHODS[t] for t in sorted(combined) if t in METHODS],'proven_route':False,'qualification':'Syntactic call/spawn closure. Callback successor phases excluded from local slices, retained separately. Existing entities, dynamic targets and entry gates need runtime trace.'})
 contracts=[]
 for op in range(185):
  n=OPS.get(op,'UNKNOWN');roles=[]
  if op<=53:category='scalar_control_or_interpolation'
  elif op<=62:category='animation_binding'
  elif op<=83:category='movement_and_interaction'
  elif op<=95:category='remote_entities_and_spawning'
  elif op<=121:category='bullet_and_laser'
  else:category='lifecycle_callbacks_and_world'
  contracts.append({'opcode':op,'name':n,'observed_sites':op_hist[op],'schema':SCHEMA.get(op),'category':category,'source_handler_named':True,'full_runtime_implemented_in_this_package':False,'note':'Payload layout is not a proof of complete semantics. Original reconstructed engine remains the reference.'})
 unique=sorted(set(s['id'] for s in spells));assert unique==list(range(222))
 cov={'dat_sha256':hashlib.sha256(next((ROOT/'private_resources').glob('ecldata1.ecl')).read_bytes()).hexdigest(),'qualification':'The field dat_sha256 is supplied below from the archive manifest, not an ECL hash.','source_commit':'a45e99fb1942714e6edded20847e32a654d56f97','resource_files':len(list((ROOT/'private_resources').iterdir())),'ecl_files':len(es),'subprograms':len(subs),'nonterminal_instructions':sum(op_hist.values()),'jump_targets_checked':jumps,'spell_sites':len(spells),'unique_spell_ids':len(unique),'missing_spell_ids':[],'observed_primary_opcodes':sum(op_hist[k]>0 for k in range(1,185)),'default_opcode0_sites':op_hist[0],'observed_ex_ids':len(set(exsites)-{-1}),'schema_errors':schema_errors,'full_spell_solutions_verified':0,'static_coverage_is_not_dynamic_coverage':True}
 cov['dat_sha256']=json.loads((report/'archive_manifest.json').read_text())['archive']['sha256'];cov.pop('qualification')
 def save(n,x): (report/n).write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf8')
 save('allcase_coverage.json',cov);save('opcode_contracts.json',contracts);save('subprogram_atlas.json',subs);save('spell_atlas.json',spells);save('callgraph.json',all_edges)
 save('ex_registry.json',[{'id':k,'name':EX[k],'roles':EX_ROLES[k],'sites':exsites[k],'runtime_complete':False} for k in range(32)])
 save('transform_registry.json',[{'kind':hex(k),'name':TRANSFORMS.get(k,'unknown'),'sites':v,'configured_not_necessarily_enabled':True} for k,v in sorted(transites.items())])
 # All-mask disassembly, not the previous mask8-only dumps.
 dis=report/'all_masks_disassembly';dis.mkdir(exist_ok=True)
 import analyze_ecl
 analyze_ecl.SCHEMA.update(SCHEMA)
 for e in es:
  lines=[e['file']+' '+e['sha256']+'\nAll masks; local ECL time; zero-based sub IDs.']
  for s in e['subs']:
   lines.append(f"\n=== sub{s['id']} @{s['offset']:#x} ===")
   for i in s['instructions']:
    lines.append(f"{i['offset']:#07x} t={i['time']:6} mask={i['mask']:02x} flags={i['flags']:04x} {i['op']}({operands(i)})")
  (dis/(e['file']+'.txt')).write_text('\n'.join(lines),encoding='utf8')
 # 222 ID entries with all original occurrences and no silently merged variants.
 lines=['# 全部222个原始符卡ID：源程序与求解模型索引','', '下表是可复核的结构化方案，不是已成功路线。编号保留原始ID；名称逐字保留DAT，包括原数据的拼写/标点。mask=0xff不证明所有难度入口可达。','']
 rows=[]
 for id in unique:
  occ=[s for s in spells if s['id']==id];tags=sorted(set(t for s in occ for sl in s['difficulty_slices'] for t in sl['mechanism_tags']))
  source='; '.join(f"{s['file']}:sub{s['sub']}@{s['pc']}({s['mask']})" for s in occ)
  exs=sorted(set(k for s in occ for sl in s['difficulty_slices'] for k in sl['ex_ids']))
  rows.append({'id':id,'name':occ[0]['name'],'owner':occ[0]['owner'],'sources':source,'tags':', '.join(tags),'ex_ids':','.join(map(str,exs)),'verified_route':'NO'})
  lines += [f"## ID {id:03d} · {occ[0]['name']}",f"人物：{occ[0]['owner']}。记录数：{len(occ)}。",f"来源：`{source}`。",f"机制标签：{', '.join(tags)}。EX：{exs or '无直接/静态传播站点'}。"]
  lines += [METHODS[t]+'。' for t in tags if t in METHODS]
  lines += ['验收：多入口/形态/种子下事件级对照 → 同预算对照 → 原版合法输入连续验证。当前状态：结构分析已覆盖，完整成功路线未验证。','']
 (ROOT/'docs/ALL_222_SPELLS.md').write_text('\n\n'.join(lines),encoding='utf8')
 with (report/'spell_index.csv').open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 data=json.dumps(rows,ensure_ascii=False).replace('</','<\\/')
 page='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>TH08 全符卡结构索引</title><style>body{font:16px/1.65 system-ui,sans-serif;max-width:1250px;margin:32px auto;padding:0 20px}h1{line-height:1.2}input{font:inherit;width:90%;padding:12px}article{border-top:1px solid #bbb;padding:18px 0}small{overflow-wrap:anywhere}code{white-space:normal} .status{font-weight:bold} </style><h1>TH08 · 全部222个原始符卡ID</h1><p>基于给定DAT与固定源码提交的结构索引。保留431个来源记录。不是222条已验证解法。</p><input id="q" placeholder="搜索名称、ID、sub、EX或机制标签"><p id="count"></p><main id="items"></main><script>const data=DATA;function draw(){let q=document.getElementById('q').value.toLowerCase();let rs=data.filter(x=>JSON.stringify(x).toLowerCase().includes(q));document.getElementById('count').textContent=rs.length+' / 222';let p=document.getElementById('items');p.replaceChildren();for(let r of rs){let a=document.createElement('article');let h=document.createElement('h2');h.textContent=String(r.id).padStart(3,'0')+' · '+r.name;a.append(h);for(let [label,key] of [['来源','sources'],['机制','tags'],['EX','ex_ids'],['已验证路线','verified_route']]){let t=document.createElement('p');t.textContent=label+'：'+r[key];a.append(t)}p.append(a)}}document.getElementById('q').oninput=draw;draw();</script></html>'''.replace('DATA',data)
 (ROOT/'ALL_222_SPELLS.html').write_text(page,encoding='utf8')
 print(json.dumps(cov,ensure_ascii=False,indent=2))
if __name__=='__main__':run()
