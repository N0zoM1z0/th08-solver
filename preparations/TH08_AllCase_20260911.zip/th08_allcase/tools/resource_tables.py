#!/usr/bin/env python3
"""Parse all ANM scripts, all SHT descriptors and all STD objects/instructions.
This records geometry/resources, not render-equivalence or damage simulation.
"""
from pathlib import Path
import struct,json,collections as C,hashlib
from analyze_anm import read_anm
ROOT=Path(__file__).resolve().parent.parent

def sht(path):
 b=path.read_bytes();levels=struct.unpack_from('<H',b,2)[0]
 row={'file':path.name,'sha256':hashlib.sha256(b).hexdigest(),'header':{},'power_levels':[]}
 keys=['initialBombCount','deathbombWindowFrames','hurtboxSize','grazeBoxSize','itemAutoCollectSpeed','itemCollectionBoxSize','pointItemValueLine','reserved20','normalAxisSpeed','focusedAxisSpeed','normalDiagonalSpeed','focusedDiagonalSpeed','itemMovementSpeed']
 for off,key in zip(range(4,56,4),keys):row['header'][key]=struct.unpack_from('<i' if off in(8,32) else '<f',b,off)[0]
 names=['fireInterval','fireFrame','offsetX','offsetY','hitboxX','hitboxY','angle','speed','damage','extremeGaugeBehavior','sourceOptionIndex','shotType','animationIndex','soundIndex','spawnCallbackIndex','updateCallbackIndex','drawCallbackIndex','collisionCallbackIndex']
 for k in range(levels):
  off,power=struct.unpack_from('<Ii',b,56+8*k);p=off;shots=[]
  while True:
   assert p+2<=len(b),(path,k,p)
   if struct.unpack_from('<h',b,p)[0]<0:break
   assert p+56<=len(b)
   v=struct.unpack_from('<hhffffffhhhhhhIIII',b,p)
   r=dict(zip(names,v));r['offset']=hex(p);shots.append(r);p+=56
  row['power_levels'].append({'minimumPower':power,'offset':hex(off),'terminal_offset':hex(p),'descriptors':shots})
 return row

def std(path):
 b=path.read_bytes();objcount,quadcount,instoff,scriptoff=struct.unpack_from('<hhii',b)
 assert len(b)>=0x490 and 0<=objcount<10000 and 0x490<=instoff<scriptoff<len(b)
 row={'file':path.name,'sha256':hashlib.sha256(b).hexdigest(),'objects':[],'instances':[],'instructions':[],'declared_quads':quadcount}
 offs=struct.unpack_from('<'+'I'*objcount,b,0x490)
 for off in offs:
  assert off+28<=len(b)
  id,z,flags=struct.unpack_from('<hbb',b,off);pos=struct.unpack_from('<ffffff',b,off+4);p=off+28;quads=[]
  while True:
   typ,size=struct.unpack_from('<hh',b,p)
   if typ<0:break
   assert size in(28,36) and p+size<=len(b),(path,p,typ,size)
   anm,vm=struct.unpack_from('<hh',b,p+4)
   quads.append({'offset':hex(p),'type':typ,'size':size,'anm_script':anm,'vm':vm,'geometry':struct.unpack_from('<'+'f'*((size-8)//4),b,p+8)})
   p+=size
  row['objects'].append({'id':id,'offset':hex(off),'zLevel':z,'flags':flags,'position':pos[:3],'size':pos[3:],'quads':quads})
 p=instoff
 while True:
  id,res=struct.unpack_from('<hh',b,p)
  if id<0:break
  assert p+16<=scriptoff and 0<=id<objcount
  row['instances'].append({'offset':hex(p),'object_id':id,'position':struct.unpack_from('<fff',b,p+4)})
  p+=16
 p=scriptoff
 for _ in range(100000):
  frame,op,size=struct.unpack_from('<ihh',b,p)
  if frame<0 or op<0:break
  # RawStageInstr records occupy fixed 20 bytes; size stores payload bytes.
  assert 0<=op<=34 and p+20<=len(b),(path,p,frame,op,size)
  row['instructions'].append({'offset':hex(p),'frame':frame,'opcode':op,'size_field':size,'args_i':struct.unpack_from('<iii',b,p+8),'args_f':struct.unpack_from('<fff',b,p+8)})
  p+=20
 else:raise ValueError('unterminated STD script')
 row['terminal_offset']=hex(p)
 assert sum(len(o['quads']) for o in row['objects'])==quadcount,(path,'quad count')
 return row

def run():
 resources=ROOT/'private_resources';rep=ROOT/'reports';rep.mkdir(exist_ok=True)
 anms=[read_anm(p) for p in sorted(resources.glob('*.anm'))]
 shts=[sht(p) for p in sorted(resources.glob('*.sht'))]
 stds=[std(p) for p in sorted(resources.glob('*.std'))]
 for n,x in [('anm_all.json',anms),('sht_complete.json',shts),('std_complete.json',stds)]:
  (rep/n).write_text(json.dumps(x,ensure_ascii=False),encoding='utf8')
 summ={'anm_files':len(anms),'anm_entries':sum(len(a['entries']) for a in anms),'anm_scripts':sum(len(a['scripts']) for a in anms),'anm_sprites':sum(len(a['sprites']) for a in anms),'anm_instruction_sites':sum(len(s['instructions'])-1 for a in anms for s in a['scripts']),'sht_files':len(shts),'sht_levels':sum(len(s['power_levels']) for s in shts),'sht_descriptor_occurrences':sum(len(l['descriptors']) for s in shts for l in s['power_levels']),'std_files':len(stds),'std_objects':sum(len(s['objects']) for s in stds),'std_quads':sum(s['declared_quads'] for s in stds),'std_instances':sum(len(s['instances']) for s in stds),'std_instruction_sites':sum(len(s['instructions']) for s in stds),'std_observed_opcodes':dict(sorted(C.Counter(i['opcode'] for s in stds for i in s['instructions']).items()))}
 (rep/'resource_tables_summary.json').write_text(json.dumps(summ,indent=2));print(json.dumps(summ,indent=2))
if __name__=='__main__':run()
