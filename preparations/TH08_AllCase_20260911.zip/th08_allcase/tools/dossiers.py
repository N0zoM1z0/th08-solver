#!/usr/bin/env python3
"""Generate per-occurrence engineering dossiers; no inferred global frame schedule."""
from pathlib import Path
import json,struct,collections,html
from analyze_ecl import read_ecl,OPS
from atlas import operands_info
ROOT=Path(__file__).resolve().parent.parent

def run():
 rep=ROOT/'reports';spells=json.loads((rep/'spell_atlas.json').read_text());subs=json.loads((rep/'subprogram_atlas.json').read_text());by={(s['file'],s['sub']):s for s in subs}
 programs={p.name:read_ecl(p) for p in (ROOT/'private_resources').glob('*.ecl')}
 dossiers=[];md=['# 431个开符来源：逐来源参数、控制点与验收契约','这些表来自全量字节码，不是已验证路线。时间均是所在上下文的局部标签；静态站点数不是运行次数。普通/练习文件不合并。每个mask切片仍需入口与运行时门槛判定。']
 for sp in sorted(spells,key=lambda x:(x['id'],x['file'],x['pc'])):
  ids=sorted(set(s for sl in sp['difficulty_slices'] for s in sl['sub_ids']));rows=[];dependencies=[]
  for sid in ids:
   s=programs[sp['file']]['subs'][sid]
   for i in s['instructions']:
    if i['opcode']==-1 or not any(i['mask']&sl['difficulty_mask']==sl['difficulty_mask'] and sid in sl['sub_ids'] for sl in sp['difficulty_slices']):continue
    if 96<=i['opcode']<=104 or i['opcode'] in (105,106,107,108,110,111,112,113,114,115,116,117,118,119,120,121,130,133,134,135,136,137,153,173,175,176,179,180,181):
     oi,err=operands_info(i)
     rows.append(dict(sub=sid,pc=hex(i['offset']),local_time=i['time'],mask=hex(i['mask']),opcode=i['opcode'],name=OPS.get(i['opcode'],'?'),operands=oi,raw_payload=i['payload'],transform=i.get('transform'),ex_id=i.get('ex_id')))
   dependencies.extend(dict(sub=sid,**site) for site in by[sp['file'],sid]['selector_sites'] if site['role'] in ('read','read_write') and site['selector'] in ('PLAYER_X','PLAYER_Y','PLAYER_Z','ANGLE_TO_PLAYER','DISTANCE_TO_PLAYER','PLAYER_IS_YOUKAI','RAND_ANGLE','RAND_FLOAT','RAND_INT'))
  d=dict(id=sp['id'],file=sp['file'],root_sub=sp['sub'],start_spell_pc=sp['pc'],name=sp['name'],mask=sp['mask'],difficulty_slices=sp['difficulty_slices'],control_and_emitter_sites=rows,external_read_sites=dependencies,status='STATIC_CONTRACT_NOT_EXECUTABLE_WORLD_MODEL')
  dossiers.append(d);md += [f"## ID{sp['id']:03d} {sp['name']} — {sp['file']} / sub{sp['sub']} / {sp['pc']}",f"原始掩码 `{sp['mask']}`；本来源的局部调用/生成闭包：`{ids}`。",'### 难度切片（只是mask兼容）']
  for sl in sp['difficulty_slices']:
   md += [f"`{sl['difficulty_label']}` mask={sl['difficulty_mask']:#x}：{sl['instruction_sites']}指令站点，{sl['shoot_sites']}射击站点；EX={sl['ex_ids']}；变换={sl['transform_kinds']}；未解析边={len(sl['unresolved_edges'])}。"]
  md+=['### 发射、变换、阶段和EX参数','|sub|PC|局部t|mask|指令|参数（选择器/立即数）|','|---:|---|---:|---|---|---|']
  for r in rows:
   vals=', '.join((a['selector'] if a['selector'] else str(a['value']))+(' [写]' if a['role']=='write' else '') for a in r['operands'])
   md.append(f"|{r['sub']}|{r['pc']}|{r['local_time']}|{r['mask']}|{r['name']}|{vals}|")
  md+=['### 候选相关读取（不包含所有隐式依赖）']
  if dependencies:
   md.append('; '.join(f"sub{x['sub']}@{x['pc']} {x['selector']}" for x in dependencies))
  else:md.append('无这组显式玩家/随机选择器读取；这不证明发射门槛、rank、RNG、伤害及外部控制器不相关。')
  md+=['### 求解契约与测试目标',*sp['proposed_methods'],'先固定真实初态、入口、难度、形态及输入消费阶段；记录本节所有发射/EX的首次实际执行时刻；对不同动作比较取样值、抑制结果、RNG、槽位及碰撞查询。未知上下文必须阻止优化，不得用0补齐。','验收状态：资源结构已解析；全世界执行、完整路线、原版实时成绩均未由本节证明。']
 (rep/'phase_contracts.json').write_text(json.dumps(dossiers,ensure_ascii=False,separators=(',',':')),encoding='utf8');(ROOT/'docs/PHASE_DOSSIERS.md').write_text('\n\n'.join(md),encoding='utf8')
 a=json.loads((rep/'anm_all.json').read_text());et=next(x for x in a if x['file']=='etama.anm')
 primary=list(range(10))+[25]+list(range(106,116));templates=[]
 for typ,script in enumerate(primary):
  ins=et['scripts'][script]['instructions'];initial=[x for x in ins if x['time']==0 and x['opcode'] in(3,25)]
  sprite=next(struct.unpack('<i',bytes.fromhex(x['payload']))[0] for x in initial if x['opcode']==3)
  typeins=[x for x in initial if x['opcode']==25];vmtype=struct.unpack('<i',bytes.fromhex(typeins[0]['payload']))[0] if typeins else None
  h=et['sprites'][sprite]['height']
  size=4 if h<=8 else (4 if script in (2,4,5,6,106,107,108,111,112) else 6) if h<=16 else (5 if script in(8,113,114,115) else 8 if script in(9,109,110) else 10) if h<=32 else 24
  templates.append(dict(bullet_type=typ,main_script=script,script_offset=hex(et['scripts'][script]['offset']),initial_sprite=sprite,sprite_size=[et['sprites'][sprite]['width'],h],collision_full_size=[size,size],explicit_initial_vm_type=vmtype))
 rng=[dict(file=x['file'],script=s['index'],pc=hex(i['offset']),opcode=i['opcode'],local_time=i['time']) for x in a for s in x['scripts'] for i in s['instructions'] if i['opcode'] in(59,60)]
 audit=dict(bullet_templates=templates,anm_rng_sites=rng,rng_opcode_counts=dict(collections.Counter(x['opcode'] for x in rng)),qualification='Template sizes from AddedCallback plus real initial sprite. ANM parser is structural, not an entire ANM executor.')
 (rep/'bullet_and_anm_contracts.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf8')
 print(json.dumps(dict(phase_occurrences=len(dossiers),emitter_control_rows=sum(len(d['control_and_emitter_sites']) for d in dossiers),bullet_templates=len(templates),anm_rng_sites=len(rng)),indent=2))
if __name__=='__main__':run()
