#!/usr/bin/env python3
"""ANM v3 metadata/script parser. No texture decoding or game emulation."""
from pathlib import Path
import struct,json,hashlib
ROOT=Path(__file__).resolve().parent.parent
NAMES={-1:'END',0:'NOP',1:'DELETE',2:'STATIC',3:'SPRITE',4:'JUMP',5:'JUMP_DEC',6:'POS',7:'SCALE',8:'ALPHA',9:'COLOR',12:'ROTATE',13:'ANGULAR_VELOCITY',14:'SCALE_GROWTH',15:'ALPHA_TIME_LINEAR',16:'ADDITIVE',20:'STOP',21:'INTERRUPT',23:'STOP_HIDE',25:'SET_TYPE',28:'VISIBLE',30:'ZWRITE',34:'ALPHA_TIME',35:'ROTATE_TIME',36:'SCALE_TIME',37:'ISET',38:'FSET',39:'IADD',40:'FADD'}
def read_anm(p):
 b=Path(p).read_bytes();base=0;sprites=[];scripts=[];entries=[]
 while True:
  h=struct.unpack_from('<16I',b,base);ns,nc=h[:2];assert h[10]==3 and ns<10000 and nc<10000
  name=b[base+h[7]:].split(b'\0',1)[0].decode('cp932');entries.append(dict(offset=base,name=name,sprites=ns,scripts=nc))
  for k in range(ns):
   off=base+struct.unpack_from('<I',b,base+64+4*k)[0];vals=struct.unpack_from('<Iffff',b,off)
   sprites.append(dict(index=len(sprites),raw_id=vals[0],offset=off,x=vals[1],y=vals[2],width=vals[3],height=vals[4]))
  for k in range(nc):
   sid,off=struct.unpack_from('<II',b,base+64+4*ns+8*k);pos=base+off;start=pos;ins=[]
   for step in range(10000):
    op,size,t,mask=struct.unpack_from('<hHhH',b,pos)
    if op==-1:
     ins.append(dict(offset=pos,opcode=op,time=t,size=size,mask=mask,payload=''));break
    assert size>=8 and pos+size<=len(b)
    ins.append(dict(offset=pos,opcode=op,time=t,size=size,mask=mask,payload=b[pos+8:pos+size].hex()));pos+=size
   else:raise ValueError('ANM no terminator')
   scripts.append(dict(index=len(scripts),raw_id=sid,offset=start,instructions=ins))
  if not h[14]:break
  assert h[14]>=64;base+=h[14];assert base<len(b)
 return dict(file=Path(p).name,sha256=hashlib.sha256(b).hexdigest(),entries=entries,sprites=sprites,scripts=scripts)
def fmt(s):
 out=[f"script[{s['index']}] raw_id={s['raw_id']} offset={s['offset']:#x}"]
 for i in s['instructions']:
  p=bytes.fromhex(i['payload']);vs=[]
  for j in range(0,len(p)//4*4,4):
   a=struct.unpack_from('<i',p,j)[0];f=struct.unpack_from('<f',p,j)[0]
   vs.append(str(a) if i['opcode'] in (3,25,20,2,37,1,21,28,30) else f'{a}/f:{f:.8g}')
  out.append(f" {i['offset']:#x} t={i['time']} {NAMES.get(i['opcode'],str(i['opcode']))} mask={i['mask']:#x} {', '.join(vs)}")
 return '\n'.join(out)
def main():
 for f in ['etama.anm','stg4benm.anm']:
  p=ROOT/'private_resources'/f
  if not p.exists():continue
  a=read_anm(p);(ROOT/'reports'/(f+'.metadata.json')).write_text(json.dumps(a,indent=2))
  ids=([2,111,18,19,20] if f=='etama.anm' else [6])
  text='\n\n'.join(fmt(a['scripts'][k]) for k in ids)
  (ROOT/'reports'/(f+'.selected.txt')).write_text(text);print(f,len(a['sprites']),len(a['scripts']));print(text)
if __name__=='__main__':main()
