#!/usr/bin/env python3
"""Extract audit inputs from a user-owned TH08 archive. No game files are distributed."""
import argparse,json,hashlib
from pathlib import Path
from unpack_dat import read_archive,lzss,content_decrypt
ROOT=Path(__file__).resolve().parent.parent
def main():
 ap=argparse.ArgumentParser();ap.add_argument('archive',type=Path);args=ap.parse_args()
 out=ROOT/'private_resources';out.mkdir(exist_ok=True);(ROOT/'reports').mkdir(exist_ok=True)
 d,entries,meta=read_archive(args.archive)
 for e in entries:
  if Path(e['name']).suffix in {'.ecl','.sht','.std','.txt','.dat','.ver'} or e['name'] in {'etama.anm','stg4benm.anm'}:
   blob=content_decrypt(lzss(d[e['offset']:e['offset']+e['compressed_size']],e['packed_decoded_size']))
   (out/e['name']).write_bytes(blob);e.update(decoded_size=len(blob),sha256=hashlib.sha256(blob).hexdigest())
 (ROOT/'reports/archive_manifest.json').write_text(json.dumps(dict(archive=meta,entries=entries),indent=2,ensure_ascii=False));print(json.dumps(meta,indent=2))
if __name__=='__main__':main()
