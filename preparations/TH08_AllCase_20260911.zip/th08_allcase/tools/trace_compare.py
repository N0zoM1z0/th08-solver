#!/usr/bin/env python3
"""Strict event-stream comparison. Missing footer, drops or length mismatch never PASS.
Call traces are not complete world snapshots; PASS means these fields match only.
"""
import argparse,json,itertools,pathlib

def load(p):
    with open(p,encoding='utf8') as f:
        n=0;end=None;header=None
        for line_no,line in enumerate(f,1):
            try:r=json.loads(line)
            except Exception as ex:raise ValueError(f'{p}:{line_no}: invalid JSON') from ex
            if header is None:
                if r.get('kind')!='header' or r.get('schema')!=1:raise ValueError('missing/unknown header')
                header=r;yield r;continue
            if end is not None:raise ValueError('data after footer')
            if r.get('kind')=='end':end=r
            else:n+=1
            yield r
        if end is None:raise ValueError('missing end footer: trace truncated or process killed')
        if end.get('rows')!=n or end.get('dropped')!=0:raise ValueError(f'incomplete trace: {end}, actual rows={n}')

def firstdiff(a,b,p=''):
    if type(a)!=type(b):return {'field':p,'left':a,'right':b}
    if isinstance(a,dict):
        if a.keys()!=b.keys():return {'field':p,'left_keys':sorted(a),'right_keys':sorted(b)}
        for k in a:
            d=firstdiff(a[k],b[k],p+'.'+k)
            if d:return d
    elif isinstance(a,list):
        if len(a)!=len(b):return {'field':p,'left_length':len(a),'right_length':len(b)}
        for k,(x,y) in enumerate(zip(a,b)):
            d=firstdiff(x,y,f'{p}[{k}]')
            if d:return d
    elif a!=b:return {'field':p,'left':a,'right':b}
    return None

def compare(a,b):
    missing=object(); first=None;count=0
    try:
        # Keep consuming even after a mismatch, to detect invalid/truncated tails.
        for count,(x,y) in enumerate(itertools.zip_longest(load(a),load(b),fillvalue=missing),1):
            if first is None:
                if x is missing or y is missing:first={'row':count,'field':'length'}
                else:
                    d=firstdiff(x,y)
                    if d:first={'row':count,'tick':x.get('tick'),'seq':x.get('seq'),**d}
    except ValueError as ex:return {'status':'INVALID_TRACE','error':str(ex),'first_divergence':first}
    return {'status':'FIELDS_MATCH_ONLY' if first is None else 'DIVERGED','rows_including_header_footer':count,'first_divergence':first}
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('left');a.add_argument('right');x=a.parse_args();r=compare(x.left,x.right);print(json.dumps(r,indent=2));raise SystemExit(0 if r['status']=='FIELDS_MATCH_ONLY' else 2)
