// Measures ONLY the actual ecldata1 sub40 emission scheduler.
// No bullets are moved, no collision/search/graphics/input or full ECL runtime.
// The generated header contains the user's decoded scalar instructions, not game art.
#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <stdexcept>
#include <vector>
struct Ins {int time,op;unsigned mask,flags;int target;std::array<std::uint32_t,8> w;};
#include "emitter_fixture.hpp"
static float toF(std::uint32_t x){float f;std::memcpy(&f,&x,4);return f;}
static std::uint32_t toU(float x){std::uint32_t u;std::memcpy(&u,&x,4);return u;}
struct Event {int tick,op;std::array<std::uint32_t,8> shot;std::array<std::array<std::uint32_t,7>,2> transforms;};
struct Result{int instructions,events,bullets,lastTick;std::uint64_t digest;};
Result execute(){
 std::array<double,128> vars{};std::array<std::array<std::uint32_t,7>,2> tf{};std::vector<Event> out;out.reserve(160);
 int pc=0,time=0,executed=0,bullets=0;
 auto readF=[&](const Ins&i,int k){float v=toF(i.w[k]);return (i.flags&(1u<<k))?float(vars.at(int(v)-10000)):v;};
 auto readI=[&](const Ins&i,int k){int v=int(i.w[k]);return (i.flags&(1u<<k))?int(vars.at(v-10000)):v;};
 for(int tick=0;tick<=400;++tick,++time){
  while(pc<int(code.size())&&code[pc].time==time){
   const Ins&i=code[pc];if((i.mask&8)!=8){++pc;continue;}++executed;
   switch(i.op){
    case 6:vars.at(int(i.w[0])-10000)=readI(i,1);break;
    case 7:vars.at(int(toF(i.w[0]))-10000)=readF(i,1);break;
    case 15:case 16:case 17:{float a=readF(i,0),b=readF(i,1);vars.at(int(toF(i.w[0]))-10000)=float(i.op==15?a+b:i.op==16?a-b:a*b);break;}
    case 111:{int slot=readI(i,0);for(int k=0;k<7;++k)tf.at(slot)[k]=i.w[k];break;}
    case 97:case 99:{Event e{tick,i.op,i.w,tf};
     // SHOOT packed shorts occupy word0, but angle is operand6 / word5.
     float a=toF(i.w[5]);if(i.flags&(1u<<6))a=float(vars.at(int(a)-10000));e.shot[5]=toU(a);
     bullets+=int(i.w[1])*int(i.w[2]);out.push_back(e);break;}
    case 5:{int slot=int(i.w[2])-10000;vars.at(slot)-=1;if(vars.at(slot)>0){time=int(i.w[0]);pc=i.target;continue;}break;}
    case 53:{std::uint64_t h=1469598103934665603ULL;for(const auto&e:out){h=(h^e.tick)*1099511628211ULL;for(auto v:e.shot)h=(h^v)*1099511628211ULL;}
     return {executed,int(out.size()),bullets,tick,h};}
    default:throw std::runtime_error("unsupported executed opcode");
   }++pc;
  }
 }
 throw std::runtime_error("no return within bound");
}
volatile std::uint64_t sink=0;
int main(){
 auto check=execute();if(check.events!=160||check.bullets!=840||check.lastTick!=360)return 2;
 for(int i=0;i<100;++i)sink=sink^execute().digest;
 std::vector<double> ns;constexpr int batch=1000,repeats=41;
 for(int j=0;j<repeats;++j){auto a=std::chrono::steady_clock::now();std::uint64_t h=0;
  for(int k=0;k<batch;++k){h^=execute().digest+std::uint64_t(k);}
  sink=sink^h;
  auto b=std::chrono::steady_clock::now();ns.push_back(std::chrono::duration<double,std::nano>(b-a).count()/batch);}
 std::sort(ns.begin(),ns.end());
 std::cout<<"{\"scope\":\"actual ecldata1 sub40 emission schedule only; NO motion collision search ECL world or Windows\",\"executed_instructions\":"<<check.instructions<<",\"emission_commands\":"<<check.events<<",\"requested_bullets\":"<<check.bullets<<",\"return_tick\":"<<check.lastTick<<",\"digest\":\""<<check.digest<<"\",\"batch\":"<<batch<<",\"repeats\":"<<repeats<<",\"median_nanoseconds_per_schedule\":"<<ns[repeats/2]<<",\"p95_of_batch_averages_ns\":"<<ns[int((repeats-1)*.95)]<<",\"max_batch_average_ns\":"<<ns.back()<<"}\n";
}
