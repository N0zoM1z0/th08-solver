#!/usr/bin/env python3
"""Extract unmodified production collision function bodies and exercise them.
Usage: python tools/source_geometry_oracle.py --repo /path/to/th08 --out results/source_oracle
This is an isolated, native-compiler predicate oracle with observable Die/graze
stubs. It is NOT a whole-engine, Windows or original-x87 equivalence test.
"""
from pathlib import Path
import argparse,hashlib,json,subprocess

def body(source,signature):
 start=source.index(signature);a=source.index('{',start);depth=1;b=a+1
 while depth:
  depth+=(source[b]=='{')-(source[b]=='}');b+=1
 return source[start:b]

PREFIX=r'''
#include <cmath>
#include <cstdint>
#include <iostream>
#include <random>
#include <algorithm>
using f32=float;using i32=int32_t;using u32=uint32_t;
struct Float3 {float x=0,y=0,z=0;Float3()=default;Float3(float a,float b,float c=0):x(a),y(b),z(c){} Float3 operator+(Float3 b)const{return {x+b.x,y+b.y,z+b.z};} Float3 operator-(Float3 b)const{return {x-b.x,y-b.y,z-b.z};} Float3 operator/(float s)const{return {x/s,y/s,z/s};}};
struct PlayerCollisionRegion {Float3 center,size;float radius=0,angle=0;int active=0,collisionValue=0,hitAccumulator=0;};
#define ARRAY_SIZE_SIGNED(x) int(sizeof(x)/sizeof((x)[0]))
enum {PLAYER_STATE_ALIVE,PLAYER_STATE_SPAWNING,PLAYER_STATE_DYING,PLAYER_STATE_INVULNERABLE};
constexpr u32 REPLAY_FRAME_EVENT_PLAYER_HIT=1;
struct Replay {u32 frameEventFlags=0;} replay;Replay*g_ReplayManager=&replay;
struct Game {void RandomizeAntiTamper(){}} g_GameManager;
struct Player {Float3 position,hurtboxHalfSize,hurtboxBoundsMin,hurtboxBoundsMax,grazeBoundsMin,grazeBoundsMax;PlayerCollisionRegion cancelRegions[192];int bulletCancelItemType=0,playerState=0,deaths=0,grazes=0;
void Die(){++deaths;playerState=PLAYER_STATE_DYING;}void AwardGraze(Float3*,int){++grazes;}
i32 CheckBulletCancelCollision(Float3*,Float3*);i32 CheckBulletCollision(Float3*,Float3*);i32 CheckLethalCollision(Float3*,Float3*);i32 CheckGrazeCollision(Float3*,Float3*);u32 CalcLaserHitbox(Float3*,Float3*,Float3*,f32,i32);
};
'''
SUFFIX=r'''
bool compact_box(Float3 p,Float3 h,Float3 c,Float3 size){
Float3 amin=p-h,amax=p+h,bmin=c-size/2.0f,bmax=size/2.0f+c;
return !(amin.x>bmax.x||amin.y>bmax.y||amax.x<bmin.x||amax.y<bmin.y);}
bool compact_laser(Float3 p,Float3 h,Float3 c,Float3 size,Float3 origin,float angle){
float s=std::sin(-angle),co=std::cos(-angle);Float3 d=p-origin;
Float3 q{co*d.x-s*d.y+origin.x,co*d.y+s*d.x+origin.y};return compact_box(q,h,c,size);}
bool compact_cancel(Float3 p,const PlayerCollisionRegion&r){
if(!r.active)return false;float x=p.x-r.center.x,y=p.y-r.center.y;
if(r.radius!=0)return x*x+y*y<r.radius*r.radius;
if(r.angle!=0){float s=std::sin(-r.angle),c=std::cos(-r.angle);float a=c*x-s*y,b=c*y+s*x;return -r.size.x/2<=a&&a<=r.size.x/2&&-r.size.y/2<=b&&b<=r.size.y/2;}
return compact_box(p,{0,0},r.center,r.size);}
int main(){std::mt19937 rng(20260911);auto u=[&](float a,float b){return std::uniform_real_distribution<float>(a,b)(rng);};uint64_t mismatch=0;
for(int i=0;i<300000;++i){Player p;p.position={u(-40,424),u(-40,488)};p.hurtboxHalfSize={u(.5f,3),u(.5f,3)};p.hurtboxBoundsMin=p.position-p.hurtboxHalfSize;p.hurtboxBoundsMax=p.position+p.hurtboxHalfSize;
Float3 c{u(-100,484),u(-100,548)},size{u(0,590),u(0,288)},origin{u(-100,484),u(-100,548)};float angle=u(-3.142f,3.142f);
p.playerState=rng()%4;int state=p.playerState;replay.frameEventFlags=0;
p.CheckBulletCollision(&c,&size);bool b=(replay.frameEventFlags&1)!=0;if(b!=compact_box(p.position,p.hurtboxHalfSize,c,size))++mismatch;
if((p.deaths!=0)!=(b&&state==0))++mismatch;
p.playerState=state;p.deaths=0;replay.frameEventFlags=0;p.CalcLaserHitbox(&c,&size,&origin,angle,0);
b=(replay.frameEventFlags&1)!=0;if(b!=compact_laser(p.position,p.hurtboxHalfSize,c,size,origin,angle))++mismatch;
if((p.deaths!=0)!=(b&&state==0))++mismatch;
auto&r=p.cancelRegions[0];r.active=1;r.center=origin;r.size=size;r.angle=(i%3==1)?angle:0;r.radius=(i%3==0)?u(1,100):0;
b=p.CheckBulletCancelCollision(&c,&size)==2;if(b!=compact_cancel(c,r))++mismatch;
p.playerState=0;replay.frameEventFlags=0;int ret=p.CheckBulletCollision(&c,&size);if((ret==2)!=b)++mismatch;
if(b&&(replay.frameEventFlags&1))++mismatch;
}
std::cout<<"{\"random_cases\":300000,\"predicates_per_case\":3,\"predicate_comparisons\":900000,\"mismatches\":"<<mismatch<<",\"side_effect_order_checked\":true}\n";return mismatch?1:0;}
'''
def run(repo,out):
 out.mkdir(parents=True,exist_ok=True);src=(repo/'src/Player.cpp').read_text();glob=(repo/'src/Global.cpp').read_text()
 funcs=[body(glob,'void Rotate(Float3 *'),*[body(src,x) for x in ['i32 Player::CheckBulletCancelCollision(', 'i32 Player::CheckBulletCollision(', 'i32 Player::CheckLethalCollision(', 'i32 Player::CheckGrazeCollision(', 'u32 Player::CalcLaserHitbox(']]]
 cpp=PREFIX+'\n'.join(funcs)+SUFFIX;(out/'oracle.cpp').write_text(cpp)
 command=['g++','-std=c++17','-O3','-ffp-contract=off',str(out/'oracle.cpp'),'-o',str(out/'oracle')]
 subprocess.run(command,check=True);r=subprocess.run([str(out/'oracle')],capture_output=True,text=True,check=True)
 result=json.loads(r.stdout);result.update(compiler=subprocess.check_output(['g++','--version'],text=True).splitlines()[0],compile_command=command,source_hashes={x:hashlib.sha256((repo/x).read_bytes()).hexdigest() for x in ['src/Player.cpp','src/Global.cpp']},source_body_sha256=hashlib.sha256('\n'.join(funcs).encode()).hexdigest(),evidence='unmodified function bodies, isolated native predicate harness; NOT original Windows run')
 (out/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();run(a.repo.resolve(),a.out.resolve())
