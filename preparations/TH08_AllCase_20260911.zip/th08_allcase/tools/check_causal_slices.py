#!/usr/bin/env python3
"""Small source+resource-derived causal calculations, NOT full game runs."""
from pathlib import Path
import struct,json,math
from analyze_ecl import read_ecl
ROOT=Path(__file__).resolve().parent.parent

def main():
 e=read_ecl(ROOT/'private_resources/ecldata1.ecl');ins={i['offset']:i for i in e['subs'][0]['instructions']}
 f=lambda pc,k:struct.unpack_from('<f',bytes.fromhex(ins[pc]['payload']),4*k)[0]
 alpha=f(0x2a0,1);beta=f(0x248,1)
 assert abs(alpha-.002)<1e-8 and abs(beta-.6)<1e-6
 n=90;bound=beta*(1-(1-alpha)**n)
 tracking=dict(file=e['file'],sub=0,pcs=['0x218','0x248','0x270','0x2a0','0x2c8','0x2f0'],alpha_float32=alpha,beta_float32=beta,updates=90,ideal_real_arithmetic_recurrence='D_next=(1-alpha)*D + alpha*beta*(player_now-spawn_origin)',state_dimension_per_enemy=2,fixed_initial_D_linf_input_error_to_D_bound_at_update90=bound,qualification='Closed form bounds refer to ideal real arithmetic; bound floating-point rounding separately. Initial D is fixed at the planning snapshot. Actual enemy position also depends on interpolation and other update semantics.')
 # Reproduce only the order-sensitive U16 stream / first hex-direction choice.
 # Source C++ U32 operand evaluation order needs binary attestation; fixture explicitly fixes high-half-first.
 def step(s):
  t=((s^0x9630)-0x6553)&65535;return ((t<<2)|(t>>14))&65535
 def choice(seed,skip_angle,previous_direction=0):
  s=seed;draws=0
  def u32():
   nonlocal s,draws
   s=step(s);hi=s;s=step(s);lo=s;draws+=2;return(hi<<16)|lo
  if not skip_angle:u32()
  k=(u32()&0x7fffffff)%6;back=(previous_direction+3)%6
  if k==back:k=(k+1)%6
  return dict(direction=k,u16_draws=draws,seed_after=s)
 pairs=[]
 for seed in [0,1,42,12345,65535]:pairs.append(dict(seed=seed,inside_48=choice(seed,True),outside_48=choice(seed,False)))
 assert pairs[0]['inside_48']['direction']!=pairs[0]['outside_48']['direction']
 result=dict(tracking_filter=tracking,proximity_rng_fixture=dict(file='ecldata6.ecl',sub=62,seed_scope='Seed just before DispatchShotInstruction; hold other RNG consumers fixed for this isolated calculation.',ordering='Explicit high half first, then low half. NOT attested U32 evaluation order of original binary.',pairs=pairs,qualification='Shows why skipping a random angle can alter subsequent tree directions. Does not generate a full tree or assert original runtime outcomes.'))
 (ROOT/'reports/causal_slice_checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
