#!/usr/bin/env python3
"""Cross-check concrete resource parameters against source-derived mechanisms.
These are static and isolated state-machine checks, not complete gameplay tests.
"""
from pathlib import Path
import struct,json,math,collections
from analyze_ecl import read_ecl
from analyze_anm import read_anm
ROOT=Path(__file__).resolve().parent.parent
def load(name,sid):return read_ecl(ROOT/'private_resources'/name)['subs'][sid]['instructions']
def words(i):return struct.unpack('<'+'i'*(len(bytes.fromhex(i['payload']))//4),bytes.fromhex(i['payload']))
def main():
 out={}
 # Reisen: validate the actual bullet-template state and event schedule.
 a=read_anm(ROOT/'private_resources/etama.anm');s=a['scripts'][111]
 assert any(i['opcode']==25 and words(i)[0]==1 and i['time']==0 for i in s['instructions'])
 ins=load('ecldata5.ecl',75);ex=[(i['time'],hex(i['offset'])) for i in ins if i['opcode']==136 and words(i)[0]==14]
 assert [t for t,p in ex]==[140,140,220,220,240,240]
 shots=[i for i in ins if i['opcode']==99 and i['mask']&8];layers=[]
 for i in shots:
  args=struct.unpack('<hhiiffffI',bytes.fromhex(i['payload']));n=144 if i['time']==90 else 56
  speeds=[args[4]-(args[4]-args[5])*j/args[3] for j in range(args[3])]
  layers.append(dict(local_time=i['time'],pc=hex(i['offset']),count1=n,count2=args[3],nominal_requests=n*args[3],layer_speeds=speeds,marker_flags=hex(args[-1])))
 assert sum(x['nominal_requests'] for x in layers)==592
 phase=1;disabled=False;transitions=[]
 for t in (140,220,240):
  if phase==1:phase=0;disabled=True
  elif phase==0:phase=2
  else:phase=1;disabled=False
  transitions.append(dict(local_time=t,type=phase,collision_disabled=disabled))
 out['reisen']=dict(file='ecldata5.ecl',sub=75,spell_raw_id=115,template_index=111,template_offset=hex(s['offset']),ex_calls=ex,layers=layers,nominal_requests_per_parent_cycle=592,parent_loop_ticks=210,eligible_batch_transitions=transitions,qualification='Only marked, alive bullets in corresponding VM type; unrelated familiar bullets remain hazardous. No full engine timing test.')
 # Reimu: distinct deterministic warp and player-distance-dependent emission.
 ins=load('ecldata4a.ecl',46)
 spawns=[words(i)[0] for i in ins if i['opcode'] in (90,91,92) and i['mask']&8]
 assert collections.Counter(spawns)=={47:4,48:4}
 exs=[(i['opcode'],words(i)[0]) for i in ins if i['opcode'] in(136,137)]
 assert(136,6) in exs and(137,7) in exs
 gate=next(i for i in ins if i['offset']==0x84e8);lhs,rhs,t,jmp=struct.unpack('<ffii',bytes.fromhex(gate['payload']));assert lhs==10050 and rhs==64 and gate['opcode']==51
 out['reimu']=dict(file='ecldata4a.ecl',sub=46,spell_raw_id=73,spawner_counts=dict(collections.Counter(spawns)),guard_pc=hex(gate['offset']),guard_distance=rhs,skip_aimed_burst_when_distance_ge=rhs,extra_aimed_requests=5,warp_center=[192,224],inner_rect=[56.23548889160156,88.23548889160156,327.7645263671875,359.7645263671875],outward_scale=224/135.76451110839844,inward_scale=135.76451110839844/224,source_asymmetry_note='Current-zone outer left=-32; previous-zone outer left=-31.100006103515625. Preserve this asymmetry.')
 # Double Spark: actual animation does not rotate its angle itself.
 a=read_anm(ROOT/'private_resources/stg4benm.anm');s=a['scripts'][6]
 assert not any(i['opcode'] in(12,13,35) for i in s['instructions'])
 ins=load('ecldata4b.ecl',57);ex=[(i['time'],words(i)[0]) for i in ins if i['opcode']==137]
 assert ex==[(120,9),(310,-1)]
 out['double_spark']=dict(file='ecldata4b.ecl',sub=57,spell_raw_id=92,main_sub=55,lethal_controller_interval_local=[120,310],callback=9,anm_file='stg4benm.anm',anm_script=6,anm_script_offset=hex(s['offset']),anm_rotation_instructions=0,qualification='Interval in actor ECL clock; birth runs ECL immediately, so align physical-frame counts with original update order. Other ring hazards are not included.')
 # Kaguya: asynchronous boundary event triggers subsequent aimed transform.
 ins=load('ecldata7.ecl',72);tf=[i['transform'] for i in ins if'transform'in i]
 assert [t['kind'] for t in tf]==[2048,128,16384]
 parent=load('ecldata7.ecl',71);spawns=[i for i in parent if i['opcode'] in(90,91,92) and words(i)[0]==72 and i['mask']&8]
 assert len(spawns)==7
 out['kaguya']=dict(file='ecldata7.ecl',sub=72,parent_sub=71,spell_raw_id=170,spawn_count=7,transform_records=tf,first_volley_transform_flags=hex(0xa82),enabled_transform_kinds=[t['kind'] for t in tf if t['kind']&0xa82],disabled_configured_transform_kinds=[t['kind'] for t in tf if not t['kind']&0xa82],first_volley_per_emitter=48,first_volley_total_conditional=336,qualification='Requires all seven emitters to survive to emission and not cancel; zero bounceLimit still processes one boundary event before stopping, according to UpdateBoundaryBounce. No global re-aim tick inferred.')
 # Rising Game: branching and proximity gate affect RNG BEFORE spawn-tree random choices.
 ins=load('ecldata6.ecl',62);gate=next(i for i in ins if i['opcode']==82);radius=struct.unpack('<f',bytes.fromhex(gate['payload']))[0]
 assert radius==48
 split=[i for i in ins if i['opcode']==94];assert len(split)==2 and all(words(i)[0]==62 for i in split)
 shot=next(i for i in ins if i['opcode']==99);args=struct.unpack('<hhiiffffI',bytes.fromhex(shot['payload']))
 assert args[4]==0 and args[6]==10082 and shot['flags']&0x40
 out['rising_game']=dict(file='ecldata6.ecl',sub=62,spell_raw_id=130,parent_sub=56,proximity_radius=radius,shot_pc=hex(shot['offset']),shot_uses_random_angle_despite_zero_speed=True,descendant_sites=[hex(i['offset']) for i in split],split_local_time=4,maximum_counter=9,ideal_total_nodes_from_initial_counter_zero=2**9-1,qualification='511 is cumulative ideal nodes per seed, NOT simultaneous occupancy or actual on-screen bullets. Proximity return in DispatchShotInstruction happens before the random angle read; recursive ECL continues.')
 (ROOT/'reports/verified_mechanisms.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
