#!/usr/bin/env python3
"""Static ECL disassembly and audit; NOT a complete game simulator.
Schemas are transcribed from th08 EclManager.hpp and opcode handlers.
Mask filtering is static inclusion, not dynamic reachability or frequency.
"""
from pathlib import Path
import struct, json, hashlib, collections, math
ROOT=Path(__file__).resolve().parent.parent
NAMES='''TERMINATE SET_SECONDARY_TIME NOP JUMP JUMP_DEC SET_INT SET_FLOAT SET_INT_RANDOM_SIGN SET_FLOAT_RANDOM_SIGN INT_ADD_ASSIGN INT_SUBTRACT_ASSIGN INT_MULTIPLY_ASSIGN INT_DIVIDE_ASSIGN INT_MODULO_ASSIGN FLOAT_ADD_ASSIGN FLOAT_SUBTRACT_ASSIGN FLOAT_MULTIPLY_ASSIGN FLOAT_DIVIDE_ASSIGN FLOAT_MODULO_ASSIGN INT_ADD INT_SUBTRACT INT_MULTIPLY INT_DIVIDE INT_MODULO FLOAT_ADD FLOAT_SUBTRACT FLOAT_MULTIPLY FLOAT_DIVIDE FLOAT_MODULO INT_INCREMENT INT_DECREMENT FLOAT_SINE FLOAT_COSINE POINT_ANGLE INTERPOLATE_VALUE INSTALL_INTERPOLATION NORMALIZE_ANGLE POLAR_TO_CARTESIAN POINT_DISTANCE JUMP_IF_INT_EQUAL JUMP_IF_FLOAT_EQUAL JUMP_IF_INT_NOT_EQUAL JUMP_IF_FLOAT_NOT_EQUAL JUMP_IF_INT_LESS JUMP_IF_FLOAT_LESS JUMP_IF_INT_LESS_EQUAL JUMP_IF_FLOAT_LESS_EQUAL JUMP_IF_INT_GREATER JUMP_IF_FLOAT_GREATER JUMP_IF_INT_GREATER_EQUAL JUMP_IF_FLOAT_GREATER_EQUAL CALL RETURN SET_MAIN_ANM SET_PRIMARY_ANM_SEQUENCE SET_PRIMARY_ANM_SCRIPTS SET_EXTRA_ANM_SCRIPT SET_MAIN_ANM_ALTERNATE SET_PRIMARY_ANM_SEQUENCE_ALTERNATE SET_PRIMARY_ANM_SCRIPTS_ALTERNATE SET_EXTRA_ANM_SCRIPT_ALTERNATE PLAY_SPECIAL_ANM SET_POSITION MOVE_TO SET_DIRECTION_AND_SPEED MOVE_IN_DIRECTION MOVE_RANDOM_IN_BOUNDS SET_AIMED_DIRECTION_AND_SPEED MOVE_IN_AIMED_DIRECTION SET_ANGULAR_VELOCITY SET_ACCELERATION ORBIT_AROUND_POINT ORBIT_AROUND_CURRENT_POSITION SET_ORBIT_VELOCITIES SET_MOVEMENT_BOUNDS DISABLE_MOVEMENT_BOUNDS SET_HITBOX SET_SECONDARY_HITBOX SET_INTERACTION_FLAGS DISABLE_INTERACTION_FLAGS ENABLE_INTERACTION_FLAGS SET_MINIMUM_PLAYER_DISTANCE SET_FORM_EFFECT_ENABLED NOP_84 NOP_85 SET_REMOTE_INT SET_REMOTE_FLOAT CALL_REMOTE SCHEDULE_REMOTE_SUBROUTINE SPAWN_FAMILIAR_AT_POSITION SPAWN_FAMILIAR_AT_OFFSET SPAWN_FAMILIAR_INHERITING_POSITION SPAWN_ENEMY_AT_POSITION SPAWN_ENEMY_RELATIVE KILL_ALL_NON_BOSS_ENEMIES SHOOT_FAN_AIMED SHOOT_FAN SHOOT_CIRCLE_AIMED SHOOT_CIRCLE SHOOT_OFFSET_CIRCLE_AIMED SHOOT_OFFSET_CIRCLE SET_SHOOT_PLACEHOLDER'''.split()
# Complete the sequence from opcode 102, avoiding implicit inferred opcode numbering.
NAMES=NAMES[:101]+'''SHOOT_RANDOM_ANGLE SHOOT_RANDOM_SPEED SHOOT_RANDOM SET_SHOOT_INTERVAL SET_SHOOT_INTERVAL_DELAYED ENABLE_DEFERRED_SHOOTING DISABLE_DEFERRED_SHOOTING SHOOT_NOW SET_SHOOT_OFFSET SET_BULLET_TRANSFORM CLEAR_BULLETS_FOR_TRANSITION SET_BULLET_SOUNDS CREATE_LASER CREATE_LASER_AIMED SELECT_LASER_SLOT ROTATE_LASER AIM_LASER_AT_PLAYER SET_LASER_POSITION TEST_LASER_ACTIVE CANCEL_LASER START_SPELL END_SPELL PLAY_POSITIONED_SOUND CALL_SUBROUTINE_SLOT SET_SUBROUTINE_SLOT SET_BOSS ATTACH_SPELL_EFFECT SET_DEATH_MODE SET_DEATH_CALLBACK SET_LIFE SET_BOSS_TIMER SET_LIFE_CALLBACK SET_TIMER_CALLBACK SET_CHILD_ECL CALL_EX_INSTRUCTION SET_REPEATING_EX_INSTRUCTION SET_DEATH_ANM_SCRIPTS SPAWN_EFFECT SPAWN_EFFECT_WITH_VELOCITY SPAWN_ITEM DROP_POWER_OR_POINT_ITEMS SET_ITEM_DROP_TYPE SET_ITEM_DROP_COUNTS SET_ANM_ROTATION_ENABLED ADD_TIME SET_BACKGROUND_SCRIPT_LABEL SET_BOSS_LIFE_MARKER_COUNT INTERRUPT_MAIN_ANM INTERRUPT_SECONDARY_ANM SET_CALL_STACK_DISABLED SET_BULLET_RANK_INFLUENCE RESET_BOSS_TIMER_CALLBACK CLEAR_LASER_SLOTS SET_TIMEOUT_SPELL SET_SPECIAL_INTERACTION SET_TRAIL SET_BOSS_GAUGE_SLOT SET_DRAW_GROUP SET_DAMAGE_REDUCTION_TIMER REMOVE_BULLETS_IN_RADIUS REMOVE_ALL_BULLETS SET_MANAGER_PROTOCOL_VALUE SET_SPELL_EFFECT_TRACKING_DISABLED SET_MAIN_ANM_ROTATION POLAR_TO_CARTESIAN_ALT SET_LASER_ANGLE DROP_POINT_ITEMS RANDOM_HORIZONTAL_ANGLE SET_LASER_START_CAP_HIDDEN SET_LASER_START_LENGTH SET_LASER_OFFSETS SET_TIMER_PAUSED REPLACE_ALIGNMENT_EFFECT SET_TIMELINE_SPAWNS_SUPPRESSED PREPARE_STAGE_TIME_STOP SET_PHASE_STARTING_LIFE MOVE_RANDOM_BIASED START_STAGE_BACKGROUND_SEQUENCE HIDE_CLOCK_TIME INCREMENT_CLOCK_TIME SET_EXTRA_ANM_FIXED_OFFSET SET_NO_DAMAGE_DURING_STOP SET_BONUS_UPDATES_DISABLED'''.split()
assert len(NAMES)==184 and NAMES[95]=='SHOOT_FAN_AIMED' and NAMES[121]=='START_SPELL'
OPS={i+1:n for i,n in enumerate(NAMES)}; OPS[0]="DEFAULT_NOP_0"
VARS={**{10000+i:f'I{i}' for i in range(8)},**{10008+i:f'EI{i}' for i in range(8)},**{10016+i:f'F{i}' for i in range(8)},**{10024+i:f'EF{i}' for i in range(8)}}
VARS.update(dict(zip(range(10032,10101),'''RAND_NONNEG_INT RAND_UNIT_FLOAT RAND_RAW_INT RAND_SIGNED_UNIT EXTRA_I0 EXTRA_I1 EXTRA_I2 EXTRA_I3 DIFFICULTY RANK ENEMY_X ENEMY_Y ENEMY_Z PLAYER_X PLAYER_Y PLAYER_Z ANGLE_TO_PLAYER BOSS_TIMER DISTANCE_TO_PLAYER LIFE SHOT_TYPE CALL_I0 CALL_I1 CALL_I2 CALL_I3 CALL_F0 CALL_F1 CALL_F2 CALL_F3 SHARED_CALL_I0 SHARED_CALL_I1 SHARED_CALL_I2 SHARED_CALL_I3 SHARED_CALL_F0 SHARED_CALL_F1 SHARED_CALL_F2 SHARED_CALL_F3 MOVE_ANGLE ANGULAR_VELOCITY SPEED ACCELERATION ORBIT_RADIUS INTERP_ORIGIN_X INTERP_ORIGIN_Y INTERP_ORIGIN_Z ORBIT_ANGLE ORBIT_ANGULAR_VELOCITY INTERP_DELTA_X INTERP_DELTA_Y INTERP_DELTA_Z RAND_ANGLE LAST_DAMAGE BOSS_SLOT LAST_DISP_X LAST_DISP_Y LAST_DISP_Z LIFE_THRESHOLD_0 LIFE_THRESHOLD_1 LIFE_THRESHOLD_2 LIFE_THRESHOLD_3 ITEM_DROP_TYPE SCORE EXTRA_F0 EXTRA_F1 PARENT_CHAIN_DEPTH PLAYER_IS_YOUKAI TIME_ORB_STATE SPELL_CAPTURE_STATE SPELL_TIMER_FRAMES'''.split())))
EX='''ConfigureNightBlindness TriggerShortScreenPulse UpdateBouncingEnemyMotion StartNarrowBulletWarpBarrier WarpBulletsAcrossNarrowBarrier StopBulletWarpBarrier StartWideBulletWarpBarrier WarpBulletsAcrossWideBarrier SynchronizeOrbitingChildFormation UpdateNarrowRotatingLaserHitbox TriggerScreenPulseAndShake UpdateMediumRotatingLaserHitbox ReisenFreezeBullets ApplyRedBackgroundTint AdvanceReisenBulletPhase TriggerScreenShake TriggerChildrenNearMarkedBullets TriggerLongScreenPulse SetFrameRateDivisor PublishCurrentSpellCardNumber StartMediumBulletWarpBarrier WarpBulletsAcrossMediumBarrier MokouResurrection HideSpellCardPresentation PublishCapturedSpellCardCount UpdateWideRotatingLaserHitbox SetScriptedUpdateFreeze SpawnEnemiesFromMarkedBullets EnterScaledBulletTime ExitScaledBulletTime SetScreenEffectCounter SpawnBombOrExtendItem'''.split()
# Known, audited scalar schemas only; unknown payloads are explicitly dual-view dumps.
SCHEMA={1:'',2:'i',3:'',4:'ii',5:'iii',6:'ii',7:'ff',8:'ii',9:'ff',30:'i',31:'i',32:'ff',33:'ff',34:'fffff',37:'f',38:'ffff',39:'fffff',53:'',63:'fff',64:'iiff',65:'ff',66:'iiff',67:'iif',68:'ff',69:'iiff',70:'f',71:'f',75:'ffff',76:'',77:'ff',78:'ff',79:'i',80:'i',81:'i',82:'f',83:'i',105:'i',106:'i',107:'',108:'',109:'',110:'fff',111:'iiiiiff',112:'',113:'ii',114:'hhffffffiiiiiI',115:'hhffffffiiiiiI',116:'i',117:'if',118:'if',119:'ifff',120:'i',121:'i',123:'',124:'i',125:'i',126:'ii',127:'i',131:'i',132:'i',133:'iii',134:'ii',135:'ii',136:'ii',137:'ii',145:'i',146:'i',147:'i',148:'i',149:'i',150:'ii',151:'i',152:'ffiiii',153:'',154:'',155:'i',156:'i',159:'i',160:'i',161:'f',162:'',163:'i',164:'i',165:'fff',166:'ffff',167:'if',168:'i',169:'fff',170:'ii',171:'if',172:'iff',173:'i',175:'i',176:'',177:'i',179:'',180:'',181:'',182:'ifff',183:'i',184:'i'}
for op in range(10,15): SCHEMA[op]='ii'
for op in range(15,20): SCHEMA[op]='ff'
for op in range(20,25): SCHEMA[op]='iii'
for op in range(25,30): SCHEMA[op]='fff'
for op in range(40,52): SCHEMA[op]=('ii' if op%2==0 else 'ff')+'ii'
for op in range(96,105): SCHEMA[op]='hhiiffffI'
for op in (90,91,92): SCHEMA[op]='iffiii'
for op in (93,94): SCHEMA[op]='ifffiii'
SCHEMA[165]='f'
SCHEMA.update({52:'i',54:'i',55:'i',56:'iiiiii',57:'ii',58:'i',59:'i',60:'iiiiii',61:'ii',62:'',63:'ff',72:'ifffff',73:'ifff',74:'iff',110:'ff',128:'iffff',129:'i',130:'i',138:'i',139:'iii',140:'iiifff',141:'i',142:'i',143:'i',144:'ii',157:'iiii',158:'iiii',174:'i',178:'iif'})

def decode_text(b,key): return bytes(x^key for x in b).split(b'\0',1)[0].decode('cp932')
def read_ecl(path):
 b=Path(path).read_bytes();version,n,t=struct.unpack_from('<IHH',b); assert version==0x800
 ts=list(struct.unpack_from('<16I',b,8)); ss=list(struct.unpack_from('<'+str(n)+'I',b,72)); boundaries=sorted(set(ss+ts[:t]+[len(b)]));subs=[]
 assert len(set(ss))==len(ss)
 for sid,start in enumerate(ss):
  end=min(x for x in boundaries if x>start);p=start;ins=[]
  while p<end:
   time,op,size,res,mask,flags=struct.unpack_from('<ihhBBH',b,p)
   assert size>=12 and size%4==0 and p+size<=end and (0<=op<=184 or (op==-1 and time==-1 and p+size==end)),(path,sid,p,time,op,size,end)
   payload=b[p+12:p+size]; entry=dict(offset=p,relative=p-start,time=time,opcode=op,op=OPS.get(op,"END_SENTINEL"),size=size,mask=mask,flags=flags,payload=payload.hex())
   if op==122:
    face,num,bonus=struct.unpack_from('<hHi',payload)
    entry['spell']=dict(id=num,name=decode_text(payload[8:56],0xaa),owner=decode_text(payload[56:104],0xbb),bonus=bonus)
   if op in (136,137):
    idx=struct.unpack_from('<i',payload)[0]; entry['ex_id']=idx;entry['ex']=EX[idx] if 0<=idx<32 else 'NONE_OR_DYNAMIC'
   if op==111:
    k=struct.unpack_from('<iiiii ff',payload);entry['transform']=dict(index=k[0],kind=k[1],concurrent=k[2],int0=k[3],int1=k[4],float0=k[5],float1=k[6])
   ins.append(entry);p+=size
  assert p==end;subs.append(dict(id=sid,offset=start,end=end,instructions=ins))
 return dict(file=Path(path).name,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b),sub_count=n,timeline_count=t,timeline_offsets=ts[:t],subs=subs)
def operands(ins):
 b=bytes.fromhex(ins['payload']);op=ins['opcode'];schema=SCHEMA.get(op);flags=ins['flags']
 if op==122:return f"id={ins['spell']['id']} {ins['spell']['name']} owner={ins['spell']['owner']} bonus={ins['spell']['bonus']}"
 result=[]
 if schema is not None and struct.calcsize('<'+schema)==len(b):
  offset=0
  for ix,typ in enumerate(schema):
   value=struct.unpack_from('<'+typ,b,offset)[0];offset+=struct.calcsize(typ)
   if flags&(1<<ix) and int(value) in VARS: result.append('$'+VARS[int(value)])
   else: result.append(f'{value:.8g}' if typ=='f' else (hex(value) if typ=='I' else str(value)))
 else:
  for off in range(0,len(b),4):
   if off+4>len(b): result.append(b[off:].hex());break
   i=struct.unpack_from('<i',b,off)[0];f=struct.unpack_from('<f',b,off)[0]
   if flags&(1<<(off//4)) and i in VARS: result.append('$'+VARS[i])
   elif flags&(1<<(off//4)) and math.isfinite(f) and int(f) in VARS:result.append('$'+VARS[int(f)])
   elif i==0:result.append('0')
   else: result.append(f'{i}/f:{f:.7g}')
 if op in (136,137): result.append('['+ins['ex']+']')
 if op==4:result.append(f"->0x{ins['offset']+struct.unpack_from('<i',b,4)[0]:x}")
 if op==5:result.append(f"->0x{ins['offset']+struct.unpack_from('<i',b,4)[0]:x}")
 if 40<=op<=51:result.append(f"->0x{ins['offset']+struct.unpack_from('<i',b,12)[0]:x}")
 return ', '.join(result)
def dump(ecl,mask=8):
 lines=[f"{ecl['file']} sha256={ecl['sha256']}\nMask inclusion only (0x{mask:02x}); NOT a reachability claim.\nOffsets are in decrypted ECL; sub IDs are zero-based.\n"]
 for s in ecl['subs']:
  lines.append(f"\n=== sub {s['id']} @ 0x{s['offset']:05x}..0x{s['end']:05x} ===")
  for i in s['instructions']:
   if mask is not None and i['mask']&mask!=mask:continue
   lines.append(f"0x{i['offset']:05x} +{i['relative']:04x} t={i['time']:5} mask={i['mask']:02x} flags={i['flags']:04x} {i['op']}({operands(i)})")
 return '\n'.join(lines)+'\n'
def main():
 (ROOT/'reports'/'disassembly').mkdir(exist_ok=True)
 all_ecl=[];spellrows=[];stats=[];sh=[]
 for p in sorted((ROOT/'private_resources').glob('*.ecl')):
  e=read_ecl(p);all_ecl.append(e);(ROOT/'reports'/'disassembly'/(p.stem+'.txt')).write_text(dump(e),encoding='utf-8')
  ins=[i for s in e['subs'] for i in s['instructions'] if i['opcode']!=-1];lun=[i for i in ins if i['mask']&8]
  for s in e['subs']:
   for i in s['instructions']:
    if 'spell'in i:spellrows.append(dict(file=p.name,sub=s['id'],offset=f"0x{i['offset']:x}",mask=f"0x{i['mask']:02x}",**i['spell']))
  stats.append(dict(file=p.name,sub_count=e['sub_count'],instructions=len(ins),lunatic_mask_instructions=len(lun),shoot_sites=sum(96<=i['opcode']<=104 for i in lun),ex_sites=sum(i['opcode'] in (136,137) for i in lun),spell_records=sum(i['opcode']==122 for i in lun),opcode_hist=dict(collections.Counter(i['opcode'] for i in lun))))
 for p in sorted((ROOT/'private_resources').glob('*.sht')):
  b=p.read_bytes(); n=struct.unpack_from('<H',b,2)[0]
  sh.append(dict(file=p.name,bytes=len(b),levels=n,bombs=struct.unpack_from('<f',b,4)[0],deathbomb_window=struct.unpack_from('<i',b,8)[0],hurtbox_full_width=struct.unpack_from('<f',b,12)[0],normal_axis=struct.unpack_from('<f',b,36)[0],focused_axis=struct.unpack_from('<f',b,40)[0],normal_diagonal=struct.unpack_from('<f',b,44)[0],focused_diagonal=struct.unpack_from('<f',b,48)[0]))
 for name,obj in [('ecl_parsed',all_ecl),('legacy_mask8_ecl_inventory',stats),('legacy_mask8_spell_inventory',spellrows),('sht_parameters',sh)]:
  (ROOT/'reports'/(name+'.json')).write_text(json.dumps(obj,ensure_ascii=False,indent=2))
 print('ECL',len(all_ecl),'subs',sum(e['sub_count'] for e in all_ecl),'instructions',sum(s['instructions'] for s in stats),'spell records',len(spellrows));print(json.dumps(sh,indent=2))
 print('\nLunatic-mask spell records in main-stage files:')
 for s in spellrows:
  if s['file'] in ['ecldata1.ecl','ecldata2.ecl','ecldata3.ecl','ecldata4a.ecl','ecldata4b.ecl','ecldata5.ecl','ecldata6.ecl','ecldata7.ecl','ecldata8.ecl'] and int(s['mask'],16)&8:
   print(s)
if __name__=='__main__':main()
