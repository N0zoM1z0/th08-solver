#!/usr/bin/env python3
"""Full bounded extraction and per-member hashing; optional native LZSS accelerator."""
from pathlib import Path
import sys,ctypes,hashlib,json,time,collections
import unpack_dat
ROOT=Path(__file__).resolve().parent.parent
orig=unpack_dat.lzss
libname='lzss_fast.dll' if sys.platform=='win32' else 'liblzss_fast.dylib' if sys.platform=='darwin' else 'liblzss_fast.so'
candidates=[ROOT/'build'/libname,ROOT/'build/Release'/libname,ROOT/'native'/libname]
libpath=next((p for p in candidates if p.exists()),candidates[-1])
if libpath.exists():
 lib=ctypes.CDLL(str(libpath));fn=lib.th08_lzss
 fn.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_void_p,ctypes.c_size_t];fn.restype=ctypes.c_int
 def fast(data,expected):
  if not 0<=expected<=256*1024*1024:raise ValueError('invalid output bound')
  out=ctypes.create_string_buffer(expected);err=fn(data,len(data),out,expected)
  if err:raise ValueError(f'LZSS error {err}')
  return out.raw
 unpack_dat.lzss=fast
else:print('Native LZSS unavailable: using slower Python reference.',flush=True)

def run(path):
 t=time.perf_counter();data,entries,meta=unpack_dat.read_archive(path)
 out=ROOT/'private_resources';out.mkdir(exist_ok=True)
 # Cross-check both implementations on all ECL, SHT, and small metadata.
 differential=[]
 for e in entries:
  name=e['name']
  if Path(name).name!=name or '\\' in name or '/' in name:raise ValueError('unsafe resource name')
  compressed=data[e['offset']:e['offset']+e['compressed_size']]
  decoded=unpack_dat.lzss(compressed,e['packed_decoded_size'])
  if name.endswith(('.ecl','.sht','.ver')):
   assert decoded==orig(compressed,e['packed_decoded_size']),name;differential.append(name)
  plain=unpack_dat.content_decrypt(decoded)
  (out/name).write_bytes(plain)
  e.update(decoded_size=len(plain),sha256=hashlib.sha256(plain).hexdigest())
 meta.update(extraction_seconds=time.perf_counter()-t,all_members_hashed=True,decoder_differential_files=differential)
 r=ROOT/'reports';r.mkdir(exist_ok=True)
 (r/'archive_manifest.json').write_text(json.dumps({'archive':meta,'entries':entries},ensure_ascii=False,indent=2),encoding='utf8')
 print(json.dumps(meta,ensure_ascii=False,indent=2));print(dict(collections.Counter(Path(e['name']).suffix for e in entries)))
if __name__=='__main__':run(Path(sys.argv[1]))
