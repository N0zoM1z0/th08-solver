#!/usr/bin/env python3
"""Bounded TH08 PBGZ reader derived from the supplied reconstruction source.
Only user-supplied game data is read. Output sizes, offsets and names are validated.
"""
from pathlib import Path
import struct, hashlib, json, argparse
PARAMS=[(0x5d,0x1b,0x37,0x40,0x2800),(0x74,0x51,0xe9,0x40,0x3000),(0x71,0xc1,0x51,0x1400,0x2000),(0x8a,3,0x19,0x1400,0x7800),(0x95,0xab,0xcd,0x200,0x1000),(0xb7,0x12,0x34,0x400,0x2800),(0x9d,0x35,0x97,0x80,0x2800),(0xaa,0x99,0x37,0x400,0x1000)]
def decrypt(data, key, inc, chunk, limit):
    size=len(data); tail=(size%chunk if size%chunk<chunk//4 else 0)+(size&1)
    remaining=size-tail; pos=0; out=bytearray(data)
    while remaining>0 and limit>0:
        chunk=min(chunk,remaining)
        dest=list(range(pos+chunk-1,pos-1,-2))+list(range(pos+chunk-2,pos-1,-2))
        assert len(dest)==chunk
        for j in dest:
            out[j]=data[pos]^key; key=(key+inc)&255; pos+=1
        remaining-=chunk; limit-=chunk
    return bytes(out)
def lzss(data,expected):
    if not 0<=expected<=256*1024*1024: raise ValueError('Unreasonable output size')
    dictionary=bytearray(8192); initialized=bytearray(8192); wp=1; bit=0; out=bytearray()
    def take(n):
        nonlocal bit
        if bit+n>len(data)*8+16 or (bit+n>len(data)*8 and len(out)!=expected): raise ValueError(f'Truncated LZSS stream: output {len(out)}/{expected}')
        v=0
        for _ in range(n):
            v=(v<<1)|(((data[bit>>3]>>(7-(bit&7)))&1) if bit<len(data)*8 else 0); bit+=1
        return v
    while True:
        if take(1):
            v=take(8); out.append(v); dictionary[wp]=v; initialized[wp]=1; wp=(wp+1)&8191
        else:
            off=take(13)
            if off==0: break
            count=take(4)+3
            for i in range(count):
                p=(off+i)&8191
                if not initialized[p]: raise ValueError('Read before dictionary initialization')
                v=dictionary[p]; out.append(v); dictionary[wp]=v; initialized[wp]=1; wp=(wp+1)&8191
        if len(out)>expected: raise ValueError('LZSS length overflow')
    if len(out)!=expected: raise ValueError(f'Output size {len(out)} != {expected}')
    return bytes(out)
def content_decrypt(data):
    if data[:3]!=b'edz': return data
    for i,(marker,k,inc,chunk,lim) in enumerate(PARAMS):
        if data[3]==marker-(i<<4)-0x10: return decrypt(data[4:],k,inc,chunk,lim)
    raise ValueError('Unknown encryption marker')
def read_archive(path):
    data=Path(path).read_bytes()
    if data[:4]!=b'PBGZ': raise ValueError('Not PBGZ')
    a,b,c=struct.unpack('<III',decrypt(data[4:16],0x1b,0x37,12,0x400))
    count=a-123456; table_off=b-345678; table_size=c-567891
    assert 0<count<100000 and 16<=table_off<len(data)
    table=lzss(decrypt(data[table_off:],0x3e,0x9b,0x80,0x400),table_size)
    entries=[]; p=0
    for i in range(count):
        end=table.index(0,p); name=table[p:end].decode('cp932'); p=end+1
        offset,size,meta=struct.unpack_from('<III',table,p); p+=12
        if Path(name).name!=name or name in ('.','..'): raise ValueError('Unsafe name')
        entries.append(dict(name=name,offset=offset,packed_decoded_size=size,metadata=meta))
    assert not any(table[p:]), 'Nonzero unparsed table tail'
    for i,e in enumerate(entries):
        e['compressed_size']=(entries[i+1]['offset'] if i+1<count else table_off)-e['offset']
        assert 16<=e['offset']<table_off and e['compressed_size']>0
    return data,entries,dict(sha256=hashlib.sha256(data).hexdigest(),file_size=len(data),entry_count=count,table_offset=table_off,table_size=table_size)
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('archive',type=Path); ap.add_argument('output',type=Path); ap.add_argument('--all',action='store_true'); args=ap.parse_args()
    data,entries,meta=read_archive(args.archive); args.output.mkdir(parents=True,exist_ok=True)
    wanted={'.ecl','.sht','.std','.txt','.dat'}
    for e in entries:
        if args.all or Path(e['name']).suffix.lower() in wanted:
            packed=lzss(data[e['offset']:e['offset']+e['compressed_size']],e['packed_decoded_size'])
            out=content_decrypt(packed)
            (args.output/e['name']).write_bytes(out)
            e.update(decoded_size=len(out),sha256=hashlib.sha256(out).hexdigest())
    (args.output.parent/'reports').mkdir(exist_ok=True)
    (args.output.parent/'reports'/'archive_manifest.json').write_text(json.dumps(dict(archive=meta,entries=entries),indent=2,ensure_ascii=False))
    from collections import Counter
    print(json.dumps(meta,indent=2)); print(Counter(Path(e['name']).suffix for e in entries)); print('\n'.join(f"{e['name']} {e.get('decoded_size','not extracted')}" for e in entries if 'decoded_size' in e))
if __name__=='__main__': main()
