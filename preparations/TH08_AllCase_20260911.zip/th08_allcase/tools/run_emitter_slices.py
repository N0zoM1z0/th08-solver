#!/usr/bin/env python3
"""Execute audited ECL emitter *slices*, not the full game.
Supported: local arithmetic, constant/caller-supplied external reads, jumps,
secondary wait, transform-descriptor writes and emission-request logging.
No movement, collision, ANM execution, pool saturation, damage, sound/effect RNG,
or Windows input. A supplied random-value tape is NOT a game RNG replay.
Unknown executed opcodes fail closed. Time multiplier fixed to one.
Float writes round to f32; x87 exactness is NOT claimed.
"""
from pathlib import Path
import struct,math,json,collections
from analyze_ecl import read_ecl,SCHEMA,VARS
ROOT=Path(__file__).resolve().parent.parent
f32=lambda x:struct.unpack('<f',struct.pack('<f',x))[0]
class Slice:
 def __init__(self,ecl,sid,mask=8,externals=None):
  self.ecl=ecl;self.sid=sid;sub=ecl['subs'][sid];self.pc=sub['offset'];self.ins={i['offset']:i for i in sub['instructions']};self.time=0;self.wait=0;self.done=False;self.vars={};self.external=externals or {};self.mask=mask;self.transforms={};self.events=[];self.executed=0;self.random_reads=0;self.tick=0
 def get(self,key,typ):
  if key in self.external:
   x=self.external[key];v=x(self.tick) if callable(x) else x
   if key in (10032,10033,10034,10035,10082):self.random_reads+=1
  elif key in self.vars:v=self.vars[key]
  elif (10000<=key<=10031 or 10036<=key<=10039 or 10053<=key<=10068 or 10094<=key<=10095):v=0
  else:raise ValueError(f'Unspecified external selector {key} at {self.pc:#x}')
  return f32(v) if typ=='f' else int(v)
 def arg(self,i,ix,typ='i',resolve=True):
  b=bytes.fromhex(i['payload']);v=struct.unpack_from('<'+typ,b,4*ix)[0]
  return self.get(int(v),typ) if resolve and i['flags']&(1<<ix) and int(v) in VARS else v
 def write(self,i,ix,v,typ):
  key=int(self.arg(i,ix,typ,False))
  if not i['flags']&(1<<ix) or key not in VARS:raise ValueError('Unsupported write into bytecode')
  self.vars[key]=f32(v) if typ=='f' else int(v)
 def step(self,tick):
  self.tick=tick
  for _ in range(10000):
   if self.done:return
   if self.wait>0:self.wait-=1;self.time-=1;break
   i=self.ins[self.pc]
   if i['time']!=self.time:break
   nxt=self.pc+i['size'];op=i['opcode']
   if i['mask']&self.mask!=self.mask:self.pc=nxt;continue
   self.executed+=1
   if op in (0,3):pass
   elif op in (1,53):self.done=True;return
   elif op==2:self.wait=self.arg(i,0)
   elif op in (4,5):
    take=True
    if op==5:
     v=self.arg(i,2)-1;self.write(i,2,v,'i');take=v>0
    if take:self.time=self.arg(i,0,resolve=False);nxt=self.pc+self.arg(i,1,resolve=False)
   elif 40<=op<=51:
    typ='i' if op%2==0 else 'f';a=self.arg(i,0,typ);b=self.arg(i,1,typ)
    take=[a==b,a!=b,a<b,a<=b,a>b,a>=b][(op-40)//2]
    if take:self.time=self.arg(i,2,resolve=False);nxt=self.pc+self.arg(i,3,resolve=False)
   elif op in (6,7):
    typ='i' if op==6 else'f';self.write(i,0,self.arg(i,1,typ),typ)
   elif 10<=op<=29:
    typ='i' if op<15 or 20<=op<25 else'f'
    if op<20:a=self.arg(i,0,typ);b=self.arg(i,1,typ);k=(op-10)%5
    else:a=self.arg(i,1,typ);b=self.arg(i,2,typ);k=(op-20)%5
    if k==0:v=a+b
    elif k==1:v=a-b
    elif k==2:v=a*b
    elif k==3:v=(int(a/b) if typ=='i' else a/b)
    else:v=(a-int(a/b)*b if typ=='i' else math.fmod(a,b))
    self.write(i,0,v,typ)
   elif op in (30,31):self.write(i,0,self.arg(i,0)+(1 if op==30 else -1),'i')
   elif op in (32,33):self.write(i,0,(math.sin if op==32 else math.cos)(self.arg(i,1,'f')),'f')
   elif op==37:
    v=self.arg(i,0,'f')
    while v>math.pi:v-=2*math.pi
    while v<-math.pi:v+=2*math.pi
    self.write(i,0,v,'f')
   elif op==111:
    vals=[self.arg(i,k,'i' if k<5 else 'f') for k in range(7)];self.transforms[vals[0]]=vals[1:]
   elif 96<=op<=104:
    raw=struct.unpack('<hhiiffffI',bytes.fromhex(i['payload']));v=[]
    for k,x in enumerate(raw):
     typ='f' if 4<=k<=7 else'i'
     v.append(self.get(int(x),typ) if k<8 and i['flags']&(1<<k) and int(x) in VARS else x)
    self.events.append(dict(tick=tick,local_time=self.time,pc=f'{i["offset"]:#x}',opcode=op,args=v,requested_bullets=v[2]*v[3],transforms=dict(self.transforms)))
   else:raise ValueError(f'Unsupported executed {i["op"]} in sub{self.sid} at{self.pc:#x}')
   self.pc=nxt
  else:raise ValueError('Instruction cap exceeded')
  self.time+=1
 def run(self,ticks):
  for t in range(ticks):
   self.step(t)
   if self.done:break
  batches=collections.Counter(e['tick'] for e in self.events)
  return dict(file=self.ecl['file'],sub=self.sid,mask=hex(self.mask),ticks_requested=ticks,return_tick=t if self.done else None,executed_instructions=self.executed,emission_commands=len(self.events),emission_ticks=len(batches),requested_bullets=sum(e['requested_bullets'] for e in self.events),max_commands_per_tick=max(batches.values(),default=0),random_external_reads=self.random_reads,first_ticks=list(batches)[:12],last_tick=self.events[-1]['tick'] if self.events else None,events=self.events)
def main():
 specs=[('firefly_40','ecldata1.ecl',40,8,400,{}),('firefly_41','ecldata1.ecl',41,8,400,{}),('familiar_human','ecldata1.ecl',42,0x28,120,{}),('familiar_youkai','ecldata1.ecl',42,0x48,120,{}),('barrier_a','ecldata4a.ecl',49,8,180,{10077:0.0}),('barrier_b','ecldata4a.ecl',50,8,180,{10077:0.0}),('double_spark_background','ecldata4b.ecl',56,8,144,{10082:0.0}),('rising_ring_a','ecldata6.ecl',57,8,120,{10082:0.0}),('rising_ring_b','ecldata6.ecl',58,8,120,{10082:0.0}),('rising_ring_c','ecldata6.ecl',59,8,120,{10082:0.0})]
 results={}
 for name,file,sid,mask,ticks,external in specs:
  vm=Slice(read_ecl(ROOT/'private_resources'/file),sid,mask,external);r=vm.run(ticks);r['external_fixture_values']=external;results[name]=r;print(name,{k:v for k,v in r.items() if k!='events'})
 assert results['firefly_40']['requested_bullets']==840 and results['firefly_40']['return_tick']==360
 assert results['firefly_41']['requested_bullets']==840 and results['firefly_41']['return_tick']==360
 assert results['familiar_human']['requested_bullets']==30 and results['familiar_youkai']['requested_bullets']==6
 assert results['double_spark_background']['requested_bullets']==180
 assert sum(results[k]['requested_bullets'] for k in ('rising_ring_a','rising_ring_b','rising_ring_c'))==351
 (ROOT/'reports'/'emitter_slice_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
