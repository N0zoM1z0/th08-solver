#!/usr/bin/env python3
"""Generate the bounded emitter benchmark from the actual decoded sub40 bytecode."""
import struct
from pathlib import Path
from analyze_ecl import read_ecl
ROOT=Path(__file__).resolve().parent.parent
ins=read_ecl(ROOT/'private_resources/ecldata1.ecl')['subs'][40]['instructions'];by={i['offset']:k for k,i in enumerate(ins)};rows=[]
for i in ins:
 p=bytes.fromhex(i['payload']);u=list(struct.unpack('<'+str(len(p)//4)+'I',p));assert len(u)<=8;u+=[0]*(8-len(u))
 target=by[i['offset']+struct.unpack_from('<i',p,4)[0]] if i['opcode']==5 else-1
 rows.append('{'+','.join(map(str,[i['time'],i['opcode'],i['mask'],i['flags'],target]))+', {'+','.join(hex(x)+'u' for x in u)+'}}')
(ROOT/'tools/emitter_fixture.hpp').write_text('// Generated from decoded ecldata1.ecl sub40.\nstatic const std::array<Ins,'+str(len(ins))+'> code={{\n'+',\n'.join(rows)+'\n}};\n')
