#!/usr/bin/env python3
"""Try EVERY subprogram under 5 runtime difficulty masks x 3 alignment overrides.
This is an explicitly restricted interpreter. Missing caller state, unknown
semantics and nontermination remain visible; they never become zero-cost NOPs.
"""
import json,collections,time
from pathlib import Path
from run_emitter_slices import Slice
from analyze_ecl import read_ecl
ROOT=Path(__file__).resolve().parent.parent
class StrictSlice(Slice):
 def get(self,key,typ):
  if key not in self.vars and key not in self.external:
   raise ValueError(f'REQUIRES_CONTEXT selector {key} at {self.pc:#x}')
  return super().get(key,typ)
def main():
 rows=[];schedules={};t=time.perf_counter()
 for p in sorted((ROOT/'private_resources').glob('*.ecl')):
  ecl=read_ecl(p)
  for sub in ecl['subs']:
   for bit in [1,2,4,8,15]:
    for form in [0,0x20,0x40]:
     vm=StrictSlice(ecl,sub['id'],bit|form,{})
     r=dict(file=p.name,sub=sub['id'],difficulty_mask=bit,alignment_override=form)
     try:
      result=vm.run(360)
      r.update(status='RETURNED' if vm.done else 'BOUNDED_PREFIX',ticks=vm.tick,executed=vm.executed,commands=len(vm.events),requested=sum(x['requested_bullets'] for x in vm.events))
      if vm.events:schedules[f'{p.stem}:{sub["id"]}:{bit|form}']=result
     except (ValueError,KeyError,ZeroDivisionError,OverflowError) as ex:
      why=str(ex);r.update(status='REQUIRES_CONTEXT' if 'REQUIRES_CONTEXT' in why else 'UNSUPPORTED_OR_INVALID',first_blocker=why,pc=hex(vm.pc),executed=vm.executed,commands_before_blocker=len(vm.events))
     rows.append(r)
 counts=collections.Counter(r['status'] for r in rows)
 summary=dict(attempts=len(rows),unique_subprograms=len({(r['file'],r['sub']) for r in rows}),max_ticks=360,runtime_difficulty_masks=[1,2,4,8,15],alignment_overrides=[0,32,64],status_counts=counts,strict_no_default_external_values=True,successful_emitter_variants=len(schedules),elapsed_seconds=time.perf_counter()-t,scope='restricted scalar emitter slices only; NO complete ECL/world simulation')
 (ROOT/'reports/slice_coverage.json').write_text(json.dumps(dict(summary=summary,attempts=rows),ensure_ascii=False,indent=2))
 (ROOT/'reports/compiled_slice_schedules.json').write_text(json.dumps(schedules,ensure_ascii=False,separators=(',',':')))
 print(json.dumps(summary,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
