# 上机接入：从可复现模块到原版控制器

## 1. 本次已打通的位置

可以直接运行全资源分析和原生实验。可以针对固定源码检查点生成只读记录补丁，编译Player、Global、EclRun三个真实翻译单元的副本。这个步骤已经实际执行成功。

还没有打通的是：完整原版状态转移的可分叉适配器、完整全局状态的无副作用快照、正常设备输入提交器、原版与重构器的全阶段差分、完整成功路线。这里逐一给出接线位置和验收条件，不用占位函数冒充已实现。

## 2. 在独立worktree应用记录补丁

首先固定自己的EXE、DAT哈希，记录源码HEAD、dirty diff、编译选项、机体、难度、练习/正常/回放模式。对于本次DAT，主README有精确哈希。原版EXE本次没有运行，因此不要把包内native测试结果登记为原版成绩。

```sh
# 在已有仓库中，建立独立工作区；不改变原工作分支。
git worktree add --detach ../th08-allcase-probe a45e99fb1942714e6edded20847e32a654d56f97

# 在实验包中生成副本和patch。
python tools/instrument_repo.py --repo /path/to/th08-allcase-probe --out /tmp/th08-allcase-trace

# 再在独立工作区中检查、应用。
git -C /path/to/th08-allcase-probe apply --check --ignore-whitespace /tmp/th08-allcase-trace/trace.patch
git -C /path/to/th08-allcase-probe apply --ignore-whitespace /tmp/th08-allcase-trace/trace.patch
```

源文件哈希不匹配时脚本拒绝。此时应审阅新版的函数入口和字段，不应删除哈希检查直接强行使用。

采用仓库本身的modern Linux构建流程编译这个独立工作区。运行时设置：

```sh
export TH08_ALLCASE_TRACE=/absolute/path/run-a.jsonl
# 然后按仓库自己的运行脚本启动自己有资源的游戏实例。
```

记录器只读参数，不改位置、速度、敌人、RNG、判定或按键。它使用文件IO和互斥锁，**会扰动运行时间，因此只用于离线正确性检查，不用于声称实时性能。** 退出应正常关闭，以写入尾记录。强杀、超过200万条、文件截断都会使比较器拒绝“通过”。

记录粒度：`Chain::RunCalcChain`调用计数、`Player::OnUpdate`入口可见按键和玩家状态、普通弹/敌人/擦弹/激光判定调用参数、通过掩码后的ECL指令位置。循环链的restart/execute-again仍是同一次链调用内的序列，不擅自变成新游戏帧。

局限：不包含所有实体的generation、所有字段、RNG取数、子弹分配成败或完整事件副作用；不是WorldSnapshot。ECL指令序列只是其中一条观测通道。需要进一步在Spawn/Deactivate、DispatchShotInstruction门槛、RNG、ANM和各EX入口补齐事件后，才能进行完整世界差分。

## 3. 比较器的使用与“通过”的含义

```sh
python tools/trace_compare.py run-a.jsonl run-b.jsonl
```

成功只返回`FIELDS_MATCH_ONLY`。这是刻意的名字：它说明两个完整、未丢记录的调用序列在已记录字段上相同，不是整个游戏等价。不同长度、缺尾、丢记录或首个浮点位差异均被报告，不会只比较公共前缀。

每次调用流应附独立运行清单，确认EXE/DAT/source/input identity相同；记录器当前header不是这些身份的独立证明。原版和重构器的对应还需建立统一逻辑阶段，不能直接按进程墙钟对齐。

## 4. 完整世界适配器应包含的状态

必须按逻辑字段导出，不序列化进程指针当成跨机器身份。至少包括：

| 系统 | 不能省略的内容 |
|---|---|
| 玩家 | 位置、速度参数、实际形态、focus状态、过渡计数、无敌/死亡、hurtbox与碰撞区域、射击/子机/持续弹状态 |
| ECL | 主/子/栈上下文的PC、sub、整数/浮点变量、extra/call变量、time的current/previous/subFrame、secondaryTime、插值槽、逐帧callback |
| 敌人 | 槽位+generation、出生/本帧已更新信息、position/worldPosition/父链/远程目标、movement、life、damage、shot门槛、pendingShotInstruction、动画VM及阶段callback |
| 弹丸 | 槽位+generation、state、位置/速度/angle/speed、21类模板关联、碰撞开关、timer、transformFlags/activeFlags/index/records、共享状态槽、sprite/ANM、消弹及离屏状态 |
| 激光 | 池内状态机全部字段；另加直接EX判定所依赖的敌人位置/动画角/计时器 |
| 全局 | RNG seed及计数、rank/subrank/gauge/捕获计数、时间倍率与forceExtraTimerStep、freeze、当前阶段/消息/事件门槛、资源与程序身份 |
| 输入 | 观测所处阶段、已采样/已提交/不可撤回队列、实际消费帧，正常与replay分别标记 |

敌人出生时立即执行ECL，以及本帧对象池遍历是否还会再次经过新槽位，必须保留。不能仅保存“一张活跃对象列表”然后任意排序。

## 5. 参考执行器与优化预测器的分工

参考执行器应复用源码语义：同一输入完整推进、记录事件；主要承担离线对照和少量候选的准入测试。不能默认把它放进每个在线搜索节点。

优化预测器读取已验证的快照，输出带依赖契约的危险块。每个块携带root epoch、来源实体generation、所依赖控制器、时间区间、条件参数、RNG/形态/阶段版本。失效按读写依赖传播，不因无关得分变化清空全部旧弹轨迹。

对EX12，包内只有弹丸局部状态转移；附着使魔的FORCE_PAUSE和背景interrupt必须由世界适配器处理。EX28/29同理，局部速度算子不包含完整全局时钟与ANM副作用。任何缺失字段都不能以默认0或空callback替代。

## 6. 输入提交不要接错位置

固定源码中，计算链重要优先级为：replay playback 6，Player 9，Enemy 11，Bullet 14，replay record 17。记录模式和回放模式不具有相同输入交接位置。

原版正常输入控制器应读取实际设备输入消费时序，先推进已经不可撤回的输入，再选择可改的后缀。把`g_GuiMessageInputCurrent`在Player之前直接覆盖，属于另一种控制接口；不能当成正常设备输入延迟的证据。

本包没有提供直接内存改写原版按键的DLL，也没有提供原版进程位置/判定/RNG修改器。`trace_plan`输出的是动作CSV；把它接到原版输入设备前，必须先完成正常输入消费帧的测量和合法按键映射。

## 7. 上机验收顺序与失败诊断

第一组：一面sub0的连续反馈、Wriggle sub40/sub42的共享与形态分支，核对时钟、发射请求/实际生成、输入消费。

第二组：铃仙EX12/14、三种结界、普通/直接EX激光、16×1024参数的敌人柱状判定，核对致死生效、离散映射和几何调用。

第三组：Rising递归、玉枝异步再瞄准、咲夜标记弹转敌人、妖梦缩时、Blazing Star移动激光原点，核对RNG/slot/生成时序/强耦合分支。

最后以全量来源清单驱动覆盖，而不是止步于这几例：逐来源记录所有动态首次经过的opcode、EX、变换、阶段边和输入模式。没有命中的分支继续保留未覆盖；已出现在静态数据不等于动态测试已经过。

每条路线只有同时满足“模型对照一致、按键真实消费、整条链不超时、没有命中/炸弹/续关违规、阶段出口可继续”才升级。失败时保存第一分歧字段，而不是只保存死亡画面。

性能的计时必须包住状态读取、预测、分支构建、搜索、独立复核、对象清理、输入提交。当前C++外层计时已经纳入内部搜索容器清理；尚未包含游戏读取/输入/参考世界推进。轮询8ms不代表操作系统硬实时8ms。
