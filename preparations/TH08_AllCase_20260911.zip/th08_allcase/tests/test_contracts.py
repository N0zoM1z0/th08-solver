import json,tempfile,unittest,sys, pathlib
ROOT=pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'tools'))
from trace_compare import compare
class TraceContracts(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.root=pathlib.Path(self.tmp.name)
 def tearDown(self):self.tmp.cleanup()
 def make(self,name,body,drop=0,footer=True):
  p=self.root/name;rows=[{'kind':'header','schema':1},*body]
  if footer:rows.append({'kind':'end','rows':len(body),'dropped':drop})
  p.write_text('\n'.join(json.dumps(r) for r in rows)+'\n');return p
 def test_match(self):
  p=self.make('a',[{'kind':'frame','tick':1,'seq':0}]);self.assertEqual(compare(p,p)['status'],'FIELDS_MATCH_ONLY')
 def test_missing_footer(self):
  p=self.make('a',[],footer=False);self.assertEqual(compare(p,p)['status'],'INVALID_TRACE')
 def test_drops(self):
  p=self.make('a',[],drop=1);self.assertEqual(compare(p,p)['status'],'INVALID_TRACE')
 def test_different_length(self):
  p=self.make('a',[]);q=self.make('b',[{'kind':'frame','tick':1}]);self.assertEqual(compare(p,q)['status'],'DIVERGED')
 def test_first_field(self):
  p=self.make('a',[{'kind':'bullet','tick':1,'seq':2,'p':[1,2]}]);q=self.make('b',[{'kind':'bullet','tick':1,'seq':2,'p':[1,3]}]);r=compare(p,q);self.assertEqual(r['first_divergence']['field'],'.p[1]')
 def test_trailing_data(self):
  p=self.make('a',[]);p.write_text(p.read_text()+'{}\n');self.assertEqual(compare(p,p)['status'],'INVALID_TRACE')
class CorpusContracts(unittest.TestCase):
 def test_corpus(self):
  p=ROOT/'reports/allcase_coverage.json'
  if not p.exists():self.skipTest('run resource audit first')
  r=json.loads(p.read_text());self.assertEqual(r['missing_spell_ids'],[]);self.assertEqual(r['unique_spell_ids'],222);self.assertEqual(r['schema_errors'],[]);self.assertEqual(r['full_spell_solutions_verified'],0)
 def test_extra_mask(self):
  from atlas import closure
  edges=[{'source':0,'target':1,'kind':'call','mask':8},{'source':0,'target':2,'kind':'call','mask':255}]
  self.assertEqual(closure(0,edges,15)[0],[0,2]);self.assertEqual(closure(0,edges,8)[0],[0,1,2])
if __name__=='__main__':unittest.main()
