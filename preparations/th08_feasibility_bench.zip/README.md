# TH08 source-guided feasibility: geometry microbenchmark

This is a **standalone synthetic geometry microbenchmark**, not a TH08 emulator,
not extracted retail ECL, and not an autoplay or NMNB result. It accompanies the
source-level architecture analysis in the conversation.

## Measured setup

- Linux container reporting AMD EPYC 9V74; single-threaded executable.
- GCC 14.2.0, C++17, `-O3 -DNDEBUG -ffp-contract=off`.
- 1,536 synthetic bullets, a 96-step forecast, 256 candidate point sequences.
- Three warm-ups, 15 measured runs per kernel and scene.
- Table values are milliseconds per complete synthetic workload, **not per game frame**.
- Input generation and initial buffer allocation are excluded. Copying the initial
  compact bullet state, forecasting, rebuilding indices, and all collision queries
  are included in the corresponding kernels. Buffers are reused between runs.
- Candidate trajectories are predefined. There is no search, beam expansion, ECL
  interpretation, real player movement, Windows input, or reference-game validation.
- Every kernel returns collision counts at **all 24,576 candidate/time points**,
  including after an earlier collision; all count vectors are checked for exact
  equality before measuring. This is not a speed comparison against an optimized
  survival planner that discards dead candidates early.
- p95 is the empirical nearest-rank statistic. With only 15 samples it is the sample
  maximum, not evidence about real-time tail latency or worst-case execution time.

## Workloads

1. `uniform_linear`: synthetic fixed-velocity field.
2. `uniform_polar`: synthetic polar acceleration with a permanently active transform,
   fixed multiplier 1, and standard C++ trigonometry. This is **not** TH08 floating-point
   equivalence and does not implement transform expiry or combination.
3. `narrow_warp`: the narrow-barrier position/velocity/cooldown rule inspired directly
   by `src/EclExIns.cpp::WarpBulletsAcrossNarrowBarrier`, followed by translation.
   The rest of the game's update pipeline, sprite state, angle bookkeeping, culling,
   timers, transforms, and other callbacks are deliberately absent.
4. `concentrated_static`: bullets and queries concentrated in one small region.
   Many collisions occur; a real survival planner could prune many queries earlier.
5. `same_bucket_nearmiss`: all bullets and queries share a coarse grid bucket but
   their exact boxes never overlap the query points. This exposes bucket occupancy
   degradation even when there are no collisions to enable early termination.

The last two point sequences are geometric stress tests, not valid player inputs.
All worlds are autonomous: their bullet geometry does not depend on a candidate.
Sharing this forecast would be WRONG for candidate-dependent aiming, kills, form,
RNG consumption, or any other relevant state that the benchmark omits.

## Kernels

- `recompute`: copies and re-integrates the synthetic world for each candidate,
  and tests every bullet at every time step.
- `shared_scan`: integrates once, but still performs all pairwise collision tests.
- `shared_grid`: integrates once, builds 16-unit spatial buckets by inserting each
  expanded AABB into every intersected bucket, and performs exact tests in one bucket.
- `shared_microtiles`: also builds conservative 2-unit occupancy bitsets. Empty
  microtiles safely skip all exact checks; occupied microtiles still use exact bucket
  checks. It preserves all collision counts; it never treats a blocked tile alone
  as proof of actual point collision. The extra construction cost can make ordinary
  cases SLOWER. This is evidence for adaptive use, not always enabling the filter.

## Reproduce

```sh
g++ -std=c++17 -O3 -DNDEBUG -ffp-contract=off geometry_bench.cpp -o geometry_bench
./geometry_bench 15 > geometry_results.csv
```

With a recent MSVC developer shell:

```bat
cl /std:c++17 /O2 /EHsc /fp:precise geometry_bench.cpp /Fe:geometry_bench.exe
geometry_bench.exe 15 > windows_geometry_results.csv
```

The Windows command is provided for reproduction and **has not been run here**.
Different compilers, CPUs, workloads and load conditions may change results.
The source needs no game assets or external libraries.

## Narrow interpretation of results

The measurements show that sharing deterministic work AND limiting collision queries
can put this isolated workload into a few milliseconds on this container. They also
show coarse bucket degeneration and an occupancy-filter tradeoff. They do NOT measure
full TH08 forward-model cost, a candidate-dependent event tree, RNG/animation/damage
semantics, online search quality, operating-system input latency, or Windows NMNB.

## Primary source files inspected

Only the user-specified N0zoM1z0/th08 repository was read. Relevant paths include:

- `src/BulletManager.cpp` and `src/BulletManager.hpp`
- `src/EclRun.cpp`, `src/EclRunHigh.inl`, `src/EclDependencies.cpp`
- `src/EclExIns.cpp`, `src/EclOperandsFloat.cpp`
- `src/EnemyManager.cpp`, `src/EnemyManagerUpdate.cpp`
- `src/Player.cpp`, `src/AnmManager.cpp`, `src/EffectManager.cpp`
- `src/ReplayManager.cpp`, `src/Global.hpp`, `src/Supervisor.cpp`

The current-session reads used GitHub `main`; they were not compared against the
original Windows executable. Retail stage data was not available for this experiment.

## Causality counterexample

`python causal_fixture.py` runs a tiny one-shot fixture with chosen parameters
and a two-tick input queue. It checks that a candidate which shifts early and
then stops is falsely judged safe under a frozen, stationary-player future,
but gets hit when the shot targets that candidate's actual position. A policy
that moves through the sampling event and continues moving survives the fixture.
This is a constructed dependency test, **not** a solved retail spellcard.
