// Standalone geometry microbenchmark. NOT a TH08 emulator or an autoplay solver.
// The synthetic worlds below are autonomous: every candidate sees the SAME
// future. This sharing is invalid for candidate-dependent aiming, deaths, RNG,
// form changes, or other unmodelled game events.
// Build: g++ -std=c++17 -O3 -DNDEBUG -ffp-contract=off geometry_bench.cpp -o geometry_bench
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>

constexpr int B=1536, H=96, M=256;
constexpr int NX=24, NY=28, CELLS=NX*NY; // 16-unit spatial buckets
constexpr float W=384.0f, HEIGHT=448.0f, CELL=16.0f;
constexpr float PI=3.14159265358979323846f;
struct Vec {float x,y;};
struct Bullet {float x,y,vx,vy,hx,hy,speed,angle; int cooldown=0;};
struct Box {float lo_x,hi_x,lo_y,hi_y;};
struct Entry {int id,next;};
constexpr int FNX=192,FNY=224,FWORDS=FNX/64;
struct Frame {
 std::array<int,CELLS> heads; std::vector<Entry> entries;
 std::array<uint64_t,FNY*FWORDS> occupied{}; // conservative 2-unit microtiles
};
struct Work {
 std::vector<Bullet> state;
 std::vector<Box> boxes;
 std::vector<Frame> index;
 std::vector<uint32_t> counts;
 Work(): state(B),boxes(H*B),index(H),counts(M*H) {
  for(auto& f:index) f.entries.reserve(B*9);
 }
};
volatile uint64_t sink=0;
float ur(std::mt19937& r,float lo,float hi){return std::uniform_real_distribution<float>(lo,hi)(r);}
int zone(float x,float y){
 if(x>124.11774444580078f && x<259.88226318359375f &&
    y>140.11773681640625f && y<275.88226318359375f) return 0;
 if(x>56.23548889160156f && x<327.7645263671875f &&
    y>72.23548889160156f && y<343.7645263671875f) return 1;
 return 2;
}
void advance(Bullet& b, int kind){
 if(kind==2){ // Only the narrow-barrier coordinate update, before translation.
  if(b.cooldown) --b.cooldown;
  else {int now=zone(b.x,b.y), before=zone(b.x-b.vx,b.y-b.vy);
   if(now!=before){
    b.cooldown=2; b.vx*=-1.0f; b.vy*=-1.0f;
    if(now==0 || before==0){
     b.x=(b.x-192.0f)*135.76451110839844f/67.88225555419922f+192.0f;
     b.y=(b.y-208.0f)*135.76451110839844f/67.88225555419922f+208.0f;
    }else{
     b.x=(b.x-192.0f)*67.88225555419922f/135.76451110839844f+192.0f;
     b.y=(b.y-208.0f)*67.88225555419922f/135.76451110839844f+208.0f;
    }
   }
  }
 }
 if(kind==1){ // Synthetic indefinitely active polar transform, multiplier=1.
  b.angle+=0.011f; if(b.angle>PI)b.angle-=2.0f*PI;
  b.speed+=0.004f;
  b.vx=std::cos(b.angle)*b.speed; b.vy=std::sin(b.angle)*b.speed;
 }
 b.x+=b.vx; b.y+=b.vy;
}
Box bounds(const Bullet& b){return {b.x-b.hx,b.x+b.hx,b.y-b.hy,b.y+b.hy};}
bool hit(const Box& b,Vec p){
 return p.x>=b.lo_x && p.x<=b.hi_x && p.y>=b.lo_y && p.y<=b.hi_y;
}
void forecast(Work& w,const std::vector<Bullet>& start,int kind){
 std::copy(start.begin(),start.end(),w.state.begin());
 for(int t=0;t<H;++t) for(int i=0;i<B;++i){
  advance(w.state[i],kind); w.boxes[t*B+i]=bounds(w.state[i]);
 }
}
uint64_t recompute(Work& w,const std::vector<Bullet>& start,
                   const std::vector<Vec>& paths,int kind){
 uint64_t total=0;
 for(int m=0;m<M;++m){
  std::copy(start.begin(),start.end(),w.state.begin());
  for(int t=0;t<H;++t){uint32_t n=0; const Vec p=paths[m*H+t];
   for(int i=0;i<B;++i){advance(w.state[i],kind); n+=hit(bounds(w.state[i]),p);}
   w.counts[m*H+t]=n; total+=n;
  }
 }
 return total;
}
uint64_t shared_scan(Work& w,const std::vector<Bullet>& start,
                    const std::vector<Vec>& paths,int kind){
 forecast(w,start,kind); uint64_t total=0;
 for(int m=0;m<M;++m)for(int t=0;t<H;++t){
  uint32_t n=0; const Vec p=paths[m*H+t]; const Box* row=&w.boxes[t*B];
  for(int i=0;i<B;++i)n+=hit(row[i],p);
  w.counts[m*H+t]=n; total+=n;
 }
 return total;
}
void make_index(Work& w){
 for(int t=0;t<H;++t){auto& f=w.index[t];f.heads.fill(-1);f.entries.clear();
  for(int i=0;i<B;++i){const Box& b=w.boxes[t*B+i];
   if(b.hi_x<0.0f || b.lo_x>=W || b.hi_y<0.0f || b.lo_y>=HEIGHT)continue;
   int x0=std::max(0,int(std::floor(b.lo_x/CELL)));
   int x1=std::min(NX-1,int(std::floor(b.hi_x/CELL)));
   int y0=std::max(0,int(std::floor(b.lo_y/CELL)));
   int y1=std::min(NY-1,int(std::floor(b.hi_y/CELL)));
   for(int y=y0;y<=y1;++y)for(int x=x0;x<=x1;++x){int c=y*NX+x;
    f.entries.push_back({i,f.heads[c]});f.heads[c]=int(f.entries.size()-1);
   }
  }
 }
}
uint64_t shared_grid(Work& w,const std::vector<Bullet>& start,
                    const std::vector<Vec>& paths,int kind){
 forecast(w,start,kind);make_index(w);uint64_t total=0;
 for(int m=0;m<M;++m)for(int t=0;t<H;++t){
  const Vec p=paths[m*H+t];auto& f=w.index[t];uint32_t n=0;
  int c=int(p.y/CELL)*NX+int(p.x/CELL);
  for(int k=f.heads[c];k>=0;k=f.entries[k].next)n+=hit(w.boxes[t*B+f.entries[k].id],p);
  w.counts[m*H+t]=n;total+=n;
 }
 return total;
}
void make_microtiles(Work& w){
 for(int t=0;t<H;++t){auto& f=w.index[t];f.occupied.fill(0);
  for(int i=0;i<B;++i){const Box& b=w.boxes[t*B+i];
   if(b.hi_x<0 || b.lo_x>=W || b.hi_y<0 || b.lo_y>=HEIGHT)continue;
   const int x0=std::max(0,int(std::floor(b.lo_x/2.0f)));
   const int x1=std::min(FNX-1,int(std::floor(b.hi_x/2.0f)));
   const int y0=std::max(0,int(std::floor(b.lo_y/2.0f)));
   const int y1=std::min(FNY-1,int(std::floor(b.hi_y/2.0f)));
   for(int y=y0;y<=y1;++y)for(int k=x0/64;k<=x1/64;++k){
    const int lo=std::max(x0,k*64)-k*64,hi=std::min(x1,k*64+63)-k*64;
    const uint64_t mask=(~uint64_t(0)<<lo)&(~uint64_t(0)>>(63-hi));
    f.occupied[y*FWORDS+k]|=mask;
   }
  }
 }
}
uint64_t shared_microtiles(Work& w,const std::vector<Bullet>& start,
                          const std::vector<Vec>& paths,int kind){
 forecast(w,start,kind);make_index(w);make_microtiles(w);uint64_t total=0;
 for(int m=0;m<M;++m)for(int t=0;t<H;++t){
  const Vec p=paths[m*H+t];auto& f=w.index[t];uint32_t n=0;
  const int x=int(p.x/2.0f),y=int(p.y/2.0f);
  if(f.occupied[y*FWORDS+x/64]&(uint64_t(1)<<(x%64))){
   const int c=int(p.y/CELL)*NX+int(p.x/CELL);
   for(int k=f.heads[c];k>=0;k=f.entries[k].next)n+=hit(w.boxes[t*B+f.entries[k].id],p);
  }
  w.counts[m*H+t]=n;total+=n;
 }
 return total;
}
using Fn=uint64_t(*)(Work&,const std::vector<Bullet>&,const std::vector<Vec>&,int);
struct Stats{double p50,p95,max;};
Stats measure(Fn fn,Work& w,const std::vector<Bullet>& start,
              const std::vector<Vec>& paths,int kind,int repeats){
 for(int i=0;i<3;++i)sink=fn(w,start,paths,kind);
 std::vector<double> ms;ms.reserve(repeats);
 for(int i=0;i<repeats;++i){
  const auto a=std::chrono::steady_clock::now();
  const uint64_t val=fn(w,start,paths,kind);
  const auto b=std::chrono::steady_clock::now();sink=val;
  ms.push_back(std::chrono::duration<double,std::milli>(b-a).count());
 }
 std::sort(ms.begin(),ms.end());
 return {ms[ms.size()/2],ms[size_t(std::ceil(0.95*ms.size()))-1],ms.back()};
}
int main(int argc,char**argv){
 try{
  int repeats=argc>1?std::stoi(argv[1]):15;
  if(repeats<3 || repeats>1000)throw std::invalid_argument("repeats must be 3..1000");
  const char* names[]={"uniform_linear","uniform_polar","narrow_warp","concentrated_static","same_bucket_nearmiss"};
  std::cout<<"scene,kernel,B,H,M,repeats,p50_ms,p95_ms,max_ms,collision_count,exact_checks\n";
  for(int kind=0;kind<5;++kind){
   std::mt19937 r(1729);std::vector<Bullet> start(B);
   for(auto& b:start){b.x=ur(r,0,W);b.y=ur(r,0,HEIGHT);b.hx=ur(r,2,5);b.hy=ur(r,2,5);
    b.angle=ur(r,-PI,PI);b.speed=ur(r,0.5f,3.0f);
    b.vx=std::cos(b.angle)*b.speed;b.vy=std::sin(b.angle)*b.speed;
    if(kind==3){b.x=ur(r,184,200);b.y=ur(r,344,360);b.vx=b.vy=0;}
    if(kind==4){b.x=ur(r,193,194);b.y=ur(r,354,355);b.vx=b.vy=0;b.hx=b.hy=2;}
   }
   std::vector<Vec> paths(M*H);
   for(int m=0;m<M;++m){Vec p{192,352};float dx=0,dy=0;
    for(int t=0;t<H;++t){
     if(t%8==0){dx=float(int(r()%3)-1)*2.0f;dy=float(int(r()%3)-1)*2.0f;}
     p.x=std::clamp(p.x+dx,1.0f,W-1);p.y=std::clamp(p.y+dy,1.0f,HEIGHT-1);
     if(kind==3){p.x=ur(r,188,196);p.y=ur(r,348,356);} // Adversarial locality, not a legal input trajectory.
     if(kind==4){p.x=ur(r,202,204);p.y=ur(r,354,357);} // Geometry stress, not a gameplay path.
     paths[m*H+t]=p;
    }
   }
   Work w;
   uint64_t expected=recompute(w,start,paths,kind);auto ref=w.counts;
   if(shared_scan(w,start,paths,kind)!=expected || w.counts!=ref)throw std::runtime_error("shared_scan mismatch");
   if(shared_grid(w,start,paths,kind)!=expected || w.counts!=ref)throw std::runtime_error("shared_grid mismatch");
   if(shared_microtiles(w,start,paths,kind)!=expected || w.counts!=ref)throw std::runtime_error("microtiles mismatch");
   uint64_t grid_checks=0,micro_checks=0;
   for(int m=0;m<M;++m)for(int t=0;t<H;++t){Vec p=paths[m*H+t];auto& f=w.index[t];
    int c=int(p.y/CELL)*NX+int(p.x/CELL);
    bool occupied=f.occupied[int(p.y/2)*FWORDS+int(p.x/2)/64]&(uint64_t(1)<<(int(p.x/2)%64));
    for(int k=f.heads[c];k>=0;k=f.entries[k].next){++grid_checks;if(occupied)++micro_checks;}
   }
   Fn fns[]={recompute,shared_scan,shared_grid,shared_microtiles};
   const char* fnames[]={"recompute","shared_scan","shared_grid","shared_microtiles"};
   for(int k=0;k<4;++k){auto s=measure(fns[k],w,start,paths,kind,repeats);
    std::cout<<names[kind]<<','<<fnames[k]<<','<<B<<','<<H<<','<<M<<','<<repeats<<','
     <<std::fixed<<std::setprecision(4)<<s.p50<<','<<s.p95<<','<<s.max<<','<<expected<<','
     <<(k==3?micro_checks:k==2?grid_checks:uint64_t(B)*H*M)<<'\n';
   }
  }
 }catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}
}
