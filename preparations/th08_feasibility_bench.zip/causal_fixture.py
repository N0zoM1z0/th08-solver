"""Synthetic one-shot causal fixture, NOT retail ECL or a TH08 player emulator.

Aimed-shot mechanics mirror the relevant source dependency only: the emitter
reads the candidate's post-movement position at the firing event. All numerical
parameters, the delay queue, and the two policies below are chosen for this test.
No attempt is made to reproduce TH08 floating-point or full update semantics.
"""
from collections import deque
import json
from math import hypot
from typing import Callable

HORIZON = 120
FIRE_TICK = 32
SPEED = 4.0
PLAYER_SPEED = 2.0
HALF_EXTENT = 4.0  # combined player and bullet AABB half-extent
EMITTER = (192.0, 128.0)


def run(policy: Callable[[int], int], delay: int, frozen: bool) -> dict:
    queue = deque([0] * delay)
    x, y = 192.0, 352.0
    bx, by = EMITTER
    vx = vy = 0.0
    target = None
    first_hit = None
    for tick in range(HORIZON):
        queue.append(policy(tick))
        applied = queue.popleft()
        x = min(383.0, max(1.0, x + applied * PLAYER_SPEED))
        if tick == FIRE_TICK:
            target = (192.0, 352.0) if frozen else (x, y)
            dx, dy = target[0] - bx, target[1] - by
            distance = hypot(dx, dy)
            vx, vy = SPEED * dx / distance, SPEED * dy / distance
        if tick >= FIRE_TICK:
            bx, by = bx + vx, by + vy
            if abs(x-bx) <= HALF_EXTENT and abs(y-by) <= HALF_EXTENT:
                if first_hit is None:
                    first_hit = tick
    return {"first_hit_tick": first_hit, "aim_sample": target,
            "final_player": [x, y], "frozen_future": frozen, "delay": delay}


def early_shift_then_stop(tick: int) -> int:
    return 1 if tick < 30 else 0


def wait_then_stream(tick: int) -> int:
    return 0 if tick < 30 else 1


if __name__ == "__main__":
    results = {}
    for name, policy in (("early_shift_then_stop", early_shift_then_stop),
                         ("wait_then_stream", wait_then_stream)):
        for frozen in (True, False):
            key = name + ("_frozen" if frozen else "_candidate_dependent")
            results[key] = run(policy, 2, frozen)
    assert results["early_shift_then_stop_frozen"]["first_hit_tick"] is None
    assert results["early_shift_then_stop_candidate_dependent"]["first_hit_tick"] is not None
    assert results["wait_then_stream_candidate_dependent"]["first_hit_tick"] is None
    print(json.dumps(results, indent=2))
