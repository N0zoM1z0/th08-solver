# TH08 dat + source audit

这是一份资源、源码语义和局部计算审计，**不是已经完成的 autoplay agent、完整游戏模拟器或原版 NMNB 成绩**。

主报告：`th08_dat_source_report_zh.md`。所有 ECL 偏移都是解密后的文件偏移，sub 编号从 0 开始；符卡 ID 是资源里的原始值。ECL 时间是局部脚本时间，不默认等于全局帧号或墙钟时间。

## 输入与版本

用户提供的 dat：46,838,025 字节，SHA-256：
`9d7edf43b8ddd347cbb641836f6b5050745dd936f688daebbf9382ca557043bb`

源码读取自已注册 th08 工作区，HEAD `af72ca98d044104d396b501072f4d1570c374235`。工作区存在未提交修正；采用读取时的活跃源码，见 `reports/source_provenance.json`。没有修改该工作区，也没有调用网络攻略、现成解包器或其他 autoplay 仓库。

ZIP 不含上传的 dat、原版 executable、解包后的音画资源或字体。报告中的反汇编、结构化参数和小型测试夹具来自用户提供的数据。

## 复现

需要 Python 3.10+，标准库即可。原生小测试另外需要 C++17 编译器。

```sh
python tools/prepare_resources.py /path/to/th08.dat
python tools/analyze_ecl.py
python tools/analyze_anm.py
python tools/analyze_timeline.py
python tools/audit_corpus.py
python tools/run_emitter_slices.py
python tools/verify_mechanisms.py
python tools/check_causal_slices.py
python tools/generate_native_fixture.py
```

Linux / MinGW：
```sh
g++ -std=c++17 -O3 -Wall -Wextra tools/bench_real_emitter.cpp -o emitter_bench
./emitter_bench
```

Windows Visual Studio 开发者命令提示符：
```bat
cl /std:c++17 /O2 /EHsc tools\bench_real_emitter.cpp /Fe:emitter_bench.exe
emitter_bench.exe
```

Windows 命令是复现入口，本次未实际运行 Windows 构建或原版游戏。

## 各报告的证据等级

- `archive_manifest.json`：目录 317 项；只有带 `sha256` 的项完成了内容解包及内容哈希。没有声称所有音画资源都解码了。
- `ecl_parsed.json`：24 个 ECL 的全部子程序记录，包括终止标记。未知类型的参数保留原始十六进制。
- `ecl_inventory.json`：计数排除每个子程序的终止标记。
- `disassembly/*.txt`：0x08 掩码静态包含视图，不是执行可达性结果；不是完整反编译。未审定参数明确以整数/浮点双视图显示。
- `timeline_parsed.json`：全部 24 文件中声明的 timeline；等待消息、Boss、事件会使局部时间不同于实际帧号。
- `corpus_audit.json`：验证了 2,182 个子程序内跳转站点；直接 call/spawn 边仅为已知参数位置的静态引用，并非完整调用图。
- `emitter_slice_results.json`：十组真实发射片段的受限解释执行。未知执行指令会报错；不执行运动、碰撞、伤害、对象池、ANM、其他随机数消费者。随机角或轨道角使用明确的外部测试值，不能把这些轨迹称为原版运行。
- `verified_mechanisms.json`：资源常量与已读源码状态机之间的断言；不是 Windows 运行验证。
- `causal_slice_checks.json`：二维追踪递推的理想实数分析，以及显式约定随机数取值次序的局部例子。不能代替旧编译器浮点/求值顺序验证。
- `native_emitter_benchmark.json`：仅 ecldata1 sub40 的发射调度；不包含弹丸运动、碰撞、搜索或输入。分位数是 1,000 次调用的批次均摊分位数，不是逐帧尾延迟。

所有“发数”除另有说明都是 ECL 请求量或条件理想量，不是屏幕同时存在的弹量。
